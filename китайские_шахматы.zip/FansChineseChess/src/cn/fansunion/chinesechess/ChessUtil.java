
package cn.fansunion.chinesechess;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public final class ChessUtil {

	private ChessUtil() {

	}


	public static String getDateAndTime() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(currentTime);
		return dateString;
	}


	public static String getTime() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		String dateString = formatter.format(currentTime);
		return dateString;
	}


	public static String getDateAndDay() {
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.FULL);
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		String today = dateFormat.format(calendar.getTime());

		return today;
	}


	public static ImageIcon getImageIcon(String name) {
		String path = "img/" + name;
		URL imgURL = ChessUtil.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		}
		return null;
	}


	public static Image getImage(String name) {
		String path = "img/" + name;
		URL imgURL = ChessUtil.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL).getImage();
		}
		return null;
	}


	public static Image getAppIcon() {
		String path = "img/piece/" + "shuai.png";
		URL imgURL = ChessUtil.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL).getImage();
		}
		return null;
	}


	public static Image getAppIcon2() {
		String path = "img/piece/" + "jiang.png";
		URL imgURL = ChessUtil.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL).getImage();
		}
		return null;
	}

	public static void playSound(String name) {
		String path = "";
		path = "sounds/" + name;
		File file = new File(path);
		InputStream is;
		try {
			is = new FileInputStream(file.getAbsolutePath());

		} catch (IOException e) {
			e.printStackTrace();
		}

	}


	public static URL getHelpsUrl(String name) {
		String path = "helps/" + name;
		URL url = null;
		try {
			url = ChessUtil.class.getClassLoader().getResource(path);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return url;
	}


	public static void showHelpDialog() {
		HelpDialog help = new HelpDialog();
		help.setVisible(true);
	}


	public static String numToZi(int num) {
		if (num <= 0 || num >= 10) {
			System.out.println("���֧ӧ֧�ߧ��� ��ѧ�ѧާ֧�⣡");
			return "";
		}
		String zi = "";

		switch (num) {
		case 1:
			zi = "1";
			break;
		case 2:
			zi = "2";
			break;
		case 3:
			zi = "3";
			break;
		case 4:
			zi = "4";
			break;
		case 5:
			zi = "5";
			break;
		case 6:
			zi = "6";
			break;
		case 7:
			zi = "7";
			break;
		case 8:
			zi = "8";
			break;
		case 9:
			zi = "9";
			break;
		default:
			System.out.println("���֧ӧ֧�ߧ��� ��ѧ�ѧާ֧�⣡");
			break;
		}

		return zi;
	}


	public static int ziToNum(String zi) {
		int num = 0;

		if (zi.equals("һ") || zi.equals("1")) {
			num = 1;
		} else if (zi.equals("2") || zi.equals("2")) {
			num = 2;
		} else if (zi.equals("3") || zi.equals("3")) {
			num = 3;
		} else if (zi.equals("4") || zi.equals("4")) {
			num = 4;
		} else if (zi.equals("5") || zi.equals("5")) {
			num = 5;
		} else if (zi.equals("6") || zi.equals("6")) {
			num = 6;
		} else if (zi.equals("7") || zi.equals("7")) {
			num = 7;
		} else if (zi.equals("8") || zi.equals("8")) {
			num = 8;
		} else if (zi.equals("9") || zi.equals("9")) {
			num = 9;
		}

		return num;
	}


	public static void writeStringToFile(String path, String content) {
		File file = new File(path);

		try {
			FileWriter writer = new FileWriter(file);
			writer.write(content);

			writer.close();

	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static void showAboutDialog() {
		JOptionPane
				.showMessageDialog(
						null,
						JOptionPane.INFORMATION_MESSAGE);
	}


	public static void showWelcomeDialog() {
		JOptionPane.showMessageDialog(null, 
				JOptionPane.INFORMATION_MESSAGE);

	}


	public static void main(String[] args) {

		URL url = ChessUtil.class.getResource("/sounds/back.mid");
		ChessUtil.playSound("back.mid");
		System.out.println(url);

	}

}
