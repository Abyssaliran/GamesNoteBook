
package cn.fansunion.chinesechess.ext.maze;


public class IntPoint {

	public int i = 0;

	public int j = 0;

	public IntPoint(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public IntPoint() {

	}
}
