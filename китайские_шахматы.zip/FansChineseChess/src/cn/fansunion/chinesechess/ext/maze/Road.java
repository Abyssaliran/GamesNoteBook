
package cn.fansunion.chinesechess.ext.maze;


public class Road {

	public IntPoint seat;


	public boolean[] directions = { false, false, false, false, true, true,
			true, true };

	public Road(IntPoint curPosition) {
		this.seat = curPosition;
	}

	public Road() {

	}

	public boolean hasDirection() {
		return (directions[0] || directions[1] || directions[2]
				|| directions[3] || directions[4] || directions[5]
				|| directions[6] || directions[7]);
	}
}
