
package cn.fansunion.chinesechess.ext.maze;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessManual;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ChessRule;
import cn.fansunion.chinesechess.core.ManualItem;
import cn.fansunion.chinesechess.core.MoveStep;



public class HorseMazeGUI extends JFrame implements ActionListener {

	private static final long serialVersionUID = 266L;

	private JButton prev, next, auto, first, last;

	private JButton reprint, save, maze, set, exit, help, undo;

	private JButton manualBox;

	private JTextField startToEnd = new JTextField(9);

	private ArrayList<ManualItem> records;

	private HorseMazeBoard board;

	private ChessManual chessManual;

	private JPanel gameStatusPanel;

	private JPanel manualTools;

	public String tips;

	public MyThread mt = new MyThread();


	private JLabel gameStatusContent;

	private JLabel gameStatusIcon;

	private JScrollPane manualScroll;

	private JList manual;

	private Vector descs;

	private Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);


	public HorseMazeGUI() {

		board = new HorseMazeBoard();
		board.initChess(true);
		board.horseMazePath = this;

		chessManual = board.chessManual;
		manualScroll = chessManual.manualScroll;
		manual = chessManual.manualList;
		descs = chessManual.descs;
		records = chessManual.getManualItems();

		initButtons();
		initPanels();

		setSize(660, 640);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setResizable(false);
		setIconImage(ChessUtil.getAppIcon());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}

		});
	}


	private void initPanels() {

		JPanel rightPanel = new JPanel(new BorderLayout());


		JPanel recordsPanel = new JPanel(new BorderLayout());

		TitledBorder recordsBorder = new TitledBorder(PropertyReader
				.get("CHESS_MESSAGE_TOOLTIP"));
		recordsPanel.setBorder(recordsBorder);
		recordsPanel.setPreferredSize(new Dimension(240, 330));
		recordsPanel.add(BorderLayout.CENTER, chessManual);


		manualTools = new JPanel(new FlowLayout(FlowLayout.CENTER));
		// manualTools.setPreferredSize(new Dimension(220, 20));
		manualTools.add(first);
		manualTools.add(prev);
		manualTools.add(auto);
		manualTools.add(next);
		manualTools.add(last);

		recordsPanel.add(BorderLayout.SOUTH, manualTools);

		JPanel controlPanel = new JPanel(new GridLayout(3, 1));

		FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
		JPanel one = new JPanel(layout);
		JPanel two = new JPanel(layout);
		JPanel three = new JPanel(layout);

		one.add(startToEnd);
		one.add(maze);

		two.add(reprint);
		two.add(undo);
		two.add(manualBox);

		three.add(help);
		three.add(set);
		three.add(exit);

		controlPanel.add(one);
		controlPanel.add(two);
		controlPanel.add(three);
		// controlPanel.add(four);
		rightPanel.add(BorderLayout.NORTH, recordsPanel);
		rightPanel.add(BorderLayout.CENTER, controlPanel);

		JSplitPane splitH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, board,
				rightPanel);
		splitH.setDividerSize(5);
		splitH.setDividerLocation(450);
		add(splitH, BorderLayout.CENTER);


		gameStatusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		gameStatusPanel.setPreferredSize(new Dimension(660, 120));
		// gameStatusPanel.setBackground(new Color(122, 146, 170));
		gameStatusIcon = new JLabel(ChessUtil.getImageIcon("hongshuai.png"));

		gameStatusContent = new JLabel("����ѧ�ߧѧ� ������ߧ� �էӧڧا֧��� ��֧�ӧ��");
		gameStatusContent.setFont(new Font("����", Font.PLAIN, 16));

		TitledBorder gameStatusBorder = new TitledBorder("��������ߧڧ� �ڧԧ��");
		gameStatusBorder.setTitleColor(Color.RED);
		gameStatusBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		gameStatusPanel.setToolTipText("��������ߧڧ� �ڧԧ��");
		gameStatusPanel.setBorder(gameStatusBorder);

		gameStatusPanel.add(gameStatusIcon);
		gameStatusPanel.add(gameStatusContent);

		add(BorderLayout.SOUTH, gameStatusPanel);

	}


	private void initButtons() {
		Dimension iconSize = new Dimension(16, 16);
		prev = new JButton(ChessUtil.getImageIcon("prev.gif"));
		prev.addActionListener(this);
		prev.setToolTipText("����֧է��է��ڧ�");
		prev.setCursor(new Cursor(Cursor.HAND_CURSOR));
		prev.setPreferredSize(iconSize);

		next = new JButton(ChessUtil.getImageIcon("next.gif"));
		next.addActionListener(this);
		next.setToolTipText("���ݧ֧է���ڧ� ��ѧ�");
		next.setCursor(new Cursor(Cursor.HAND_CURSOR));
		next.setPreferredSize(iconSize);

		first = new JButton(ChessUtil.getImageIcon("first.gif"));
		first.addActionListener(this);
		first.setToolTipText("��֧�ӧ��� ��ѧ�");
		first.setCursor(new Cursor(Cursor.HAND_CURSOR));
		first.setPreferredSize(iconSize);

		last = new JButton(ChessUtil.getImageIcon("last.gif"));
		last.addActionListener(this);
		last.setToolTipText("����ݧ֧էߧڧ� ��ѧ�");
		last.setCursor(new Cursor(Cursor.HAND_CURSOR));
		last.setPreferredSize(iconSize);

		auto = new JButton(ChessUtil.getImageIcon("auto.gif"));
		auto.addActionListener(this);
		auto.setToolTipText("���ӧ��ާѧ�ڧ�֧�ܧѧ� ���֧٧֧ߧ�ѧ�ڧ�");
		auto.setPreferredSize(iconSize);
		auto.setCursor(new Cursor(Cursor.HAND_CURSOR));

		Insets insets = new Insets(1, 1, 1, 1);

		reprint = new JButton("����ا֧ݧ��� ��էѧ�", ChessUtil.getImageIcon("reprint.gif"));
		reprint.setToolTipText("���ڧާ֧ۧ�");
		reprint.addActionListener(this);
		// reprint.setPreferredSize(dimension);
		reprint.setCursor(handCursor);
		reprint.setMargin(insets);

		save = new JButton("���ѧ���", ChessUtil.getImageIcon("save.gif"));
		save.addActionListener(this);
		save.setToolTipText("������ѧߧڧ�� �٧ѧ�ڧ�� �ڧԧ��");
		// save.setPreferredSize(dimension);
		save.setCursor(handCursor);
		save.setMargin(insets);

		maze = new JButton("���֧�֧ߧڧ� �ݧѧҧڧ�ڧߧ��", ChessUtil.getImageIcon("saveas.gif"));
		maze.addActionListener(this);
		maze.setToolTipText("���֧�֧ߧڧ� �ݧѧҧڧ�ڧߧ��");
		// saveAs.setPreferredSize(dimension);
		maze.setCursor(handCursor);
		maze.setMargin(insets);

		undo = new JButton("���ѧ�ާѧ�� ���اѧݧ֧ߧڧ�", ChessUtil.getImageIcon("undo.gif"));
		undo.addActionListener(this);
		undo.setToolTipText("���ѧ�ާѧ�� ���اѧݧ֧ߧڧ�");
		undo.setCursor(handCursor);
		undo.setMargin(insets);

		set = new JButton("���ѧ����ڧ��", ChessUtil.getImageIcon("welcome.gif"));
		set.setToolTipText("���ѧ����ڧ��");
		set.addActionListener(this);
		set.setCursor(handCursor);
		set.setMargin(insets);

		help = new JButton("����ާ�ԧڧ��", ChessUtil.getImageIcon("help.gif"));
		help.setToolTipText("����ާ�ԧڧ��");
		help.addActionListener(this);
		help.setCursor(handCursor);
		help.setMargin(insets);

		exit = new JButton("�ӧ��ҧ��ӧѧ��", ChessUtil.getImageIcon("stop.gif"));
		exit.setToolTipText("�ӧ��ҧ��ӧѧ��");
		exit.addActionListener(this);
		exit.setCursor(handCursor);
		exit.setMargin(insets);

		manualBox = new JButton("���ѧ�ާѧ�ߧ��� ��֧ܧ���", ChessUtil.getImageIcon("stop.gif"));
		manualBox.setToolTipText("���ѧ�ާѧ�ߧ��� ��֧ܧ���");
		manualBox.addActionListener(this);
		manualBox.setCursor(handCursor);
		manualBox.setMargin(insets);

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();


		if (source == reprint) {

			dispose();
			HorseMazeGUI newPrint = new HorseMazeGUI();
			newPrint.setVisible(true);

		}

		if (source == maze) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}

			String movePath = startToEnd.getText();
			movePath = movePath.trim();
			String[] path = movePath.split(",");
			if (path.length != 4) {
				System.out.println("���֧��ѧӧڧݧ�ߧ��� �ܧ���էڧߧѧ����");
				return;
			}

			int[] startToEnd = new int[4];
			for (int i = 0; i < path.length; i++) {
				startToEnd[i] = Integer.valueOf(path[i]);
			}
			IntPoint start = new IntPoint(startToEnd[0], startToEnd[1]);
			IntPoint end = new IntPoint(startToEnd[2], startToEnd[3]);

			HorseMazeModel maze = new HorseMazeModel(board, start, end);
			new Thread(maze).start();

			mt.start();

		} else if (source == exit) {
			dispose();
		} else if (source == manualBox) {
			String manual = JOptionPane.showInputDialog(this, "����اѧݧ�ۧ���, �ӧӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��", "����اѧݧ�ۧ���, �ӧӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��",
					JOptionPane.OK_CANCEL_OPTION);
			if (manual != null) {
				manual = manual.trim();
			}
			movePieceByManual(manual);

		}

	}


	private void movePieceByManual(String manual) {
		if (manual != null && manual.length() == 4) {
			ChessPiece movePiece = board.getMovePiece(manual);
			if (movePiece == null) {
				return;
			}
			ChessPiece removedPiece = board.getRemovedPiece(manual);
			Point pStart = board.getStartPosition(manual);
			Point pEnd = board.getEndPosition(manual);

			int startX = (int) pStart.getX();
			int startY = (int) pStart.getY();
			int endX = (int) pEnd.getX();
			int endY = (int) pEnd.getY();
			System.out.println(movePiece.getCategory() + " :" + startX + startY
					+ endX + endY);
			boolean rule = ChessRule.allRule(movePiece, startX, startY, endX,
					endY, board.chessPoints);
			System.out.println("�ܷ��ƶ����ӣ�" + rule);
			if (rule) {

				board.removePiece(removedPiece);
				board.chessPoints[endX][endY].setPiece(movePiece, board);
				(board.chessPoints[startX][startY]).setHasPiece(false);
				movePiece.setPosition(pEnd);

				board.setMoveFlag(true);
				board.movePoints[0] = new Point(endX, endY);
				board.movePoints[1] = new Point(startX, startY);
				board.clearTipPoints();

		
				ManualItem record = new ManualItem();
				MoveStep moveStep = new MoveStep(new Point(startX, startY),
						new Point(endX, endY));
				record.setMoveStep(moveStep);
				if (removedPiece != null) {
					record.setEatedPieceId(removedPiece.getId());
				} else {
					record.setEatedPieceId(null);
				}
				record.setMovePieceId(movePiece.getId());
				board.chessManual.addManualItem(record);


				ChessUtil.playSound("eat.wav");

				validate();
				repaint();


				board.reverseName();

			}
		}
	}

	private void handleExitGame() {
		if (board.getWinkThread() != null) {
			board.getWinkThread().interrupt();
			System.out.println("�ر��У�");
		}
		dispose();
	}


	public void updateGameStatus(int state, String content) {

		switch (state) {
		case 1:
			gameStatusIcon.setIcon(ChessUtil.getImageIcon("hongshuai.png"));
			gameStatusIcon.setToolTipText("���ѧ��ѧݧ� ���֧�֧է� �ܧ�ѧ�ߧ�� �ӧ֧�֧�ڧߧܧڣ�");
			break;
		case 2:
			gameStatusIcon.setIcon(ChessUtil.getImageIcon("heijiang.png"));
			gameStatusIcon.setToolTipText("����ڧ�ݧ� ���֧�֧է� ��֧�ߧ��� �ڧէ�ڣ�");
			break;
		default:
			break;
		}

		if (content != null && !content.equals("")) {
			gameStatusContent.setText(content);
		}
	}

	public void showTips(String tips) {
		this.tips = tips;
	}


	public static void main(String[] args) {
		HorseMazeGUI maze = new HorseMazeGUI();
		maze.setVisible(true);
	}

	class MyThread extends Thread {
		public void run() {
			while (true) {
				if (gameStatusContent == null) {
					gameStatusContent = new JLabel();
				}
				if (tips != null && tips.equals("exit")) {
					System.out.println("exit...");
					break;
				}
				gameStatusContent.setText(tips);
				validate();
				repaint();
			}
		}
	}

}
