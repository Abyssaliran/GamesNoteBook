
package cn.fansunion.chinesechess.ext.maze;

import java.util.ArrayList;

import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ChessPoint;
import cn.fansunion.chinesechess.core.ChessRule;



public class HorseMazeModel implements Runnable {
	private HorseMazeBoard board;


	private IntPoint[][] myPoints = new IntPoint[10][11];


	private ArrayList<Road> roads = new ArrayList<Road>();

	private IntPoint startPos = null;


	private IntPoint endPos = null;


	private IntPoint curPos;


	private Road startRoad = new Road(startPos);


	private ArrayList<ArrayList<Road>> allRoads = new ArrayList<ArrayList<Road>>();


	private boolean isBackRoad = false;

	private ChessPiece movePiece;

	private static int TIME = 1500;

	private String tips;

	public HorseMazeModel(HorseMazeBoard board, IntPoint startPos,
			IntPoint endPos) {
		this.board = board;
		this.startPos = startPos;
		this.endPos = endPos;

		for (int i = 1; i <= 9; i++) {
			for (int j = 1; j <= 10; j++) {
				myPoints[i][j] = new IntPoint(i, j);
			}
		}
		curPos = startPos;
		ChessPoint point = board.chessPoints[startPos.i][startPos.j];
		if (point.hasPiece()) {
			movePiece = point.getPiece();
		}
	}

	public boolean hasMazePath() {
		Road road = new Road();
		boolean flag = false;

		do {
			if (curPos != null) {
				System.out
						.println("\n��֧ܧ��ѧ� ���٧ڧ�ڧ�(" + curPos.i + "," + curPos.j + ")");
			}
			if (curPos != null) {
				if (isBackRoad) {
					if (road.hasDirection()) {
						System.out.println("���֧�ߧ����� �� ��ݧ֧է���֧ާ� ����ڣ�");

						nextPosition(road);

						if (!isBackRoad) {
							road = new Road(curPos);
							roads.add(road);
							showTips("���֧�֧ۧ�� �� ��ݧ֧է���֧ާ� �ާ֧��� �� ��֧ܧ��֧� �ާ֧�����ݧ�ا֧ߧڧڣ�");
							System.out.println("(" + road.seat.i + ","
									+ road.seat.j + ")����ҧѧӧڧ�� �� ����");
						}
					} else {
						Road temp = roads.remove(roads.size() - 1);
						showTips("���֧�ߧ����� �� ���֧է��է��֧� ���٧ڧ�ڧڣ�");
						System.out.println("(" + temp.seat.i + ","
								+ temp.seat.j + ")�ҧ��� ��էѧݧ֧ߣ�");
						road = roads.get(roads.size() - 1);
						curPos = road.seat;
						board.movePiece(movePiece, temp.seat.i, temp.seat.j,
								curPos.i, curPos.j);
						sleep(TIME);

						isBackRoad = false;
					}
				} else {
					road = new Road(curPos);
					if (road.hasDirection()) {
						roads.add(road);
						showTips("���֧�֧ۧ�� �� ��ݧ֧է���֧ާ� �ާ֧��� �� ��֧ܧ��֧� �ާ֧�����ݧ�ا֧ߧڧ�");
						System.out.println("(" + road.seat.i + ","
								+ road.seat.j + ")����ҧѧӧڧ�� �� ����");
					}// if (isBackRoad)
				}// if (curPos != null && curPos.go)

				System.out.println("road(" + road.seat.i + "," + road.seat.j
						+ ")");


				if (curPos.i == startPos.i && curPos.j == startPos.j && isEnd()) {

					System.out.println("(" + road.seat.i + "," + road.seat.j
							+ ")���֧ܧ�է� �ڧէ�� ��� ��֧ܧ��֧ާ� �����");
					return allRoads.size() != 0;
				}

				if (curPos.i == endPos.i && curPos.j == endPos.j) {
					boolean found = false;
					for (int i = 0; i < roads.size(); i++) {
						IntPoint myPoint = roads.get(i).seat;
						if (myPoint.i == endPos.i && myPoint.j == endPos.j) {
							found = true;
							System.out.println("found = true");
						}
					}

					if (!found) {
						roads.add(new Road(endPos));
					}

					ArrayList<Road> oneRoad = new ArrayList<Road>();
					oneRoad.addAll(roads);
					allRoads.add(oneRoad);
					showTips("���ѧ�֧� ����");
					sleep(1000);

					flag = true;
					System.out.println("���ѧ�֧� ����");

					showTips("���֧�ߧ����� �� ���֧է��է��֧� ���٧ڧ�ڧ� ��֧ܧ��֧� ���٧ڧ�ڧ�");
					Road endRoad = roads.remove(roads.size() - 1);
					road = roads.get(roads.size() - 1);

					board.movePiece(movePiece, endRoad.seat.i, endRoad.seat.j,
							road.seat.i, road.seat.j);
					sleep(TIME);

					nextPosition(road);

				}
				else {
					System.out.println("����ݧ��ڧ�� ��ݧ֧է���ڧ� ����");
					nextPosition(road);
				}
			} else {
				if (!roads.isEmpty()) {
					while ((!road.hasDirection()) && (!roads.isEmpty())) {
						showTips("���֧�ߧ����� �� ���֧է��է��֧� ���٧ڧ�ڧ� ��֧ܧ��֧� ���٧ڧ�ڧ�");
						Road temp = roads.remove(roads.size() - 1);
						System.out.println("(" + temp.seat.i + ","
								+ temp.seat.j + ")������ ��էѧݧ֧ߣ�");
						if (!roads.isEmpty()) {
							road = roads.get(roads.size() - 1);
							board.movePiece(movePiece, temp.seat.i,
									temp.seat.j, road.seat.i, road.seat.j);
							sleep(TIME);
						}
					}
					if (road.hasDirection()) {
						System.out.print("����ݧ��ڧ�� ��ݧ֧է���ڧ� �����22����");
						nextPosition(road);
					}
				}
			}
		} while (!roads.isEmpty());

		System.out.println("�٧ѧܧ�ߧ�ڧݧ��" + flag);
		return flag;
	}

	private void sleep(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}


	private void nextPosition(Road curRoad) {
		isBackRoad = false;
		curPos = curRoad.seat;
		int i = curPos.i;
		int j = curPos.j;
		System.out.print("(" + i + "," + j + ")���ݧ֧է���ڧ� ����");

		int iSize = 9;
		int jSize = 10;
		boolean[] directions = curRoad.directions;
		IntPoint nextPos = null;


		if (directions[0]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[0] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ� 0");
			}

			i++;
			j = j - 2;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("0������ݧ࣡");
			}
			curRoad.directions[0] = false;
		} else if (directions[1]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[1] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ� 1");
			}

			i = i + 2;
			j--;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("1������ݧ࣡");
			}
			curRoad.directions[1] = false;
		} else if (directions[2]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[2] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ�2");
			}

			i = i + 2;
			j++;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("3������ݧ࣡");
			}
			curRoad.directions[2] = false;
		} else if (directions[3]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[3] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ�3");
			}
			i++;
			j = j + 2;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("3������ݧ࣡");
			}
			curRoad.directions[3] = false;

		}

		else if (directions[4]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[4] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ�4");
			}

			i--;
			j = j + 2;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("4������ݧ࣡");
			}
			curRoad.directions[4] = false;
		} else if (directions[5]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[5] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ�5");
			}

			i = i - 2;
			j++;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("5������ݧ࣡");
			}
			curRoad.directions[5] = false;
		} else if (directions[6]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[6] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ�6");
			}

			i = i - 2;
			j--;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("6������ݧ࣡");
			}
			curRoad.directions[6] = false;
		} else if (directions[7]) {
			if (i == startPos.i && j == startPos.j) {
				startRoad.directions[7] = false;
				System.out.println("�����ѧӧߧѧ� ����ܧ�7");
			}
			i--;
			j = j - 2;
			if (i >= 1 && j >= 1 && i <= iSize && j <= jSize) {
				nextPos = myPoints[i][j];
				System.out.print("7������ݧ࣡");
			}
			curRoad.directions[7] = false;

		}

		System.out.println("(" + i + "," + j + ")");

		int size = roads.size();

		for (int m = 0; m < size; m++) {
			Road r = roads.get(m);
			if (r.seat.i == i && r.seat.j == j) {
				System.out.println("������ �ӧ֧�ߧ�����!");
				isBackRoad = true;
				break;
			}
		}
		if (!isBackRoad) {
			if (nextPos == null) {
				System.out.println("nextPos == null!");
				// return;
			}
			boolean rule = ChessRule.allRule(movePiece, curPos.i, curPos.j,
					i, j, board.chessPoints);


			if (rule && !board.chessPoints[i][j].hasPiece()) {
				board.movePiece(movePiece, curPos.i, curPos.j, i, j);
				curPos = nextPos;
				sleep(TIME);

			} else {
				isBackRoad = true;//
			}
		}

	}

	private boolean isEnd() {

		boolean left0 = startRoad.directions[4];
		boolean left1 = startRoad.directions[5];
		boolean left2 = startRoad.directions[6];
		boolean left3 = startRoad.directions[7];

		boolean right0 = startRoad.directions[0];
		boolean right1 = startRoad.directions[1];
		boolean right2 = startRoad.directions[2];
		boolean right3 = startRoad.directions[3];


		if ((left0 || left1 || left2 || left3 || right0 || right1 || right2 || right3)) {
			return false;
		}
		return true;
	}


	public void printAllRoads() {
		String str = "";
		for (int m = 0; m < allRoads.size(); m++) {
			str += "�ߧ�ާ֧�" + m + "�����:";
			System.out.println("�ߧ�ާ֧�" + m + "����");
			ArrayList<Road> oneRoad = allRoads.get(m);
			int num = oneRoad.size();
			for (int i = 0; i < num; i++) {
				Road road = oneRoad.get(i);
				System.out.print("id:" + i + " (" + road.seat.i + ","
						+ road.seat.j + ")\t");
				str += "(" + road.seat.i + "," + road.seat.j + ")��";
			}
			str += "\r\n";
			System.out.println();
		}
		board.horseMazePath.showTips(str);
		board.horseMazePath.mt = null;

	}

	private void showTips(String tips) {
		this.tips = tips;
		board.horseMazePath.showTips(tips);
	}

	public static void main(String[] args) {
		// String movePath = "8,10,9,8";
		String movePath = "8,10,1,6";
		movePath = movePath.trim();
		String[] path = movePath.split(",");
		if (path.length != 4) {
			System.out.println("���֧��ѧӧڧݧ�ߧ��� �ܧ���էڧߧѧ����");
			return;
		}

		int[] startToEnd = new int[4];
		for (int i = 0; i < path.length; i++) {
			startToEnd[i] = Integer.valueOf(path[i]);
		}
		IntPoint start = new IntPoint(startToEnd[0], startToEnd[1]);
		IntPoint end = new IntPoint(startToEnd[2], startToEnd[3]);

		HorseMazeBoard board = new HorseMazeBoard();
		board.initChess(true);

		HorseMazeModel maze = new HorseMazeModel(board, start, end);
		boolean has = maze.hasMazePath();
		if (has) {
			maze.printAllRoads();
		}
	}

	public void run() {
		boolean has = hasMazePath();

		if (has) {
			printAllRoads();
		}
	}

}
