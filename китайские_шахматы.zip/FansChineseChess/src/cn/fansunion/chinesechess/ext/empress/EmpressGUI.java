
package cn.fansunion.chinesechess.ext.empress;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.PieceUtil;
import cn.fansunion.chinesechess.core.ChessPiece.PieceId;


public class EmpressGUI extends JFrame implements ActionListener, Runnable {

	private static final long serialVersionUID = 266L;

	private JButton prev, next, auto, first, last;

	private JButton save, advancedSave, empress, set, exit, help, undo;

	private JTextField numField = new JTextField(5);

	private EmpressBoard board;

	private JPanel gameStatusPanel;

	private JPanel manualTools;

	public String tips;


	private JTextArea gameStatusContent;

	private JScrollPane manualScroll;

	private JList manual = new JList();

	private Vector<String> descs = new Vector<String>();

	private ArrayList<ArrayList<Point>> lists = new ArrayList<ArrayList<Point>>();

	private ArrayList<int[][]> advancedLists = new ArrayList<int[][]>();


	private Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);

	private ArrayList<ChessPiece> pieces = new ArrayList<ChessPiece>();

	private Thread autoThread = new Thread(this);

	private int curIndex = -1;

	private TitledBorder recordsBorder;


	public EmpressGUI() {

		board = new EmpressBoard();
		// board.owner = this;

		initButtons();
		initPanels();


		for (int index = 0; index < 9; index++) {
			pieces.add(PieceUtil.createPiece(PieceId.SHUAI));
		}

		setSize(660, 620);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setResizable(false);
		setIconImage(ChessUtil.getAppIcon());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}

		});
	}


	private void initPanels() {

		JPanel rightPanel = new JPanel(new BorderLayout());


		JPanel recordsPanel = new JPanel(new BorderLayout());

		recordsBorder = new TitledBorder("����� �ާѧܧ֧��");
		recordsPanel.setBorder(recordsBorder);
		recordsPanel.setPreferredSize(new Dimension(240, 330));
		manualScroll = new JScrollPane(manual);
		recordsPanel.add(BorderLayout.CENTER, manualScroll);

		manualTools = new JPanel(new FlowLayout(FlowLayout.CENTER));
		// manualTools.setPreferredSize(new Dimension(220, 20));
		manualTools.add(first);
		manualTools.add(prev);
		manualTools.add(auto);
		manualTools.add(next);
		manualTools.add(last);

		recordsPanel.add(BorderLayout.SOUTH, manualTools);

		JPanel controlPanel = new JPanel(new GridLayout(3, 1));

		FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
		JPanel one = new JPanel(layout);
		JPanel two = new JPanel(layout);
		JPanel three = new JPanel(layout);

		one.add(numField);
		one.add(empress);

		two.add(save);
		two.add(advancedSave);
		// two.add(undo);

		three.add(help);
		three.add(set);
		three.add(exit);

		controlPanel.add(one);
		controlPanel.add(two);
		controlPanel.add(three);

		rightPanel.add(BorderLayout.NORTH, recordsPanel);
		rightPanel.add(BorderLayout.CENTER, controlPanel);

		JSplitPane splitH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, board,
				rightPanel);
		splitH.setDividerSize(5);
		splitH.setDividerLocation(450);
		add(splitH, BorderLayout.CENTER);

		gameStatusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		gameStatusPanel.setPreferredSize(new Dimension(660, 90));

		gameStatusContent = new JTextArea("  N(1<=N<=9)����� ���ڧէڧ�֧�ܧڧ� �ާѧܧ֧��:\n"
				+ "  3 ��ԧ�ѧߧڧ�֧ߧڧ�: �ݧ�ҧ��� �էӧ� ��ڧԧ��� �ߧ� �ާ�ԧ�� �٧ѧߧڧާѧ�� ��էߧ� �� ��� �ا� �����ܧ� �ڧݧ� ����ݧҧ֧� �ߧ� �է��ܧ�.��" + "���ݧ� ��ѧܧѧ� �ا� �էڧѧԧ�ߧѧݧ�.");
		gameStatusContent.setFont(new Font("����", Font.PLAIN, 16));

		TitledBorder gameStatusBorder = new TitledBorder("��������ߧڧ� �ڧԧ��");
		gameStatusBorder.setTitleColor(Color.RED);
		gameStatusBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		gameStatusPanel.setToolTipText("����ڧ�ѧߧڧ� �ѧݧԧ��ڧ�ާ�");
		gameStatusPanel.setBorder(gameStatusBorder);
		gameStatusPanel.add(gameStatusContent);

		add(BorderLayout.SOUTH, gameStatusPanel);


		manual.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int count = e.getClickCount();

				if (count == 1 || count == 2) {
					int index = manual.getSelectedIndex();
					if (index != -1) {
						curIndex = index;
						displayLayout(curIndex);
					}
				}

			}

		});
	}


	private void displayLayout(int index) {
		if (index < 0 || index >= lists.size()) {
			return;
		}

		ArrayList<Point> arrayList = lists.get(index);
		int size2 = arrayList.size();
		for (int j = 0; j < size2; j++) {
			Point point = arrayList.get(j);
			ChessPiece piece = pieces.get(j);
			int x = (int) point.getX();
			int y = (int) point.getY();
			board.chessPoints[x][y].setPiece(piece, board);
			validate();
			repaint();
		}
	}


	private void initButtons() {
		Dimension iconSize = new Dimension(16, 16);
		prev = new JButton(ChessUtil.getImageIcon("prev.gif"));
		prev.addActionListener(this);
		prev.setToolTipText("����֧է��է��ڧ� �ާѧܧ֧�");
		prev.setCursor(new Cursor(Cursor.HAND_CURSOR));
		prev.setPreferredSize(iconSize);

		next = new JButton(ChessUtil.getImageIcon("next.gif"));
		next.addActionListener(this);
		next.setToolTipText("���ݧ֧է���ڧ� �ާѧܧ֧�");
		next.setCursor(new Cursor(Cursor.HAND_CURSOR));
		next.setPreferredSize(iconSize);

		first = new JButton(ChessUtil.getImageIcon("first.gif"));
		first.addActionListener(this);
		first.setToolTipText("���֧�ӧ��� �ާѧܧ֧�");
		first.setCursor(new Cursor(Cursor.HAND_CURSOR));
		first.setPreferredSize(iconSize);

		last = new JButton(ChessUtil.getImageIcon("last.gif"));
		last.addActionListener(this);
		last.setToolTipText("�����ݧ֧էߧڧ� �ާѧܧ֧�");
		last.setCursor(new Cursor(Cursor.HAND_CURSOR));
		last.setPreferredSize(iconSize);

		auto = new JButton(ChessUtil.getImageIcon("auto.gif"));
		auto.addActionListener(this);
		auto.setToolTipText("���ӧ��ާѧ�ڧ�֧�ܧѧ� ���֧٧֧ߧ�ѧ�ڧ�");
		auto.setPreferredSize(iconSize);
		auto.setCursor(new Cursor(Cursor.HAND_CURSOR));

		Insets insets = new Insets(1, 1, 1, 1);

		advancedSave = new JButton("���ѧ��ڧ�֧ߧߧ�� �����ѧߧ֧ߧڧ�",
				ChessUtil.getImageIcon("reprint.gif"));
		advancedSave.setToolTipText("���ѧ��ڧ�֧ߧߧ�� �����ѧߧ֧ߧڧ�");
		advancedSave.addActionListener(this);
		// reprint.setPreferredSize(dimension);
		advancedSave.setCursor(handCursor);
		advancedSave.setMargin(insets);

		save = new JButton("���ѧ���", ChessUtil.getImageIcon("save.gif"));
		save.addActionListener(this);
		save.setToolTipText("������ѧߧڧ�� �٧ѧ�ڧ�� �ڧԧ��");
		// save.setPreferredSize(dimension);
		save.setCursor(handCursor);
		save.setMargin(insets);

		empress = new JButton("���ѧܧ֧� N �ܧ���ݧ֧ӧ�", ChessUtil.getImageIcon("saveas.gif"));
		empress.addActionListener(this);
		empress.setToolTipText("���ѧܧ֧� N �ܧ���ݧ֧ӧ�");
		// saveAs.setPreferredSize(dimension);
		empress.setCursor(handCursor);
		empress.setMargin(insets);

		undo = new JButton("���ѧ�ާѧ�� ���اѧݧ֧ߧڧ�", ChessUtil.getImageIcon("undo.gif"));
		undo.addActionListener(this);
		undo.setToolTipText("���ѧ�ާѧ�� ���اѧݧ֧ߧڧ�");
		undo.setCursor(handCursor);
		undo.setMargin(insets);

		set = new JButton("���ѧ����ڧ��", ChessUtil.getImageIcon("welcome.gif"));
		set.setToolTipText("���ѧ����ڧ��");
		set.addActionListener(this);
		set.setCursor(handCursor);
		set.setMargin(insets);

		help = new JButton("����ާ�ԧڧ��", ChessUtil.getImageIcon("help.gif"));
		help.setToolTipText("����ާ�ԧڧ��");
		help.addActionListener(this);
		help.setCursor(handCursor);
		help.setMargin(insets);

		exit = new JButton("�ӧ��ҧ��ӧѧ��", ChessUtil.getImageIcon("stop.gif"));
		exit.setToolTipText("�ӧ��ҧ��ӧѧ��");
		exit.addActionListener(this);
		exit.setCursor(handCursor);
		exit.setMargin(insets);

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		if (source == save) {
			int size = lists.size();
			if (size == 0) {
				JOptionPane.showMessageDialog(this, "���ڧܧѧܧ�� �ާѧܧ֧� �����ѧߧڧ�� �ߧ֧ݧ�٧�!");
				return;
			}
			JFileChooser fileChooser = new JFileChooser();
			int state = fileChooser.showSaveDialog(null);
			File saveFile = fileChooser.getSelectedFile();
			if (saveFile != null && state == JFileChooser.APPROVE_OPTION) {
				System.out.println(saveFile.getAbsolutePath());
				EmpressUtil.save(saveFile.getAbsolutePath() + ".txt", lists);
			}

		} else if (source == advancedSave) {
			int size = advancedLists.size();
			if (size == 0) {
				JOptionPane.showMessageDialog(this, "���ڧܧѧܧ�� �ާѧܧ֧� �����ѧߧڧ�� �ߧ֧ݧ�٧�!");
				return;
			}

			// EightEmpressUtil.advancedSave(advancedLists);
			JFileChooser fileChooser = new JFileChooser();
			int state = fileChooser.showSaveDialog(null);
			File saveFile = fileChooser.getSelectedFile();
			if (saveFile != null && state == JFileChooser.APPROVE_OPTION) {
				System.out.println(saveFile.getAbsolutePath());

				EmpressUtil.advancedSave(saveFile.getAbsolutePath() + ".txt",
						advancedLists);
			}

		} else if (source == empress) {
			String number = numField.getText();
			int n = 3;
			try {
				n = Integer.valueOf(number);
				if (n < 1 || n > 9) {
					JOptionPane
							.showMessageDialog(this, "�� ���اѧݧ֧ߧڧ�, ��֧�ڧ�� �ާ�اߧ� ���ݧ�ܧ� ����ҧݧ֧ާ� �� N �ܧ���ݧ֧ӧ�ۣ�1<=N<=9��");
					return;
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			EmpressModel ee = new EmpressModel(n);
			ee.initAllLayout();
			lists = ee.getLists();
			advancedLists = ee.getAdvancedLists();
			int size = lists.size();

			descs.clear();
			for (int i = 0; i < size; i++) {
				descs.add("�ߧ�ާ֧�" + i + "�ާѧܧ֧�");
			}
			manual.setListData(descs);

		} else if (source == exit) {
			dispose();
		} else if (source == first) {
			first();
		} else if (source == next) {
			next();
		} else if (source == prev) {
			prev();
		} else if (source == last) {
			last();
		} else if (source == auto) {
			auto();
		}

	}


	private void auto() {
		if (autoThread == null) {
			autoThread = new Thread(this);
		}
		autoThread.start();
	}


	private void last() {
		curIndex = lists.size() - 1;
		displayLayout(curIndex);
		scrollToView();
	}


	private void first() {
		curIndex = 0;
		displayLayout(curIndex);
		scrollToView();
	}

	private void prev() {
		if (curIndex >= 0) {
			displayLayout(curIndex--);
			scrollToView();
		}

	}

	private void next() {
		if (curIndex < lists.size()) {
			displayLayout(curIndex++);
			scrollToView();
		}
	}

	private void handleExitGame() {
		if (board.getWinkThread() != null) {
			board.getWinkThread().interrupt();
			System.out.println("�ر��У�");
		}
		dispose();
	}

	private void scrollToView() {
		if (curIndex >= 0 && curIndex < lists.size()) {
			int lastIndex = curIndex;
			Rectangle rect = manual.getCellBounds(lastIndex, lastIndex);
			manualScroll.getViewport().scrollRectToVisible(rect);
			manual.setSelectedIndex(curIndex);
			validate();
			repaint();
		}

	}


	public static void main(String[] args) {
		EmpressGUI empress = new EmpressGUI();
		empress.setVisible(true);
	}

	public void run() {
		while (curIndex >= -1 && curIndex < lists.size()) {
			next();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}

}
