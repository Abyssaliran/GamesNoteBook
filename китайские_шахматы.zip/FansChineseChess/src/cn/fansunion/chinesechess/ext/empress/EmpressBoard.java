
package cn.fansunion.chinesechess.ext.empress;

import java.awt.Color;
import java.awt.event.MouseAdapter;

import cn.fansunion.chinesechess.ColorUtil;
import cn.fansunion.chinesechess.core.ChessBoard;



public class EmpressBoard extends ChessBoard {

	private static final long serialVersionUID = 4499247593357571375L;

	@Override
	protected Color getBackgroundColor() {
		return ColorUtil.getEmpressBgcolor();
	}

	@Override
	protected MouseAdapter getMouseAdapter() {
		return null;
	}

	@Override
	protected BoardType getBoardType() {
		return BoardType.eightEmpress;
	}

}
