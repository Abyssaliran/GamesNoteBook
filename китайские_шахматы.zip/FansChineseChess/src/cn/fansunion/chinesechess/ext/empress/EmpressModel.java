
package cn.fansunion.chinesechess.ext.empress;

import java.awt.Point;
import java.util.ArrayList;


public class EmpressModel {

	private int num;

	private int[][] array;

	private ArrayList<ArrayList<Point>> lists = new ArrayList<ArrayList<Point>>();

	private ArrayList<int[][]> advancedLists = new ArrayList<int[][]>();

	public EmpressModel(int n) {
		this.num = n;
		array = new int[n + 1][n + 1];// ���� ��ާ�ݧ�ѧߧڧ� 0
	}


	public void initAllLayout() {
		trial(1);
		sort();
		initAdvancedLists();
	}


	private void trial(int j) {

		if (j > num) {

			saveCurrentLayout();
		} else {
			for (int i = 1; i <= num; i++) {

				array[i][j] = 1;
				if (isLegal(i, j)) {
					trial(j + 1);
				}

				array[i][j] = 0;
			}
		}
	}


	private boolean isLegal(int row, int col) {
	
		for (int i = 1; i < array.length; i++) {
			int sumI = 0;
			int sumJ = 0;
			for (int j = 1; j < array[i].length; j++) {
				sumI += array[i][j];
				sumJ += array[j][i];
			}
			if (sumI >= 2 || sumJ >= 2) {
				return false;
			}
			sumI = 0;
			sumJ = 0;

		}
		

		int i = row - 1;
		for (int j = col - 1; j >= 1; j--) {
			if (i >= 1 && array[i][j] == 1) {
				return false;
			}
			i--;
		}


		i = row + 1;
		for (int j = col - 1; j >= 1; j--) {
			if (i <= this.num && array[i][j] == 1) {
				return false;
			}
			i++;
		}

		return true;
	}


	private void saveCurrentLayout() {
		ArrayList<Point> list = new ArrayList<Point>();
		for (int i = 1; i < array.length; i++) {
			for (int j = 1; j < array[i].length; j++) {
				if (array[i][j] == 1) {
					list.add(new Point(i, j));
				}
			}
		}
		lists.add(list);
	}

	public void printAllLayout() {
		int size = lists.size();
		for (int i = 0; i < size; i++) {
			ArrayList<Point> arrayList = lists.get(i);
			int size2 = arrayList.size();
			System.out.println("�ߧ�ާ֧�" + i + "�ާѧܧ֧䣡");
			for (int j = 0; j < size2; j++) {
				Point point = arrayList.get(j);
				System.out.print("(" + (int) point.getX() + ","
						+ (int) point.getY() + ")\t");
			}
			System.out.println();
		}
		System.out.println();
	}

	public void printAddLayout2() {
		int size = advancedLists.size();
		for (int i = 0; i < size; i++) {
			int[][] arr = advancedLists.get(i);
			System.out.println("�ߧ�ާ֧�" + i + "�ާѧܧ֧䣡");
			for (int j = 1; j <= num; j++) {
				for (int k = 1; k <= num; k++) {
					System.out.print(arr[j][k] + "\t");
				}
				System.out.println();
			}
			System.out.println();
		}
		System.out.println();
	}


	public void sort() {
		sortEveryList();
	}

	private void sortEveryList() {

		int size = lists.size();

		for (int q = 0; q < size; q++) {

			ArrayList<Point> arraylist = lists.get(q);

			int size2 = arraylist.size();

			for (int r = 1; r < size2; r++) {

				for (int s = 0; s < size2 - r; s++) {
					Point first = arraylist.get(s);
					double m = first.getY();

					Point second = arraylist.get(s + 1);
					double n = second.getY();

					if (m > n) {
						arraylist.set(s + 1, first);
						arraylist.set(s, second);
					}

				}
			}
		}

	}


	public static void main(String[] args) {
		EmpressModel ek4 = new EmpressModel(4);
		ek4.initAllLayout();

		ek4.printAllLayout();

		ek4.initAdvancedLists();
		ek4.printAddLayout2();

		/*
		 * EightKing ek4 = new EightKing(4); ek4.trial(0);
		 * 
		 * EightKing ek8 = new EightKing(8); ek8.trial(0);
		 */
	}

	public ArrayList<int[][]> getAdvancedLists() {
		return advancedLists;
	}

	private void initAdvancedLists() {
		int size = lists.size();
		for (int index = 0; index < size; index++) {
			ArrayList<Point> list = lists.get(index);
			int[][] arr = new int[num + 1][num + 1];

			int len = list.size();
			for (int i = 0; i < len; i++) {
				int x = (int) list.get(i).getY();
				int y = (int) list.get(i).getX();
				arr[x][y] = 1;
			}

			advancedLists.add(arr);
		}
	}

	public int[][] getArray() {
		return array;
	}

	public int getNum() {
		return num;
	}

	public ArrayList<ArrayList<Point>> getLists() {
		return lists;
	}

}
