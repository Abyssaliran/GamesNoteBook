
package cn.fansunion.chinesechess.load;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.HelpDialog;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ManualItem;
import cn.fansunion.chinesechess.core.ManualUtil;
import cn.fansunion.chinesechess.core.MoveStep;
import cn.fansunion.chinesechess.core.PieceUtil;
import cn.fansunion.chinesechess.core.ChessPiece.PieceId;
import cn.fansunion.chinesechess.net.client.NetworkBoard;
import cn.fansunion.chinesechess.print.part.Position;
import cn.fansunion.chinesechess.save.GameRecord;
import cn.fansunion.chinesechess.save.ISaveManual;
import cn.fansunion.chinesechess.save.SaveAsDialog;
import cn.fansunion.chinesechess.save.SaveDialog;
import cn.fansunion.chinesechess.save.GameRecord.ManualType;



public class ChessDemoGUI extends JFrame implements ActionListener, NAME,
		ISaveManual {

	private static final long serialVersionUID = 266L;

	private JMenu fileMenu, manualMenu, settingMenu, helpMenu;

	private JMenuItem openManual, saveManual, saveManualAs, exitGame,
			openMainGUI;

	private JMenuItem firstMenuItem, prevMenuItem, autoMenuItem, nextMenuItem,
			lastMenuItem, manualListMenuItem;

	private JMenuItem setting, helpContent, aboutGame, welcome;

	private JCheckBoxMenuItem bgSound;


	private JButton prev, next, auto, first, last;


	private JButton read, save, saveAs, set, manualList;


	private JTextArea area;

	private JPanel toolBar = new JPanel();


	private int curIndex = -1;


	private NetworkBoard board;


	private JList manual;


	private JScrollPane manualScroll;


	private int time = 1000;

	private GameRecord gameRecord;


	public ChessDemoGUI(GameRecord gameRecord) {
		this.gameRecord = gameRecord;
		board = new NetworkBoard();
		initMenuBar();
		initButtons();
		initPanels();
		initPieces();
		initGui();

		board.myTurn = false;
	}

	private void initGui() {
		setSize(660, 620);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setIconImage(ChessUtil.getAppIcon());
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}


	private void initMenuBar() {

		JMenuBar bar = new JMenuBar();


		fileMenu = new JMenu("��ѧۧ�(G)");

		openManual = new JMenuItem("���ڧ�ѧ��", ChessUtil.getImageIcon("open.gif"));
		saveManual = new JMenuItem("���ѧ���", ChessUtil.getImageIcon("save.gif"));
		saveManualAs = new JMenuItem("������ѧߧڧ�� �ܧѧ�", ChessUtil.getImageIcon("saveas.gif"));
		exitGame = new JMenuItem("�ӧ��ҧ��ӧѧ��", ChessUtil.getImageIcon("exit.gif"));
		openMainGUI = new JMenuItem("���ݧѧӧߧ��� �ڧߧ�֧��֧ۧ�", ChessUtil
				.getImageIcon("mainGUI.gif"));
		fileMenu.add(openManual);
		fileMenu.add(saveManual);
		fileMenu.add(saveManualAs);
		fileMenu.add(exitGame);
		fileMenu.add(openMainGUI);


		manualMenu = new JMenu("���ѧ�ާѧ�ߧ��� ��֧ܧ���(M)");
		firstMenuItem = new JMenuItem("��֧�ӧ��� ��ѧ�", ChessUtil
				.getImageIcon("first.gif"));
		prevMenuItem = new JMenuItem("����֧է��է��ڧ�", ChessUtil.getImageIcon("prev.gif"));
		autoMenuItem = new JMenuItem("���ӧ��ާѧ�ڧ�֧�ܧѧ� ���֧٧֧ߧ�ѧ�ڧ�", ChessUtil.getImageIcon("auto.gif"));
		nextMenuItem = new JMenuItem("���ݧ֧է���ڧ� ��ѧ�", ChessUtil.getImageIcon("next.gif"));
		lastMenuItem = new JMenuItem("����ݧ֧էߧڧ� ��ѧ�", ChessUtil.getImageIcon("last.gif"));
		manualListMenuItem = new JMenuItem("����ڧ��� ��ѧ�ާѧ�", ChessUtil
				.getImageIcon("manualList.gif"));


		manualMenu.add(firstMenuItem);

		manualMenu.add(prevMenuItem);
		manualMenu.add(autoMenuItem);
		manualMenu.add(nextMenuItem);
		manualMenu.add(lastMenuItem);
		manualMenu.add(manualListMenuItem);


		helpMenu = new JMenu("����ާ�ԧڧ��(H)");
		welcome = new JMenuItem("�է�ҧ�� ���اѧݧ�ӧѧ��", ChessUtil.getImageIcon("welcome.gif"));
		helpContent = new JMenuItem("����է֧�اѧߧڧ� ����ѧӧܧ�", ChessUtil.getImageIcon("help.gif"));
		aboutGame = new JMenuItem("�� �ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ�ѧ�", ChessUtil.getImageIcon("info.gif"));

		helpMenu.add(welcome);
		helpMenu.add(helpContent);
		helpMenu.add(aboutGame);


		settingMenu = new JMenu("���ѧ����ڧ��(S)");

		setting = new JMenuItem("���ҧ�ڧ� �ߧѧ����ۧܧ�");
		bgSound = new JCheckBoxMenuItem("����ߧ�ӧѧ� �ާ�٧��ܧ�");
		bgSound.setSelected(true);

		settingMenu.add(bgSound);
		settingMenu.add(setting);


		bar.add(fileMenu);
		bar.add(manualMenu);
		bar.add(settingMenu);
		bar.add(helpMenu);

		setJMenuBar(bar);


		openManual.setAccelerator(KeyStroke.getKeyStroke('N',
				InputEvent.CTRL_DOWN_MASK));
		saveManual.setAccelerator(KeyStroke.getKeyStroke('S',
				InputEvent.CTRL_DOWN_MASK));
		saveManualAs.setAccelerator(KeyStroke.getKeyStroke('U',
				InputEvent.CTRL_DOWN_MASK));

		exitGame.setAccelerator(KeyStroke.getKeyStroke('E',
				InputEvent.CTRL_DOWN_MASK));
		openMainGUI.setAccelerator(KeyStroke.getKeyStroke('M',
				InputEvent.CTRL_DOWN_MASK));

		firstMenuItem.setAccelerator(KeyStroke.getKeyStroke('Y',
				InputEvent.CTRL_DOWN_MASK));
		prevMenuItem.setAccelerator(KeyStroke.getKeyStroke('P',
				InputEvent.CTRL_DOWN_MASK));
		autoMenuItem.setAccelerator(KeyStroke.getKeyStroke('U',
				InputEvent.CTRL_DOWN_MASK));
		nextMenuItem.setAccelerator(KeyStroke.getKeyStroke('N',
				InputEvent.CTRL_DOWN_MASK));
		lastMenuItem.setAccelerator(KeyStroke.getKeyStroke('L',
				InputEvent.CTRL_DOWN_MASK));
		manualListMenuItem.setAccelerator(KeyStroke.getKeyStroke('M',
				InputEvent.CTRL_DOWN_MASK));

		welcome.setAccelerator(KeyStroke.getKeyStroke('W',
				InputEvent.CTRL_DOWN_MASK));
		helpContent.setAccelerator(KeyStroke.getKeyStroke('H',
				InputEvent.CTRL_DOWN_MASK));
		aboutGame.setAccelerator(KeyStroke.getKeyStroke('A',
				InputEvent.CTRL_DOWN_MASK));

		bgSound.setAccelerator(KeyStroke.getKeyStroke('B',
				InputEvent.CTRL_DOWN_MASK));
		setting.setAccelerator(KeyStroke.getKeyStroke('T',
				InputEvent.CTRL_DOWN_MASK));


		fileMenu.setMnemonic(KeyEvent.VK_G);
		manualMenu.setMnemonic(KeyEvent.VK_M);
		settingMenu.setMnemonic(KeyEvent.VK_S);
		helpMenu.setMnemonic(KeyEvent.VK_H);

		openManual.addActionListener(this);
		saveManual.addActionListener(this);
		saveManualAs.addActionListener(this);
		exitGame.addActionListener(this);
		openMainGUI.addActionListener(this);

		nextMenuItem.addActionListener(this);
		prevMenuItem.addActionListener(this);
		lastMenuItem.addActionListener(this);

		setting.addActionListener(this);
		bgSound.addActionListener(this);

		welcome.addActionListener(this);
		helpContent.addActionListener(this);
		aboutGame.addActionListener(this);

		setJMenuBar(bar);
	}


	private void initPanels() {

		JPanel rightPanel = new JPanel(new BorderLayout());


		JPanel recordsPanel = new JPanel(new BorderLayout());

		TitledBorder recordsBorder = new TitledBorder(PropertyReader
				.get("CHESS_MESSAGE_TOOLTIP"));
		recordsPanel.setBorder(recordsBorder);

		manual = new JList(gameRecord.getDescs());
		manual.setFont(new Font("����", Font.PLAIN, 16));
		manual.setToolTipText(PropertyReader.get("CHESS_MESSAGE_TOOLTIP"));
		manual.setVisibleRowCount(16);
		manual.setAutoscrolls(true);


		manual.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int count = e.getClickCount();
				if (count == 1 || count == 2) {
					int index = manual.getSelectedIndex();
					int n = Math.abs(index - curIndex);
					if (index > curIndex) {
						for (int i = 0; i < n; i++) {
							next();
						}
					} else if (curIndex > index) {
						for (int i = 0; i < n; i++) {
							prev();
						}
					}
				}
			}
		});

		manualScroll = new JScrollPane(manual);
		recordsPanel.setPreferredSize(new Dimension(240, 340));
		recordsPanel.add(BorderLayout.CENTER, manualScroll);


		JPanel manualTools = new JPanel(new FlowLayout(FlowLayout.CENTER));
		manualTools.add(first);
		manualTools.add(prev);
		manualTools.add(auto);
		manualTools.add(next);
		manualTools.add(last);
		recordsPanel.add(BorderLayout.SOUTH, manualTools);


		FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
		toolBar.setLayout(layout);
		toolBar.add(read);
		toolBar.add(save);
		toolBar.add(saveAs);
		toolBar.add(set);
		toolBar.add(manualList);


		JPanel descPanel = new JPanel();
		area = new JTextArea(gameRecord.getDateAndTime() + "\n"
				+ gameRecord.getDesc());

		area.setPreferredSize(new Dimension(170, 140));
		JScrollPane scroll = new JScrollPane(area);
		descPanel.setPreferredSize(new Dimension(200, 170));
		descPanel.add(scroll);
		rightPanel.add(BorderLayout.NORTH, recordsPanel);
		rightPanel.add(BorderLayout.CENTER, descPanel);


		JSplitPane splitH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, board,
				rightPanel);
		splitH.setDividerSize(5);
		splitH.setDividerLocation(450);

		add(BorderLayout.CENTER, splitH);
		add(BorderLayout.NORTH, toolBar);
	}


	private void initButtons() {
		Dimension iconSize = new Dimension(16, 16);
		prev = new JButton(ChessUtil.getImageIcon("prev.gif"));
		prev.addActionListener(this);
		prev.setToolTipText("����֧է��է��ڧ�");
		prev.setCursor(new Cursor(Cursor.HAND_CURSOR));
		prev.setPreferredSize(iconSize);

		next = new JButton(ChessUtil.getImageIcon("next.gif"));
		next.addActionListener(this);
		next.setToolTipText("���ݧ֧է���ڧ� ��ѧ�");
		next.setCursor(new Cursor(Cursor.HAND_CURSOR));
		next.setPreferredSize(iconSize);

		first = new JButton(ChessUtil.getImageIcon("first.gif"));
		first.addActionListener(this);
		first.setToolTipText("��֧�ӧ��� ��ѧ�");
		first.setCursor(new Cursor(Cursor.HAND_CURSOR));
		first.setPreferredSize(iconSize);

		last = new JButton(ChessUtil.getImageIcon("last.gif"));
		last.addActionListener(this);
		last.setToolTipText("����ݧ֧էߧڧ� ��ѧ�");
		last.setCursor(new Cursor(Cursor.HAND_CURSOR));
		last.setPreferredSize(iconSize);

		auto = new JButton(ChessUtil.getImageIcon("auto.gif"));
		auto.addActionListener(this);
		auto.setToolTipText("���ӧ��ާѧ�ڧ�֧�ܧѧ� ���֧٧֧ߧ�ѧ�ڧ�");
		auto.setPreferredSize(iconSize);
		auto.setCursor(new Cursor(Cursor.HAND_CURSOR));

		Insets insets = new Insets(1, 1, 1, 1);

		read = new JButton(ChessUtil.getImageIcon("open.gif"));
		read.setToolTipText("���ڧ�ѧ��");
		read.addActionListener(this);
		read.setCursor(new Cursor(Cursor.HAND_CURSOR));
		read.setMargin(insets);

		saveAs = new JButton(ChessUtil.getImageIcon("saveas.gif"));
		saveAs.setToolTipText("������ѧߧڧ�� �ܧѧ�");
		saveAs.addActionListener(this);
		saveAs.setCursor(new Cursor(Cursor.HAND_CURSOR));
		saveAs.setMargin(insets);

		save = new JButton(ChessUtil.getImageIcon("save.gif"));
		save.setToolTipText("���ѧ���");
		save.addActionListener(this);
		save.setCursor(new Cursor(Cursor.HAND_CURSOR));
		save.setMargin(insets);

		set = new JButton(ChessUtil.getImageIcon("welcome.gif"));
		set.setToolTipText("���ѧ����ڧ��");
		set.addActionListener(this);
		set.setCursor(new Cursor(Cursor.HAND_CURSOR));
		set.setMargin(insets);

		manualList = new JButton(ChessUtil.getImageIcon("manualList.gif"));
		manualList.setToolTipText("���֧�ߧ����� �� ���ڧ�ܧ� ��ѧ�ާѧ�ߧ��� ��֧ܧ��է��");
		manualList.addActionListener(this);
		manualList.setCursor(new Cursor(Cursor.HAND_CURSOR));
		manualList.setMargin(insets);

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();


		if (source == next) {
			next();

		}

		else if (source == prev) {
			prev();
		}

		else if (source == first) {
			while (curIndex != -1) {
				prev();
			}
		}

		else if (source == last) {
			while (curIndex != gameRecord.getDescs().size() - 1) {
				next();
			}
		}

		else if (source == exitGame) {
			dispose();
		}

		else if (source == auto) {
			DemoThread auto = new DemoThread();
			auto.start();
		}

		else if (source == helpContent) {
			HelpDialog help = new HelpDialog();
			help.setVisible(true);
		}

		else if (source == set) {

		}

		else if (source == save) {
			SaveDialog dialog = new SaveDialog(this);
			dialog.setVisible(true);
		}


		else if (source == saveAs) {
			SaveAsDialog dialog = new SaveAsDialog(this);
			dialog.setVisible(true);
		}


		else if (source == read) {
			read();
		} else if (source == manualList) {
			dispose();
			ChessLoadingGUI loading = new ChessLoadingGUI();
			loading.setVisible(true);
		}

	}


	@SuppressWarnings("unchecked")
	private void read() {
		JFileChooser fileChooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				EXTENSION_NAME2, EXTENSION_NAME2);
		fileChooser.setFileFilter(filter);

		int state = fileChooser.showOpenDialog(this);
		File openFile = fileChooser.getSelectedFile();
		if (openFile != null && state == JFileChooser.APPROVE_OPTION) {


			GameRecord gameRecord = ManualUtil.readManual(openFile);

			ChessDemoGUI demo = new ChessDemoGUI(gameRecord);

			demo.setVisible(true);
			dispose();

		}

	}


	private void next() {
		if (curIndex == gameRecord.getDescs().size() - 1) {
			return;
		}
		curIndex++;
		if (curIndex < gameRecord.getRecords().size()) {
			step(curIndex);
		}
		scrollToView();
	}


	public void step(int index) {
		ManualItem moveRecord = gameRecord.getRecords().get(index);
		MoveStep step = moveRecord.getMoveStep();
		Point pStart = step.start;
		Point pEnd = step.end;
		int startI = pStart.x;
		int startJ = pStart.y;
		int endI = pEnd.x;
		int endJ = pEnd.y;


		board.setMoveFlag(true);
		board.movePoints[0] = new Point(endI, endJ);
		board.movePoints[1] = new Point(startI, startJ);

		ChessPiece piece = (board.chessPoints)[startI][startJ].getPiece();
		if ((board.chessPoints)[endI][endJ].hasPiece()) {
			ChessPiece pieceRemoved = (board.chessPoints)[endI][endJ]
					.getPiece();
			board.remove(pieceRemoved);
			board.chessPoints[endI][endJ].setPiece(piece, board);
			board.chessPoints[startI][startJ].setHasPiece(false);
		} else {
			board.chessPoints[endI][endJ].setPiece(piece, board);
			board.chessPoints[startI][startJ].setHasPiece(false);
		}

		board.myTurn = false;
		board.repaint();
		repaint();
		validate();
	}



	private void prev() {
		if (curIndex == -1) {
			return;
		}

		int size = gameRecord.getRecords().size();


		ManualItem record = new ManualItem();
		MoveStep moveStep;

		ChessPiece eatedPiece;
		int startI = 0;
		int startJ = 0;
		int endI = 0;
		int endJ = 0;

		if (size > 0 && curIndex < size && curIndex >= 0) {

			record = (ManualItem) gameRecord.getRecords().get(curIndex);
			eatedPiece = PieceUtil.createPiece(record.getEatedPieceId());

			moveStep = record.getMoveStep();
			startI = moveStep.start.x;
			startJ = moveStep.start.y;
			endI = moveStep.end.x;
			endJ = moveStep.end.y;


			if (eatedPiece == null) {
				ChessPiece piece = board.chessPoints[endI][endJ].getPiece();
				board.chessPoints[startI][startJ].setPiece(piece, board);
				(board.chessPoints[endI][endJ]).setHasPiece(false);

			}

			else {
				ChessPiece piece = board.chessPoints[endI][endJ].getPiece();
				board.chessPoints[startI][startJ].setPiece(piece, board);

				board.chessPoints[endI][endJ].setPiece(eatedPiece, board);
				(board.chessPoints[endI][endJ]).setHasPiece(true);

			}
		}


		if (curIndex >= 1) {
			record = (ManualItem) gameRecord.getRecords().get(curIndex - 1);
			moveStep = record.getMoveStep();
			startI = moveStep.start.x;
			startJ = moveStep.start.y;
			endI = moveStep.end.x;
			endJ = moveStep.end.y;
		}

		board.setMoveFlag(true);
		board.movePoints[0] = new Point((int) (board.chessPoints[endI][endJ]
				.getX()), (int) (board.chessPoints[endI][endJ].getY()));
		board.movePoints[1] = new Point(
				(int) (board.chessPoints[startI][startJ].getX()),
				(int) (board.chessPoints[startI][startJ].getY()));

		curIndex--;

		scrollToView();
		if (curIndex == -1) {

			board.setMoveFlag(false);

			manual.setListData(gameRecord.getDescs());
		}

		board.repaint();
	}

	private void scrollToView() {
		if (curIndex >= 0 && curIndex < gameRecord.getDescs().size()) {
			int lastIndex = curIndex;
			Rectangle rect = manual.getCellBounds(lastIndex, lastIndex);
			manualScroll.getViewport().scrollRectToVisible(rect);

			manual.setSelectedIndex(curIndex);
		}

	}


	private void initPieces() {
		ManualType flag = gameRecord.getFlag();
		if (flag == ManualType.NETWORK_RED
				|| flag == ManualType.NETWORK_JUDGEMENT
				|| flag == ManualType.PRINT_WHOLE) {
			board.initChess(true);
		} else if (flag == ManualType.NETWORK_BLACK) {
			board.initChess(false);
		} else if (flag == ManualType.PRINT_PARTIAL) {
			int size = gameRecord.getInitLocations().size();
			System.out.println("����ݧڧ�֧��ӧ� ��ѧ�ާѧ�ߧ��� ��ڧԧ�� ���� �ڧߧڧ�ڧѧݧڧ٧ѧ�ڧڣ�" + size);
			board.setPlayerName("����ѧ�ߧѧ� �ӧ֧�֧�ڧߧܧ�");
			for (int i = 0; i < size; i++) {
				Position location = gameRecord.getInitLocations().get(i);
				if (location != null) {
					PieceId id = location.getId();
					int x = (int) location.getPoint().getX();
					int y = (int) location.getPoint().getY();

					ChessPiece piece = PieceUtil.createPiece(id);
					board.chessPoints[x][y].setPiece(piece, board);
				}

			}
		}

		board.validate();
		board.repaint();
	}


	private class DemoThread extends Thread {


		public DemoThread() {
			System.out.println("��������֧ߧڧ� �ѧӧ��ާѧ�ڧ�֧�ܧ�ԧ� �է֧ާ�ߧ���ѧ�ڧ�ߧߧ�ԧ� �����ܧ� �٧ѧӧ֧��֧ߧ�.");
		}


		public void run() {
			System.out.println("���ӧ��ާѧ�ڧ�֧�ܧѧ� ���֧٧֧ߧ�ѧ�ڧ� ��ܧ��� �ҧ�է֧� �٧ѧ���֧ߧ�");
			int size = gameRecord.getRecords().size();


			while (curIndex < size - 1) {
				try {
					Thread.sleep(time);

					next();
					if (curIndex >= size - 1) {
						this.join(100);
						break;
					}
				} catch (InterruptedException ie) {
					break;
				}
			}
		}
	}



	public ArrayList<String> getSavePaths() {
		ArrayList<String> paths = new ArrayList<String>();
		String path = "";
		String descsPath = "";

		URL url = ChessUtil.class.getResource("");
		if (url == null) {
			return null;

		}
		ManualType flag = gameRecord.getFlag();
		if (flag == ManualType.NETWORK_RED || flag == ManualType.NETWORK_BLACK
				|| flag == ManualType.NETWORK_OBSERVER
				|| flag == ManualType.NETWORK_JUDGEMENT) {
			path = url.getPath() + "manual/";
			descsPath = url.getPath() + "manualdesc/";
		} else if (flag == ManualType.PRINT_WHOLE) {
			path = url.getPath() + "manual/whole/";
			descsPath = url.getPath() + "manualdesc/whole/";
		} else if (flag == ManualType.PRINT_PARTIAL) {
			path = url.getPath() + "manual/partial/";
			descsPath = url.getPath() + "manualdesc/partial/";
		}
		paths.add(path);
		paths.add(descsPath);
		return paths;
	}


	public GameRecord getGameRecord() {
		return gameRecord;
	}
}
