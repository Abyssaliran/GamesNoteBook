
package cn.fansunion.chinesechess.load;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.border.Border;


public class IconListItemRenderer extends JLabel implements ListCellRenderer {

	private static final long serialVersionUID = 1L;


	private Border selectedBorder = BorderFactory.createLineBorder(Color.blue,
			1);


	private Border emptyBorder = BorderFactory.createEmptyBorder(1, 1, 1, 1);

	public IconListItemRenderer() {
		setOpaque(true);

	}

	public Component getListCellRendererComponent(JList list, Object value,
			int index, boolean isSelected, boolean cellHasFocus) {

		IconListItem item = (IconListItem) value;
		this.setIcon(item.getIcon());
		this.setText(item.getText());

		Color background;
		// Color foreground;

		if (isSelected) {
			setBorder(selectedBorder);
			background = new Color(212, 219, 238);
		} else {
			setBorder(emptyBorder);
			background = Color.WHITE;
		}


		setBackground(background);
		return this;
	}
}
