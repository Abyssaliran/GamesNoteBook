
package cn.fansunion.chinesechess.load;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ManualUtil;
import cn.fansunion.chinesechess.save.GameRecord;
import cn.fansunion.chinesechess.save.GameRecord.ManualType;



public class ChessLoadingGUI extends JFrame implements ActionListener, NAME {
	private static final long serialVersionUID = 121L;


	private JButton load, exit;


	private JList manualList;


	private DefaultListModel listModel = new DefaultListModel();


	private ArrayList<GameRecord> chessRecords = new ArrayList<GameRecord>();


	private JTextArea descArea;

	private File curFile;


	private File topFile;


	public ChessLoadingGUI() {
		initList();
		initButtons();
		initPanels();
		showGUI();
	}


	private void showGUI() {
		setSize(680, 650);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setResizable(false);
		setLocationRelativeTo(null);
		setIconImage(ChessUtil.getAppIcon());
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);


		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}
		});

	}


	@SuppressWarnings("unchecked")
	private void initList() {
		manualList = new JList();

		manualList.setCellRenderer(new IconListItemRenderer());
		manualList.setModel(listModel);

		curFile = new File("manuals");
		topFile = curFile;
		updateListData();

	}


	private void initPanels() {
		JPanel leftPanel = new JPanel();
		TitledBorder manualBorder = new TitledBorder("����ڧ��� ��ѧ�ާѧ�");
		leftPanel.setBorder(manualBorder);

		manualList.setFont(new Font("����", Font.PLAIN, 16));
		manualList.setToolTipText(PropertyReader.get("CHESS_MESSAGE_TOOLTIP"));
		manualList.setVisibleRowCount(10);
		manualList.setAutoscrolls(true);


		manualList.addMouseListener(new MouseAdapter() {

			String name = "";


			boolean isDir = false;


			boolean isFile = false;

			public void mouseClicked(MouseEvent e) {
				int count = e.getClickCount();

				System.out.println("���֧ܧ��ڧ� �����" + curFile.getAbsolutePath());

				if (count == 1) {
					int index = manualList.getSelectedIndex();
					if (index != -1) {
						IconListItem item = (IconListItem) manualList
								.getSelectedValue();
						if (item != null) {
							name = item.getText();
						}
						System.out.println("���ާ� ��֧ܧ��֧� ����ڧ�::" + name + "\n");
					}

					File dirFile = new File(curFile, name);
					System.out.println("����� ����֧��ӧ�֧䣿" + dirFile.exists());
					if (dirFile.exists()) {

						if (dirFile.isDirectory()) {
							isDir = true;
							isFile = false;
							descArea.setText("����� �ܧѧ�ѧݧ��");
							System.out.println("���֧ݧܧߧ�� �ܧѧ�ѧݧ��" + name);
						}
					} else {
						dirFile = new File(curFile, name + EXTENSION_NAME);
						if (dirFile.isFile()) {
							isFile = true;
							isDir = false;
							GameRecord chessRecord = chessRecords.get(index);
							descArea.setText(chessRecord.getDateAndTime()
									+ "\n" + chessRecord.getDesc());

							System.out.println("���֧ݧܧߧ�� ��ѧۧ�" + name);
						} else {
							isFile = false;
							isDir = false;
							System.out.println("���ѧاѧ�" + name);
							descArea.setText("");

						}

					}

					if (isDir) {
						System.out.println("���ѧۧ� �ܧѧ�ѧݧ�ԧ� �ߧѧاѧ�");
					} else if (isFile) {
						System.out.println("���ѧۧ� �ߧѧاѧ�");

					} else if (name.equals("���֧�ߧ����� �ߧ� ���֧է��է��ڧ� ����ӧ֧ߧ�")) {
						System.out.println("���ѧاާڧ��, ����ҧ� �ӧ֧�ߧ����� �ߧ� ���֧է��է��ڧ� ����ӧ֧ߧ�");
					}
				}

				if (count == 2) {
					int index = manualList.getSelectedIndex();
					if (index != -1) {
						IconListItem item = (IconListItem) manualList
								.getSelectedValue();
						if (item != null) {
							name = item.getText();
						}
						System.out.println("���ާ� ��֧ܧ��֧� ����ڧ�::" + name + "\n");
					}

					File dirFile = new File(curFile, name);
					System.out.println("����� ����֧��ӧ�֧䣿" + dirFile.exists());
					if (dirFile.exists()) {

						if (dirFile.isDirectory()) {
							isDir = true;
							isFile = false;

							curFile = dirFile;
							System.out.println("���֧ܧ��ڧ� �ӧѧ�ڧѧߧ� - ���� �ܧѧ�ѧݧ��" + name);
						}
					} else {
						dirFile = new File(curFile, name + EXTENSION_NAME);
						if (dirFile.isFile()) {
							isFile = true;
							isDir = false;

							System.out.println("���֧ܧ��ڧ� �ӧѧ�ڧѧߧ� - ��ѧۧ�" + name);
						} else {
							isFile = false;
							isDir = false;
							System.out.println("���֧ܧ��ڧ� �ӧѧ�ڧѧߧ� - ���� �ߧ� ��ѧۧ� �� �ߧ� �ܧѧ�ѧݧ��" + name);

						}

					}

					if (isDir) {
						System.out.println("���ѧ�ѧݧ�� �� ��ѧۧݧ� ��ܧ��� �ҧ�է�� ��ҧߧ�ӧݧ֧ߧ�");
						updateListData();
					} else if (isFile) {
						System.out.println("���ѧԧ��٧ܧ� �ڧԧ��");
						load();
					} else if (name.equals("���֧�ߧ����� �ߧ� ���֧է��է��ڧ� ����ӧ֧ߧ�")) {
						String p = curFile.getParent();
						System.out.println("���֧�ߧ����� �� ���ڧ�ܧ�:" + p);
						chessRecords.clear();
						curFile = curFile.getParentFile();
						updateListData();
					}
				}
			}
		});

		JScrollPane listScroll = new JScrollPane(manualList);
		listScroll.setPreferredSize(new Dimension(400, 480));
		leftPanel.add(listScroll);


		JPanel rightPanel = new JPanel(new BorderLayout());


		JPanel descPanel = new JPanel();
		TitledBorder descBorder = new TitledBorder("����ڧ�ѧߧڧ� �ڧԧ��");
		descPanel.setBorder(descBorder);

		descArea = new JTextArea("���է֧�� �ҧ�է֧� ����ҧ�ѧاѧ���� ���ڧ�ѧ�֧ݧ�ߧѧ� �ڧߧ���ާѧ�ڧ� �٧ѧ�ڧ�� �ڧԧ��.");
		descArea.setPreferredSize(new Dimension(170, 400));
		descPanel.add(descArea);
		rightPanel.add(BorderLayout.CENTER, descPanel);

		JPanel controlPanel = new JPanel(new FlowLayout());
		controlPanel.add(load);
		controlPanel.add(exit);

		rightPanel.add(BorderLayout.SOUTH, controlPanel);

		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				leftPanel, rightPanel);
		split.setDividerSize(5);
		split.setDividerLocation(450);
		add(split, BorderLayout.CENTER);
	}


	private void initButtons() {
		int width = ChessUtil.getImageIcon("load.png").getIconWidth();
		int height = ChessUtil.getImageIcon("load.png").getIconHeight();


		load = new JButton(ChessUtil.getImageIcon("load.png"));
		load.setPreferredSize(new Dimension(width, height));
		load.setToolTipText(PropertyReader.get("LOAD_GAME_JBUTTON_TOOLTIP"));
		load.setCursor(new Cursor(Cursor.HAND_CURSOR));
		load.addActionListener(this);


		exit = new JButton(ChessUtil.getImageIcon("exit.png"));
		exit.setPreferredSize(new Dimension(width, height));
		exit.setToolTipText("�ӧ��ۧ�� �ڧ� �ڧԧ��");
		exit.addActionListener(this);
		exit.setCursor(new Cursor(Cursor.HAND_CURSOR));

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();


		if (source == load) {
			load();
		}

		else if (source == exit) {
			handleExitGame();
		}

	}


	private void load() {
		GameRecord chessRecord;

		if (manualList != null) {
			int index = manualList.getSelectedIndex();
			if (index != -1) {
				chessRecord = chessRecords.get(index);
				if (chessRecord == null) {
					JOptionPane.showMessageDialog(this, "�����ҧ�ѧߧߧ��� ��ѧۧ� �ߧ� ��ӧݧ�֧��� ��ѧۧݧ�� �٧ѧ�ڧ�� �ڧԧ����");
					return;
				}
			} else {
				JOptionPane.showMessageDialog(this, "���ѧ�ڧ�� �ڧԧ�� �ߧ� �ӧ��ҧ�ѧߧѣ�");
				return;
			}

			ChessDemoGUI demo = new ChessDemoGUI(chessRecord);
			demo.setVisible(true);
			dispose();
			validate();
			repaint();
		}

	}

	private void handleExitGame() {
		dispose();
	}


	public static void main(String[] args) {
		ChessLoadingGUI loading = new ChessLoadingGUI();
		loading.setVisible(true);
	}


	@SuppressWarnings("unchecked")
	private void updateListData() {


		File[] listFile = curFile.listFiles(new FileFilter() {

			public boolean accept(File file) {
				return file.getName().endsWith(EXTENSION_NAME);
			}
		});

		File[] listDir = curFile.listFiles(new FileFilter() {

			public boolean accept(File file) {
				return file.isDirectory();
			}
		});


		listModel.removeAllElements();


		if (!curFile.equals(topFile)) {

			IconListItem item = new IconListItem(ChessUtil
					.getImageIcon("open.gif"), "���֧�ߧ����� �ߧ� ���֧է��է��ڧ� ����ӧ֧ߧ�");
			listModel.addElement(item);


			chessRecords.clear();
			chessRecords.add(null);
		}


		if (listDir != null) {
			for (int i = 0; i < listDir.length; i++) {
				File oneFile = listDir[i];
				if (oneFile.exists() && oneFile.canRead()) {
					String name = oneFile.getName();
					IconListItem item = new IconListItem(ChessUtil
							.getImageIcon("open.gif"), name);
					listModel.addElement(item);
					chessRecords.add(null);
				}
			}

		} else {
			System.out.println("���֧� �ܧѧ�ѧݧ�ԧ�");
		}


		if (listFile != null) {
			for (int i = 0; i < listFile.length; i++) {
				File oneFile = listFile[i];
				if (oneFile.exists() && oneFile.canRead()) {
					String name = oneFile.getName();
					int index = name.indexOf('.');
					if (index != -1) {

						name = name.substring(0, index);
					}


					try {
						GameRecord chessRecord = ManualUtil.readManual(oneFile);
						if (chessRecord != null) {
							chessRecords.add(chessRecord);


							IconListItem item;
							if (chessRecord.getFlag() == ManualType.NETWORK_RED) {
								item = new IconListItem(ChessUtil
										.getImageIcon("heijiang.gif"), name);
							} else {
								item = new IconListItem(ChessUtil
										.getImageIcon("hongshuai.gif"), name);
							}

							listModel.addElement(item);
						}

					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}

		} else {
			System.out.println("���֧� ��ѧۧݧ�");
		}

		printManualRecord();

	}


	private void printManualRecord() {
		printXing();
		int size = chessRecords.size();
		for (int i = 0; i < size; i++) {
			GameRecord record = chessRecords.get(i);
			System.out.print("�ߧ�ާ֧�" + i + "������� �ݧ� �٧ѧ�ڧ�" + (record == null) + "\t");
			if (record == null) {
				break;
			}
			System.out.print("������ѧߧڧ�� �էѧ�壺" + record.getDateAndTime() + "\t");
			System.out.print("���ڧ� �ڧԧ��ӧ�� �٧ѧ�ڧ�ڣ�" + record.getFlag() + "\t");
			System.out.print("����ڧ�ѧ�֧ݧ�ߧѧ� �ڧߧ���ާѧ�ڧ� ��� �ڧԧ�֣�" + record.getDesc() + "\t");
		}
	}

	private void printXing() {
		System.out.println("**************************");
	}
}
