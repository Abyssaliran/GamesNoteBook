
package cn.fansunion.chinesechess.print.all;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.ColorUtil;
import cn.fansunion.chinesechess.core.ChessBoard;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ChessRule;



public class PrintAllBoard extends ChessBoard {

	private static final long serialVersionUID = 1L;

	// private JList manualList;

	private JLabel gameStatusContent;

	private PrintAllGUI boardOwner;

	public PrintAllBoard(PrintAllGUI boardOwner) {
		this.boardOwner = boardOwner;
		// manualList = chessManual.manualList;

	}


	public void initChess(boolean isRed) {

		if (isRed) {
			playerName = RED_NAME;

			if (gameStatusContent != null) {
				gameStatusContent.setText("  " + "����ѧ�ߧѧ� ������ߧ� �էӧڧا֧��� ��֧�ӧ�ۣ�");
			}

			chessPoints[1][10].setPiece(��܇1, this);
			��܇1.setPosition(new Point(1, 10));
			chessPoints[2][10].setPiece(���R1, this);
			���R1.setPosition(new Point(2, 10));
			chessPoints[3][10].setPiece(����1, this);
			����1.setPosition(new Point(3, 10));
			chessPoints[4][10].setPiece(����1, this);
			����1.setPosition(new Point(4, 10));
			chessPoints[5][10].setPiece(�쎛, this);
			�쎛.setPosition(new Point(5, 10));
			chessPoints[6][10].setPiece(����2, this);
			����2.setPosition(new Point(6, 10));
			chessPoints[7][10].setPiece(����2, this);
			����2.setPosition(new Point(7, 10));
			chessPoints[8][10].setPiece(���R2, this);
			���R2.setPosition(new Point(8, 10));
			chessPoints[9][10].setPiece(��܇2, this);
			��܇2.setPosition(new Point(9, 10));
			chessPoints[2][8].setPiece(����1, this);
			����1.setPosition(new Point(2, 8));
			chessPoints[8][8].setPiece(����2, this);
			����2.setPosition(new Point(8, 8));
			chessPoints[1][7].setPiece(���1, this);
			���1.setPosition(new Point(1, 7));
			chessPoints[3][7].setPiece(���2, this);
			���2.setPosition(new Point(3, 7));
			chessPoints[5][7].setPiece(���3, this);
			���3.setPosition(new Point(5, 7));
			chessPoints[7][7].setPiece(���4, this);
			���4.setPosition(new Point(7, 7));
			chessPoints[9][7].setPiece(���5, this);
			���5.setPosition(new Point(9, 7));

			chessPoints[1][1].setPiece(��܇1, this);
			��܇1.setPosition(new Point(1, 1));
			chessPoints[2][1].setPiece(���R1, this);
			���R1.setPosition(new Point(2, 1));
			chessPoints[3][1].setPiece(����1, this);
			����1.setPosition(new Point(3, 1));
			chessPoints[4][1].setPiece(��ʿ1, this);
			��ʿ1.setPosition(new Point(4, 1));
			chessPoints[5][1].setPiece(�ڌ�, this);
			�ڌ�.setPosition(new Point(5, 1));
			chessPoints[6][1].setPiece(��ʿ2, this);
			��ʿ2.setPosition(new Point(6, 1));
			chessPoints[7][1].setPiece(����2, this);
			����2.setPosition(new Point(7, 1));
			chessPoints[8][1].setPiece(���R2, this);
			���R2.setPosition(new Point(8, 1));
			chessPoints[9][1].setPiece(��܇2, this);
			��܇2.setPosition(new Point(9, 1));
			chessPoints[2][3].setPiece(����1, this);
			����1.setPosition(new Point(2, 3));
			chessPoints[8][3].setPiece(����2, this);
			����2.setPosition(new Point(8, 3));
			chessPoints[1][4].setPiece(����1, this);
			����1.setPosition(new Point(1, 4));
			chessPoints[3][4].setPiece(����2, this);
			����2.setPosition(new Point(3, 4));
			chessPoints[5][4].setPiece(����3, this);
			����3.setPosition(new Point(5, 4));
			chessPoints[7][4].setPiece(����4, this);
			����4.setPosition(new Point(7, 4));
			chessPoints[9][4].setPiece(����5, this);
			����5.setPosition(new Point(9, 4));

		} else {//
			playerName = BLACK_NAME;
			if (gameStatusContent != null) {
				gameStatusContent.setText("   " + "���اڧէѧߧڧ� �էӧڧا֧ߧڧ� �ܧ�ѧ�ߧ�� ������ߧ���");
			}

			chessPoints[1][10].setPiece(��܇1, this);
			��܇1.setPosition(new Point(1, 10));
			chessPoints[2][10].setPiece(���R1, this);
			���R1.setPosition(new Point(2, 10));
			chessPoints[3][10].setPiece(����1, this);
			����1.setPosition(new Point(3, 10));
			chessPoints[4][10].setPiece(��ʿ1, this);
			��ʿ1.setPosition(new Point(4, 10));

			chessPoints[5][10].setPiece(�ڌ�, this);
			�ڌ�.setPosition(new Point(5, 10));

			chessPoints[6][10].setPiece(��ʿ2, this);
			��ʿ2.setPosition(new Point(6, 10));
			chessPoints[7][10].setPiece(����2, this);
			����2.setPosition(new Point(7, 10));
			chessPoints[8][10].setPiece(���R2, this);
			���R2.setPosition(new Point(8, 10));
			chessPoints[9][10].setPiece(��܇2, this);
			��܇2.setPosition(new Point(9, 10));
			chessPoints[2][8].setPiece(����1, this);
			����1.setPosition(new Point(2, 8));
			chessPoints[8][8].setPiece(����2, this);
			����2.setPosition(new Point(8, 8));
			chessPoints[1][7].setPiece(����1, this);
			����1.setPosition(new Point(1, 7));
			chessPoints[3][7].setPiece(����2, this);
			����2.setPosition(new Point(3, 7));
			chessPoints[5][7].setPiece(����3, this);
			����3.setPosition(new Point(5, 7));
			chessPoints[7][7].setPiece(����4, this);
			����4.setPosition(new Point(7, 7));
			chessPoints[9][7].setPiece(����5, this);
			����5.setPosition(new Point(9, 7));

			chessPoints[1][1].setPiece(��܇1, this);
			��܇1.setPosition(new Point(1, 1));
			chessPoints[2][1].setPiece(���R1, this);
			���R1.setPosition(new Point(2, 1));
			chessPoints[3][1].setPiece(����1, this);
			����1.setPosition(new Point(3, 1));
			chessPoints[4][1].setPiece(����1, this);
			����1.setPosition(new Point(4, 1));
			chessPoints[5][1].setPiece(�쎛, this);
			�쎛.setPosition(new Point(5, 1));
			chessPoints[6][1].setPiece(����2, this);
			����2.setPosition(new Point(6, 1));
			chessPoints[7][1].setPiece(����2, this);
			����2.setPosition(new Point(7, 1));
			chessPoints[8][1].setPiece(���R2, this);
			���R2.setPosition(new Point(8, 1));
			chessPoints[9][1].setPiece(��܇2, this);
			��܇2.setPosition(new Point(9, 1));
			chessPoints[2][3].setPiece(����1, this);
			����1.setPosition(new Point(2, 3));
			chessPoints[8][3].setPiece(����2, this);
			����2.setPosition(new Point(8, 3));
			chessPoints[1][4].setPiece(���1, this);
			���1.setPosition(new Point(1, 4));
			chessPoints[3][4].setPiece(���2, this);
			���2.setPosition(new Point(3, 4));
			chessPoints[5][4].setPiece(���3, this);
			���3.setPosition(new Point(5, 4));
			chessPoints[7][4].setPiece(���4, this);
			���4.setPosition(new Point(7, 4));
			chessPoints[9][4].setPiece(���5, this);
			���5.setPosition(new Point(9, 4));
		}

	}

	private void visibleOrNot() {
		if (winkPiece != null) {
			winkPiece.setVisible(true);
		}

	}


	public void changeSide() {
		if (playerName.equals(RED_NAME)) {
			playerName = BLACK_NAME;
			boardOwner.updateGameStatus(2, "����ڧ�ݧ� ���֧�֧է� ��֧�ߧ��� �ڧէ�ڣ�");

		} else {
			playerName = RED_NAME;
			boardOwner.updateGameStatus(1, "���ѧ��ѧݧ� ���֧�֧է� �ܧ�ѧ�ߧ�� �ӧ֧�֧�ڧߧܧڣ�");
		}
	}


	private class PrintAllMouseAdapter extends MouseAdapter {
		PrintAllBoard board;

		public PrintAllMouseAdapter(PrintAllBoard board) {
			this.board = board;
		}


		public void mouseEntered(MouseEvent e) {
			ChessPiece piece = null;

			if (e.getSource() instanceof ChessPiece) {
				piece = (ChessPiece) e.getSource();
				if (piece.getName().equals(playerName)) {
					piece.setCursor(handCursor);
				} else {
					piece.setCursor(defaultCursor);
				}
			}
		}


		public void mousePressed(MouseEvent e) {
			boardOwner.last();

			if (!isSelected) {
				ChessPiece piece = null;
				Rectangle rect = null;

				if (e.getSource() == this) {
					isSelected = false;
				}

				if (e.getSource() instanceof ChessPiece) {
					piece = (ChessPiece) e.getSource();
					if (piece.getName().equals(playerName)) {
						isSelected = true;
						ChessUtil.playSound("select.wav");

						rect = piece.getBounds();
						for (int i = 1; i <= X; i++) {
							for (int j = 1; j <= Y; j++) {
								int x = chessPoints[i][j].getX();
								int y = chessPoints[i][j].getY();
								if (rect.contains(x, y)) {
									visibleOrNot();

									winkPiece = piece;
									needWink = true;

									if (winkThread == null) {
										winkThread = new Thread(board);
										winkThread.start();
									}

									startI = i;
									startJ = j;
									board.initTipPoints(piece, startI, startJ);
									break;
								}

							}
						}
					} else {
					}
				}
			}

			else {
				boolean rule = false;

				setCursor(defaultCursor);

				int m = 0, n = 0;

				if (e.getSource() == board) {
					double x1 = e.getX();
					double y1 = e.getY();

					for (int i = 1; i <= X; i++) {
						for (int j = 1; j <= Y; j++) {
							double x0 = chessPoints[i][j].getX();
							double y0 = chessPoints[i][j].getY();

							if ((Math.abs(x0 - x1) <= PIECE_WIDTH / 2)
									&& (Math.abs(y0 - y1) <= PIECE_HEIGHT / 2)) {
								m = i;
								n = j;
								break;
							}
						}
					}

					if (m == 0 || n == 0) {
						return;
					}

					rule = ChessRule.allRule(winkPiece, startI, startJ, m,
							n, chessPoints);

				}

				else if (e.getSource() instanceof ChessPiece) {
					ChessPiece piece2 = (ChessPiece) e.getSource();

					Rectangle rect2 = piece2.getBounds();
					for (int i = 1; i <= X; i++) {
						for (int j = 1; j <= Y; j++) {
							int x = chessPoints[i][j].getX();
							int y = chessPoints[i][j].getY();
							if (rect2.contains(x, y)) {
								m = i;
								n = j;
								break;
							}
						}
					}

					if (piece2.getName().equals(playerName)) {
						needWink = true;

						visibleOrNot();
						winkPiece = piece2;
						startI = m;
						startJ = n;
						isSelected = true;
						ChessUtil.playSound("select.wav");

						tipPoints.clear();

						board.initTipPoints(piece2, startI, startJ);

						return;
					}

					rule = ChessRule.allRule(winkPiece, startI, startJ, m,
							n, chessPoints);
					if (rule) {

						winkPiece.setPosition(new Point(m, n));



					} else {
						return;
					}

				}
				if (ChessRule.isWillDangerous(startI, startJ, m, n,
						chessPoints, board)) {
					rule = false;
				}

				if (rule) {

					needWink = false;
					if (winkPiece != null) {
						winkPiece.setVisible(true);
					}
					tipPoints.clear();

					addChessRecord(winkPiece, startI, startJ, m, n);
					movePiece(winkPiece, startI, startJ, m, n);
					isSelected = false;

					boardOwner.curIndex++;

					ChessUtil.playSound("eat.wav");

					validate();
					repaint();

					changeSide();

				}
			}
		}

	}

	@Override
	protected Color getBackgroundColor() {
		return ColorUtil.getPrintWholeBgcolor();
	}

	@Override
	protected MouseAdapter getMouseAdapter() {
		return new PrintAllMouseAdapter(this);
	}

	@Override
	protected BoardType getBoardType() {
		return BoardType.printWhole;
	}

}
