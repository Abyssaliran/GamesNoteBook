
package cn.fansunion.chinesechess.print.part;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessGUI;
import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessManual;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ChessPoint;
import cn.fansunion.chinesechess.core.ManualItem;
import cn.fansunion.chinesechess.core.MoveStep;
import cn.fansunion.chinesechess.core.PieceUtil;
import cn.fansunion.chinesechess.core.ChessPiece.PieceCategory;
import cn.fansunion.chinesechess.save.GameRecord;
import cn.fansunion.chinesechess.save.ISaveManual;
import cn.fansunion.chinesechess.save.SaveAsDialog;
import cn.fansunion.chinesechess.save.SaveDialog;
import cn.fansunion.chinesechess.save.GameRecord.ManualType;


public class PrintPartGUI extends JFrame implements ActionListener, NAME,
		ISaveManual {

	private static final long serialVersionUID = 266L;

	private JMenu fileMenu, manualMenu, settingMenu, helpMenu;

	private JMenuItem newManual, saveManual, saveManualAs, exitGame,
			openMainGUI;

	private JMenuItem reprintManual, inputManual, undoManual;

	private JMenuItem setting, helpContent, aboutGame, welcome;

	private JCheckBoxMenuItem bgSound;

	private JButton newButton, reprint, save, saveAs, undo, lock, set,
			inputManualButton, openMainGUIButton;

	private JButton prev, next, auto, first, last;

	private JPanel toolBar = new JPanel();

	private JPanel manualTools;

	private ArrayList<ManualItem> records;

	private ArrayList<Position> initPositions;

	private PrintPartBoard board;

	public ChessManual chessManual;

	private JPanel gameStatusPanel;

	public PiecesPanel piecesPanel;

	public int curIndex = -1;


	JLabel gameStatusContent, gameStatusIcon;

	public JScrollPane manualScroll;

	private Vector descs;


	private Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);


	public boolean isLock = false;

	private int time = 1000;


	public boolean redFirst = true;

	public PrintPartGUI() {

		board = new PrintPartBoard(this);

		chessManual = board.chessManual;
		manualScroll = chessManual.manualScroll;
		// manual = chessManual.manual;
		descs = chessManual.descs;
		records = chessManual.getManualItems();

		initMenuBar();
		initButtons();
		initToolBar();
		initPanels();

		handleKeyEvent();

		setSize(670, 760);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setResizable(false);
		setIconImage(ChessUtil.getAppIcon());
		setLocationRelativeTo(null);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}

		});
	}


	private void handleKeyEvent() {
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {

			public void eventDispatched(AWTEvent event) {
				if (((KeyEvent) event).getID() == KeyEvent.KEY_PRESSED) {
					int code = ((KeyEvent) event).getKeyCode();
					if (code == KeyEvent.VK_F1) {
						ChessUtil.showHelpDialog();
					} else if (code == KeyEvent.VK_DOWN) {
						next();
						System.out.println("next");
					} else if (code == KeyEvent.VK_UP) {
						prev();
						System.out.println("prev");
					} else if (code == KeyEvent.VK_HOME) {
						first();
						System.out.println("first");
					} else if (code == KeyEvent.VK_END) {
						last();
						System.out.println("last");
					}

				}
			}
		}, AWTEvent.KEY_EVENT_MASK);

	}


	private void initPanels() {
		JPanel rightPanel = new JPanel(new BorderLayout());

		JPanel recordsPanel = new JPanel(new BorderLayout());

		TitledBorder recordsBorder = new TitledBorder(
				PropertyReader.get("CHESS_MESSAGE_TOOLTIP"));
		recordsPanel.setBorder(recordsBorder);
		recordsPanel.setPreferredSize(new Dimension(240, 350));

		recordsPanel.add(BorderLayout.CENTER, chessManual);
		manualTools = new JPanel(new FlowLayout(FlowLayout.CENTER));
		// manualTools.setPreferredSize(new Dimension(220, 20));
		manualTools.add(first);
		manualTools.add(prev);
		manualTools.add(auto);
		manualTools.add(next);
		manualTools.add(last);

		recordsPanel.add(BorderLayout.SOUTH, manualTools);

		rightPanel.add(BorderLayout.CENTER, recordsPanel);

		JSplitPane splitH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, board,
				rightPanel);
		splitH.setDividerSize(5);
		splitH.setDividerLocation(450);

		initPiecesPanel();

		gameStatusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		// gameStatusPanel.setBackground(new Color(122, 146, 170));
		gameStatusIcon = new JLabel(ChessUtil.getImageIcon("hongshuai.png"));
		gameStatusContent = new JLabel("����ѧ�ߧѧ� ������ߧ� �էӧڧا֧��� ��֧�ӧ��");
		gameStatusContent.setFont(new Font("����", Font.PLAIN, 16));

		TitledBorder gameStatusBorder = new TitledBorder("��������ߧڧ� �ڧԧ��");
		gameStatusBorder.setTitleColor(Color.RED);
		gameStatusBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		gameStatusPanel.setToolTipText("��������ߧڧ� �ڧԧ��");
		gameStatusPanel.setBorder(gameStatusBorder);

		gameStatusPanel.add(gameStatusIcon);
		gameStatusPanel.add(gameStatusContent);

		// add(BorderLayout.SOUTH, gameStatusPanel);
		add(BorderLayout.CENTER, splitH);
		add(BorderLayout.NORTH, toolBar);
	}


	private void initPiecesPanel() {

		GridLayout gridLayout = new GridLayout(4, 8);
		gridLayout.setHgap(5);
		gridLayout.setVgap(2);
		piecesPanel = new PiecesPanel("bgimage.png");
		piecesPanel.setLayout(gridLayout);
		piecesPanel.add(board.��܇1);
		piecesPanel.add(board.���R1);
		piecesPanel.add(board.����1);
		piecesPanel.add(board.����1);

		piecesPanel.add(board.����2);
		piecesPanel.add(board.����2);
		piecesPanel.add(board.���R2);
		piecesPanel.add(board.��܇2);

		piecesPanel.add(board.�쎛);
		piecesPanel.add(board.����1);
		piecesPanel.add(board.����2);
		piecesPanel.add(board.���1);
		piecesPanel.add(board.���2);
		piecesPanel.add(board.���3);
		piecesPanel.add(board.���4);
		piecesPanel.add(board.���5);

		piecesPanel.add(board.��܇1);
		piecesPanel.add(board.���R1);
		piecesPanel.add(board.����1);
		piecesPanel.add(board.��ʿ1);
		piecesPanel.add(board.��ʿ2);
		piecesPanel.add(board.����2);
		piecesPanel.add(board.���R2);
		piecesPanel.add(board.��܇2);

		piecesPanel.add(board.�ڌ�);
		piecesPanel.add(board.����1);
		piecesPanel.add(board.����2);
		piecesPanel.add(board.����1);
		piecesPanel.add(board.����2);
		piecesPanel.add(board.����3);
		piecesPanel.add(board.����4);
		piecesPanel.add(board.����5);

		add(BorderLayout.SOUTH, piecesPanel);

		TitledBorder piecesPanelBorder = new TitledBorder("���ѧ�ѧ�ߧѧ� ��֧�ܧ�");
		piecesPanelBorder.setTitleColor(Color.RED);
		piecesPanelBorder.setTitleFont(new Font("����", Font.PLAIN, 14));
		piecesPanel.setBorder(piecesPanelBorder);
	}


	private void initButtons() {
		Dimension iconSize = new Dimension(16, 16);
		prev = new JButton(ChessUtil.getImageIcon("prev.gif"));
		prev.addActionListener(this);
		prev.setToolTipText("����֧է��է��ڧ�");
		prev.setCursor(new Cursor(Cursor.HAND_CURSOR));
		prev.setPreferredSize(iconSize);

		next = new JButton(ChessUtil.getImageIcon("next.gif"));
		next.addActionListener(this);
		next.setToolTipText("���ݧ֧է���ڧ� ��ѧ�");
		next.setCursor(new Cursor(Cursor.HAND_CURSOR));
		next.setPreferredSize(iconSize);

		first = new JButton(ChessUtil.getImageIcon("first.gif"));
		first.addActionListener(this);
		first.setToolTipText("��֧�ӧ��� ��ѧ�");
		first.setCursor(new Cursor(Cursor.HAND_CURSOR));
		first.setPreferredSize(iconSize);

		last = new JButton(ChessUtil.getImageIcon("last.gif"));
		last.addActionListener(this);
		last.setToolTipText("����ݧ֧էߧڧ� ��ѧ�");
		last.setCursor(new Cursor(Cursor.HAND_CURSOR));
		last.setPreferredSize(iconSize);

		auto = new JButton(ChessUtil.getImageIcon("auto.gif"));
		auto.addActionListener(this);
		auto.setToolTipText("���ӧ��ާѧ�ڧ�֧�ܧѧ� ���֧٧֧ߧ�ѧ�ڧ�");
		auto.setPreferredSize(iconSize);
		auto.setCursor(new Cursor(Cursor.HAND_CURSOR));

		Insets insets = new Insets(1, 1, 1, 1);

		reprint = new JButton(ChessUtil.getImageIcon("reprint.gif"));
		reprint.setToolTipText("���´���");
		reprint.addActionListener(this);
		// reprint.setPreferredSize(dimension);
		reprint.setCursor(handCursor);
		reprint.setMargin(insets);

		save = new JButton(ChessUtil.getImageIcon("save.gif"));
		save.addActionListener(this);
		save.setToolTipText("������ѧߧڧ�� �٧ѧ�ڧ�� �ڧԧ��");
		// save.setPreferredSize(dimension);
		save.setCursor(handCursor);
		save.setMargin(insets);

		saveAs = new JButton(ChessUtil.getImageIcon("saveas.gif"));
		saveAs.addActionListener(this);
		saveAs.setToolTipText("������ѧߧڧ�� �ܧѧ� �٧ѧ�ڧ�� �ڧԧ��");
		// saveAs.setPreferredSize(dimension);
		saveAs.setCursor(handCursor);
		saveAs.setMargin(insets);

		lock = new JButton(ChessUtil.getImageIcon("lock.gif"));
		lock.addActionListener(this);
		lock.setToolTipText("�٧ѧ�ڧ�ѧߧڧ�");
		// saveAs.setPreferredSize(dimension);
		lock.setCursor(handCursor);
		lock.setMargin(insets);

		undo = new JButton(ChessUtil.getImageIcon("undo.gif"));
		undo.addActionListener(this);
		undo.setToolTipText("���ѧ�ާѧ�� ���اѧݧ֧ߧڧ�");
		undo.setCursor(handCursor);
		undo.setEnabled(false);
		undo.setMargin(insets);

		set = new JButton(ChessUtil.getImageIcon("welcome.gif"));
		set.setToolTipText("���ѧ����ڧ��");
		set.addActionListener(this);
		set.setCursor(handCursor);
		set.setMargin(insets);

		newButton = new JButton(ChessUtil.getImageIcon("newManual.gif"));
		newButton.setToolTipText("����ӧ��� �ڧԧ��ӧ�� ��֧ܧ���");
		newButton.addActionListener(this);
		newButton.setCursor(handCursor);
		newButton.setMargin(insets);

		inputManualButton = new JButton(
				ChessUtil.getImageIcon("inputManual.gif"));
		inputManualButton.setToolTipText("���ӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��");
		inputManualButton.addActionListener(this);
		inputManualButton.setCursor(handCursor);
		inputManualButton.setMargin(insets);

		openMainGUIButton = new JButton(ChessUtil.getImageIcon("mainGUI.gif"));
		openMainGUIButton.setToolTipText("����ܧ��ۧ�� ���ߧ�ӧߧ�� �ڧߧ�֧��֧ۧ�");
		openMainGUIButton.addActionListener(this);
		openMainGUIButton.setCursor(handCursor);
		openMainGUIButton.setMargin(insets);
	}


	private void initMenuBar() {
		JMenuBar bar = new JMenuBar();

		fileMenu = new JMenu("��ѧۧ�(G)");

		newManual = new JMenuItem("����ӧ���", ChessUtil.getImageIcon("newManual.gif"));
		saveManual = new JMenuItem("���ѧ���", ChessUtil.getImageIcon("save.gif"));
		saveManualAs = new JMenuItem("������ѧߧڧ�� �ܧѧ�", ChessUtil.getImageIcon("saveas.gif"));
		exitGame = new JMenuItem("�ӧ��ҧ��ӧѧ��", ChessUtil.getImageIcon("exit.gif"));
		openMainGUI = new JMenuItem("���ݧѧӧߧ��� �ڧߧ�֧��֧ۧ�",
				ChessUtil.getImageIcon("mainGUI.gif"));
		fileMenu.add(newManual);
		fileMenu.add(saveManual);
		fileMenu.add(saveManualAs);
		fileMenu.add(exitGame);
		fileMenu.add(openMainGUI);

		manualMenu = new JMenu("���ѧ�ާѧ�ߧ��� ��֧ܧ���(M)");
		reprintManual = new JMenuItem("���ڧާ֧ۧ�",
				ChessUtil.getImageIcon("reprint.gif"));
		inputManual = new JMenuItem("���ӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��",
				ChessUtil.getImageIcon("inputManual.gif"));
		undoManual = new JMenuItem("���ѧ�ާѧ�� ���اѧݧ֧ߧڧ�", ChessUtil.getImageIcon("undo.gif"));
		manualMenu.add(reprintManual);
		manualMenu.add(inputManual);
		manualMenu.add(undoManual);

		helpMenu = new JMenu("����ާ�ԧڧ��(H)");
		welcome = new JMenuItem("�է�ҧ�� ���اѧݧ�ӧѧ��", ChessUtil.getImageIcon("welcome.gif"));
		helpContent = new JMenuItem("����է֧�اѧߧڧ� ����ѧӧܧ�", ChessUtil.getImageIcon("help.gif"));
		aboutGame = new JMenuItem("�� �ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ�ѧ�", ChessUtil.getImageIcon("info.gif"));

		helpMenu.add(welcome);
		helpMenu.add(helpContent);
		helpMenu.add(aboutGame);

		settingMenu = new JMenu("���ѧ����ڧ��(S)");

		setting = new JMenuItem("���ҧ�ڧ� �ߧѧ����ۧܧ�");
		bgSound = new JCheckBoxMenuItem("����ߧ�ӧѧ� �ާ�٧��ܧ�");
		bgSound.setSelected(true);

		settingMenu.add(bgSound);
		settingMenu.add(setting);

		bar.add(fileMenu);
		bar.add(manualMenu);
		bar.add(settingMenu);
		bar.add(helpMenu);

		setJMenuBar(bar);


		saveManual.setAccelerator(KeyStroke.getKeyStroke('S',
				InputEvent.CTRL_DOWN_MASK));
		saveManualAs.setAccelerator(KeyStroke.getKeyStroke('U',
				InputEvent.CTRL_DOWN_MASK));
		reprintManual.setAccelerator(KeyStroke.getKeyStroke('P',
				InputEvent.CTRL_DOWN_MASK));
		exitGame.setAccelerator(KeyStroke.getKeyStroke('E',
				InputEvent.CTRL_DOWN_MASK));
		openMainGUI.setAccelerator(KeyStroke.getKeyStroke('M',
				InputEvent.CTRL_DOWN_MASK));

		newManual.setAccelerator(KeyStroke.getKeyStroke('N',
				InputEvent.CTRL_DOWN_MASK));
		inputManual.setAccelerator(KeyStroke.getKeyStroke('I',
				InputEvent.CTRL_DOWN_MASK));
		undoManual.setAccelerator(KeyStroke.getKeyStroke('U',
				InputEvent.CTRL_DOWN_MASK));

		welcome.setAccelerator(KeyStroke.getKeyStroke('W',
				InputEvent.CTRL_DOWN_MASK));
		helpContent.setAccelerator(KeyStroke.getKeyStroke('H',
				InputEvent.CTRL_DOWN_MASK));
		aboutGame.setAccelerator(KeyStroke.getKeyStroke('A',
				InputEvent.CTRL_DOWN_MASK));

		bgSound.setAccelerator(KeyStroke.getKeyStroke('B',
				InputEvent.CTRL_DOWN_MASK));
		setting.setAccelerator(KeyStroke.getKeyStroke('T',
				InputEvent.CTRL_DOWN_MASK));

		fileMenu.setMnemonic(KeyEvent.VK_G);
		manualMenu.setMnemonic(KeyEvent.VK_M);
		settingMenu.setMnemonic(KeyEvent.VK_S);
		helpMenu.setMnemonic(KeyEvent.VK_H);

		newManual.addActionListener(this);
		saveManual.addActionListener(this);
		saveManualAs.addActionListener(this);
		exitGame.addActionListener(this);
		openMainGUI.addActionListener(this);

		inputManual.addActionListener(this);
		reprintManual.addActionListener(this);
		undoManual.addActionListener(this);

		setting.addActionListener(this);
		bgSound.addActionListener(this);

		welcome.addActionListener(this);
		helpContent.addActionListener(this);
		aboutGame.addActionListener(this);

		setJMenuBar(bar);
	}


	private void initToolBar() {
		FlowLayout flowLayout = new FlowLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		toolBar.setLayout(flowLayout);

		toolBar.add(newButton);
		toolBar.add(save);
		toolBar.add(saveAs);

		toolBar.add(reprint);
		toolBar.add(undo);
		toolBar.add(inputManualButton);
		toolBar.add(lock);
		toolBar.add(set);
		toolBar.add(openMainGUIButton);

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == next) {
			next();
		} else if (source == prev) {
			prev();
		} else if (source == first) {
			first();
		} else if (source == last) {
			last();
		} else if (source == auto) {
			DemoThread auto = new DemoThread();
			auto.start();
			System.out.println("����ݧ�ܧ� ���� �ߧѧ�ڧ�ѧߧ� �ߧ�ӧѧ� �ӧ֧�ܧ�");
		} else if (source == helpContent) {
			ChessUtil.showHelpDialog();
		} else if (source == set) {

		}

		else if (source == reprint) {
			int result = JOptionPane.showConfirmDialog(this, "���� ��ӧ֧�֧ߧ�, ���� �ӧѧ� �ߧ�اߧ� ��֧�֧ڧԧ�ѧ�� ���֧䣿",
					"���� ��ӧ֧�֧ߧ�, ���� �ӧѧ� �ߧ�اߧ� ��֧�֧ڧԧ�ѧ�� ���֧䣿", JOptionPane.YES_NO_OPTION);

			if (result == JOptionPane.YES_OPTION) {
				dispose();
				PrintPartGUI newPrint = new PrintPartGUI();
				newPrint.setVisible(true);
			}

		} else if (source == lock) {
			int result = JOptionPane
					.showConfirmDialog(
							this,
							"  �����ݧ� ���ԧ�, �ܧѧ� �ڧԧ�� �٧ѧҧݧ�ܧڧ��ӧѧߧ�, �٧ѧ�ѧ�ߧ��� ��ڧ�ܧ� �ҧ�ݧ��� �ߧ� �ާ�ԧ�� �ҧ���� ���ާ֧�֧ߧ� �ߧ� �է��ܧ�, �� ��ڧ�ܧ� �� �է��ܧ� �ߧ� �ާ�ԧ�� �ҧ���� ���ާ֧�֧ߧ� ��ҧ�ѧ�ߧ� �� ����ݧҧ֧� �٧ѧ�ѧ�ߧ��� ��ڧ�֧�. \\ N�����ݧ� ����ԧ� �٧ѧ�ڧ�� �ڧԧ�� �ާ�ا֧� �ҧ���� �����ѧߧ֧ߧ� �էݧ� ��ݧ֧է���֧� �է֧ާ�ߧ���ѧ�ڧ�.",
							"���� ��ӧ֧�֧ߧ�, ���� ����ڧ�� �٧ѧҧݧ�ܧڧ��ӧѧ�� �ڧԧ��?��", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {
				int lockResult = canLock();
				if (lockResult == 2) {
					lockManual();
				} else if (lockResult == 1) {
					JOptionPane.showMessageDialog(this, "��û��λ�ھŹ���", "�������ʧ��",
							JOptionPane.ERROR_MESSAGE);
				} else if (lockResult == -1) {
					JOptionPane.showMessageDialog(this, "��û��λ�ھŹ���", "�������ʧ��",
							JOptionPane.ERROR_MESSAGE);
				} else if (lockResult == 0) {
					JOptionPane.showMessageDialog(this, "���͎�û��λ�ھŹ���", "�������ʧ��",
							JOptionPane.ERROR_MESSAGE);
				} else if (lockResult == 11) {
					JOptionPane.showMessageDialog(this, "���͎����ܶ���", "�������ʧ��",
							JOptionPane.ERROR_MESSAGE);
				}

			}
		}

		else if (source == save) {
			if (!isLock) {
				JOptionPane.showMessageDialog(this, "����اߧ� �����ѧߧڧ�� ���ݧ�ܧ� ����ݧ� �ҧݧ�ܧڧ��ӧܧ�");
				return;
			}
			SaveDialog dialog = new SaveDialog(this);
			dialog.setVisible(true);

		} else if (source == saveAs) {
			if (!isLock) {
				JOptionPane.showMessageDialog(this, "������ѧߧڧ�� �ܧѧ� ����ݧ� �ҧݧ�ܧڧ��ӧܧ�");
				return;
			}
			SaveAsDialog dialog = new SaveAsDialog(this);
			dialog.setVisible(true);
		} else if (source == exitGame) {
			handleExitGame();
		} else if (source == helpContent) {
			ChessUtil.showHelpDialog();
		} else if (source == welcome) {
			ChessUtil.showWelcomeDialog();
		} else if (source == aboutGame) {
			ChessUtil.showAboutDialog();
		} else if (source == set || source == setting) {

		}

		else if (source == reprint || source == reprintManual) {
			int result = JOptionPane.showConfirmDialog(this, "���ѧ� �ߧ�اߧ� �����ѧߧڧ�� ��֧ܧ��ڧ� �ڧԧ��ӧ�� ��֧ܧ��գ�",
					"���ѧ� �ߧ�اߧ� �����ѧߧڧ�� ��֧ܧ��ڧ� �ڧԧ��ӧ�� ��֧ܧ��գ�", JOptionPane.YES_NO_OPTION);

			if (result == JOptionPane.YES_OPTION) {
				SaveDialog dialog = new SaveDialog(this);
				dialog.setVisible(true);
			}
			int size = chessManual.getManualItems().size();
			for (int index = 0; index < size; index++) {
				undo();
			}
		}

		else if (source == undo || source == undoManual) {
			last();
			undo();

		} else if (source == save || source == saveManual) {
			SaveDialog dialog = new SaveDialog(this);
			dialog.setVisible(true);

		} else if (source == saveAs || source == saveManualAs) {
			SaveAsDialog dialog = new SaveAsDialog(this);
			dialog.setVisible(true);
		} else if (source == inputManualButton || source == inputManual) {
			String manual = JOptionPane.showInputDialog(this, "����اѧݧ�ۧ���, �ӧӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��", "����اѧݧ�ۧ���, �ӧӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��",
					JOptionPane.OK_CANCEL_OPTION);
			if (manual != null) {
				manual = manual.trim();
			}
			// movePieceByManual(manual);

		} else if (source == newButton || source == newManual) {
			PrintPartGUI newPrint = new PrintPartGUI();
			newPrint.setVisible(true);
		} else if (source == openMainGUI || source == openMainGUIButton) {
			ChessGUI mainGUI = new ChessGUI();
			mainGUI.setVisible(true);
		}
	}


	private void undo() {
		boolean flag = chessManual.removeManualItem();
		if (flag) {
			if (board.getPlayerName().equals(RED_NAME)) {
				board.setPlayerName(BLACK_NAME);
			} else {
				board.setPlayerName(RED_NAME);
			}
			curIndex--;
		}
	}


	private void lockManual() {
		int result = JOptionPane.showConfirmDialog(this,
				"����ѧ�ߧѧ� ������ߧ� ��ߧѧ�ѧݧ� �ӧ��ҧڧ�ѧ֧� �է�, ��֧�ߧѧ� ������ߧ� ��ߧѧ�ѧݧ� �ӧ��ҧڧ�ѧ֧� �ߧ֧�, ���ާ֧ߧڧ�� �� �ҧ�ݧ��� �ߧ� �ҧݧ�ܧڧ��ӧѧ��", "���ѧܧ�� �ڧ� �ߧڧ� �է�ݧا֧� �ڧէ�� ��֧�ӧ��ޣ�",
				JOptionPane.YES_NO_CANCEL_OPTION);
		if (result == JOptionPane.CANCEL_OPTION) {
			return;
		} else if (result == JOptionPane.YES_OPTION) {
			board.setPlayerName(RED_NAME);
			redFirst = true;
		} else if (result == JOptionPane.NO_OPTION) {
			board.setPlayerName(BLACK_NAME);
			redFirst = false;
		}

		isLock = true;

		board.setSelected(false);
		board.setNeedWink(false);

		lock.setEnabled(false);
		save.setEnabled(true);
		saveAs.setEnabled(true);
		undo.setEnabled(true);

		initPositions = new ArrayList<Position>();
		for (int i = 1; i <= 9; i++) {
			for (int j = 1; j <= 10; j++) {
				ChessPiece piece = board.chessPoints[i][j].getPiece();
				Position position = new Position();
				if (piece != null) {
					position.setId(piece.getId());
					position.setPoint(piece.getPosition());
					initPositions.add(position);
				}
			}
		}
	}

	public void scrollToView() {
		if (curIndex >= 0 && curIndex < descs.size()) {
			int lastIndex = curIndex;
			Rectangle rect = chessManual.manualList.getCellBounds(lastIndex,
					lastIndex);
			if (rect != null) {
				manualScroll.getViewport().scrollRectToVisible(rect);
			}
			System.out.println("���ݧ֧է�֧� �ӧ��ҧ�ѧ�� �����ܧ� N��" + curIndex);
			chessManual.manualList.setSelectedIndex(curIndex);
		}

	}


	private void handleExitGame() {
		int result = JOptionPane.showConfirmDialog(this, "���� ��ӧ֧�֧ߧ�, ���� ����ڧ�� �ӧ��ۧ�ڣ�", "���է�ӧ֧�էڧ�� �ӧ�����",
				JOptionPane.YES_NO_OPTION);
		if (result == JOptionPane.YES_OPTION) {
			if (board.getWinkThread() != null) {
				board.getWinkThread().interrupt();
				System.out.println("���ѧܧ����ڧ�...");
			}
			dispose();
		}
	}



	private void prev() {
		System.out.println("���֧ܧ��ڧ� �ڧߧէ֧ܧ㣺" + curIndex);
		if (curIndex == -1) {
			return;
		}

		int size = records.size();


		ManualItem record = new ManualItem();
		MoveStep moveStep;

		ChessPiece eatedPiece;
		int startI = 0;
		int startJ = 0;
		int endI = 0;
		int endJ = 0;

		if (size > 0 && curIndex < size && curIndex >= 0) {
			record = (ManualItem) records.get(curIndex);
			eatedPiece = PieceUtil.createPiece(record.getEatedPieceId());

			moveStep = record.getMoveStep();
			startI = moveStep.start.x;
			startJ = moveStep.start.y;
			endI = moveStep.end.x;
			endJ = moveStep.end.y;

			if (eatedPiece == null) {
				System.out.println("���� �֧� ��ѧ�ާѧ�ߧ�� ��ڧԧ���");

				ChessPiece piece = board.chessPoints[endI][endJ].getPiece();

				board.chessPoints[startI][startJ].setPiece(piece, board);
				(board.chessPoints[endI][endJ]).setHasPiece(false);

			}
			else {
				ChessPiece piece = board.chessPoints[endI][endJ].getPiece();
				board.chessPoints[startI][startJ].setPiece(piece, board);

				board.chessPoints[endI][endJ].setPiece(eatedPiece, board);
				(board.chessPoints[endI][endJ]).setHasPiece(true);

			}
		}

		if (curIndex >= 1) {
			record = (ManualItem) records.get(curIndex - 1);
			moveStep = record.getMoveStep();
			startI = moveStep.start.x;
			startJ = moveStep.start.y;
			endI = moveStep.end.x;
			endJ = moveStep.end.y;
		}

		board.setMoveFlag(true);
		board.movePoints[0] = new Point(
				(int) (board.chessPoints[endI][endJ].getX()),
				(int) (board.chessPoints[endI][endJ].getY()));
		board.movePoints[1] = new Point(
				(int) (board.chessPoints[startI][startJ].getX()),
				(int) (board.chessPoints[startI][startJ].getY()));

		curIndex--;
		scrollToView();

		if (curIndex == -1) {
			board.setMoveFlag(false);

			chessManual.manualList.setListData(descs);
		}

		repaint();
		validate();
	}


	public void step(int index) {
		ManualItem moveRecord = records.get(index);
		MoveStep step = moveRecord.getMoveStep();
		Point pStart = step.start;
		Point pEnd = step.end;
		int startI = pStart.x;
		int startJ = pStart.y;
		int endI = pEnd.x;
		int endJ = pEnd.y;

		ChessPiece piece = (board.chessPoints)[startI][startJ].getPiece();
		board.movePiece(piece, startI, startJ, endI, endJ);

		/*
		 * board.setMoveFlag(true); board.movePoints[0] = new
		 * Point((int) (board.chessPoints[endI][endJ] .getX()), (int)
		 * (board.chessPoints[endI][endJ].getY())); board.movePoints[1] = new
		 * Point( (int) (board.chessPoints[startI][startJ].getX()), (int)
		 * (board.chessPoints[startI][startJ].getY()));
		 * 
		 * 
		 * if ((board.chessPoints)[endI][endJ].hasPiece()) { ChessPiece
		 * pieceRemoved = (board.chessPoints)[endI][endJ] .getPiece();
		 * board.remove(pieceRemoved);
		 * (board.chessPoints)[endI][endJ].setPiece(piece, board);
		 * (board.chessPoints)[startI][startJ].setHasPiece(false); } else {
		 * (board.chessPoints)[endI][endJ].setPiece(piece, board);
		 * (board.chessPoints)[startI][startJ].setHasPiece(false); }
		 */
		repaint();
		validate();
	}


	public void next() {
		System.out.println("���֧ܧ��ڧ� �ڧߧէ֧ܧ㣺" + curIndex);

		if (curIndex == descs.size() - 1) {
			return;
		}

		curIndex++;
		if (curIndex < records.size()) {
			step(curIndex);
		}
		scrollToView();
	}


	public void last() {
		int size = descs.size();
		System.out.println(size + "aa" + curIndex);
		while (curIndex < size - 1) {
			next();
		}
	}


	private void first() {
		while (curIndex != -1) {
			prev();
		}
	}


	private int canLock() {

		boolean hasShuai = false;
		boolean hasJiang = false;

		ChessPoint[][] chessPoints = board.chessPoints;

		int shuaiX = 0, shuaiY = 0, jiangX = 0, jiangY = 0;

		for (int i = 4; i <= 6; i++) {
			for (int j = 1; j <= 3; j++) {
				if (chessPoints[i][j].hasPiece()) {
					if (chessPoints[i][j].getPiece().getCategory()
							.equals(PieceCategory.JIANG)) {
						hasJiang = true;
						jiangX = i;
						jiangY = j;
						break;
					}
				}
			}
		}
		for (int i = 4; i <= 6; i++) {
			for (int j = 8; j <= 10; j++) {
				if (chessPoints[i][j].hasPiece()) {
					if (chessPoints[i][j].getPiece().getCategory()
							.equals(PieceCategory.SHUAI)) {
						hasShuai = true;
						shuaiX = i;
						shuaiY = j;
						break;
					}
				}
			}
		}

		if (hasShuai) {
			if (hasJiang) {
				boolean flag = false;
				if (shuaiX == jiangX) {

					for (int j = jiangY + 1; j <= shuaiY - 1; j++) {
						if (chessPoints[shuaiX][j].hasPiece()) {
							flag = true;
						}
					}
				} else {
					flag = true;
				}

				if (flag) {
					return 2;
				}
				return 11;

			}
			return -1;
		}
		if (hasJiang) {
			return 1;
		}
		return 0;

	}

	private class DemoThread extends Thread {

		public DemoThread() {
			System.out.println("����ݧ�ܧ� ���� �ߧѧ�ڧ�ѧߧߧѧ� �ߧ�ӧѧ� �����ܧ���� �����ܧ� �٧ѧӧ֧��֧ߧ�");
		}

		public void run() {
			System.out.println("����ݧ�ܧ� ���� ���٧էѧߧߧ��� �ߧ�ӧ��� ������ �٧ѧ���֧�");
			int size = records.size();

			while (curIndex < size - 1) {
				try {
					Thread.sleep(time);

					next();
					if (curIndex >= size - 1) {
						this.join(100);
						break;
					}
				} catch (InterruptedException ie) {
					break;
				}
			}
		}

	}

	public static void main(String[] args) {
		String lookAndFeel = UIManager.getSystemLookAndFeelClassName();
		try {
			UIManager.setLookAndFeel(lookAndFeel);
		} catch (Exception e) {
			e.printStackTrace();
		}

		PrintPartGUI printEndManual = new PrintPartGUI();
		printEndManual.setVisible(true);

	}

	@Override
	public ArrayList<String> getSavePaths() {
		ArrayList<String> paths = new ArrayList<String>();
		String path = "manuals/partial/";
		String path2 = "manuals/partial/";

		paths.add(path);
		paths.add(path2);
		return paths;
	}

	@Override
	public GameRecord getGameRecord() {
		GameRecord gameRecord = new GameRecord(ManualType.PRINT_PARTIAL,
				ChessUtil.getDateAndTime(), "",
				board.chessManual.getManualItems(), board.chessManual.descs,
				initPositions);
		return gameRecord;
	}

}
