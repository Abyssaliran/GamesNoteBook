
package cn.fansunion.chinesechess.print.part;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JList;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.ColorUtil;
import cn.fansunion.chinesechess.core.ChessBoard;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ChessRule;
import cn.fansunion.chinesechess.core.ManualItem;
import cn.fansunion.chinesechess.core.MoveStep;


public class PrintPartBoard extends ChessBoard {

	private static final long serialVersionUID = 1L;

	public JList manualList;

	public PrintPartGUI boardOwner;


	private boolean winkPieceAtBoard = false;

	public PrintPartBoard(PrintPartGUI owner) {
		super();
		boardOwner = owner;
		playerName = RED_NAME;
		manualList = chessManual.manualList;

	}


	private class PartialMouseAdapter extends MouseAdapter {
		PrintPartBoard board;

		public PartialMouseAdapter(PrintPartBoard board) {
			this.board = board;
		}



		public void mouseEntered(MouseEvent e) {
			if (e.getSource() instanceof ChessPiece) {
				ChessPiece piece = (ChessPiece) e.getSource();
				Point point = isPieceAtBoard(piece);

				if (boardOwner.isLock) {

					if (point != null && piece.getName().equals(playerName)) {
						piece.setCursor(handCursor);
					} else {
						piece.setCursor(defaultCursor);
					}

				} else {

					piece.setCursor(handCursor);
				}
			}
		}

		public void mousePressed(MouseEvent e) {


			boardOwner.last();
			if (!isSelected) {
				ChessPiece piece = null;


				if (e.getSource() == board) {
					isSelected = false;
					System.out.println("���ѧاާڧ�� �ߧ� �է��ܧ� �� ��֧�ӧ��� ��ѧ�! �ڧԧߧ��ڧ��ӧѧ�");

				}


				if (e.getSource() instanceof ChessPiece) {
					piece = (ChessPiece) e.getSource();


					winkPieceAtBoard = false;
					Point point = isPieceAtBoard(piece);
					if (point != null) {
						winkPieceAtBoard = true;
						startI = (int) point.getX();
						startJ = (int) point.getY();
					}

					if (winkPieceAtBoard) {

						if (!boardOwner.isLock) {
							System.out.println(piece.getCategory()
									+ "�� �ѧݧ��֧�ߧѧ�ڧӧߧ�� ��֧�ܧ֣�");
							System.out.println("(" + startI + "," + startJ
									+ ")");
							System.out.println("���֧�ӧ��� �ӧ��ҧ�ѧߧߧ���" + piece.getCategory());

							isSelected = true;
							ChessUtil.playSound("select.wav");

							winkPiece = piece;
							needWink = true;
						} else {
							if (piece.getName().equals(playerName)) {
								isSelected = true;
								ChessUtil.playSound("select.wav");

								winkPiece = piece;
								needWink = true;
							} else {
								isSelected = false;
								return;
							}
						}

					} else {
						if (!boardOwner.isLock) {
							startI = 0;
							startJ = 0;
							isSelected = true;
							ChessUtil.playSound("select.wav");

							winkPiece = piece;
							needWink = true;

						} else {
							return;
						}
					}

				}
			}

			else {
				boolean canMove = true;
				ChessPiece pieceRemoved = null;

				int endI = 0, endJ = 0;

				if (e.getSource() == board) {
					double x1 = e.getX();
					double y1 = e.getY();
					for (int i = 1; i <= X; i++) {
						for (int j = 1; j <= Y; j++) {
							double x0 = chessPoints[i][j].getX();
							double y0 = chessPoints[i][j].getY();

							if ((Math.abs(x0 - x1) <= PIECE_WIDTH / 2)
									&& (Math.abs(y0 - y1) <= PIECE_HEIGHT / 2)) {
								endI = i;
								endJ = j;
								break;
							}
						}
					}
					System.out.println("����ԧէ� �ӧ� ��֧ݧܧѧ֧�� ��� ��ѧ�ާѧ�ߧ�� �է��ܧ� �ӧ� �ӧ����� ��ѧ�, �ܧ���էڧߧѧ�� �ܧ�ߧ֧�ߧ�� ����ܧڣ�(" + endI + "," + endJ
							+ ")");

					if (endI == 0 || endJ == 0) {
						if (boardOwner.isLock) {
							return;
						}
						System.out.println("����ԧէ� �� ��֧ݧܧߧ�� �ӧ����� ��ѧ�, �� �ߧ� ��֧ݧܧߧ�� �ӧߧ���� �է��ܧڣ�");
						board.remove(winkPiece);
						boardOwner.piecesPanel.add(winkPiece);
						needWink = false;
						winkPiece.setVisible(true);
						isSelected = false;
						if (winkPieceAtBoard) {
							chessPoints[startI][startJ].setHasPiece(false);
						}

					}
					else {

						canMove = ChessRule.partialRule(winkPiece, startI,
								startJ, endI, endJ, chessPoints);

						if (canMove) {
							winkPiece.setPosition(new Point(endI, endJ));
							if (winkPieceAtBoard) {
								chessPoints[startI][startJ].setHasPiece(false);
							}

							chessPoints[endI][endJ].setPiece(winkPiece, board);

							needWink = false;
							winkPiece.setVisible(true);
							isSelected = false;
							boardOwner.piecesPanel.remove(winkPiece);
							ChessUtil.playSound("eat.wav");

							if (boardOwner.isLock) {
								moveFlag = true;
								movePoints[0] = new Point(startI, startJ);
								movePoints[1] = new Point(endI, endJ);

								ManualItem moveRecord = new ManualItem();
								moveRecord.setMovePieceId(winkPiece.getId());
								moveRecord.setEatedPieceId(null);
								moveRecord
										.setMoveStep(new MoveStep(new Point(
												startI, startJ), new Point(
												endI, endJ)));
								chessManual.addManualItem(moveRecord);

								boardOwner.curIndex++;
								changeSide();

							}

						} else {
							System.out.println("�������� ��֧ݧ��� �ߧ� �����ӧ֧���ӧ�֧� ���ѧӧڧݧѧ� ��ѧ�ާѧ�ߧ�ԧ� �էӧڧا֧ߧڧ�.��");

						}
					}
				}

				else if (e.getSource() instanceof ChessPiece) {
					ChessPiece piece = (ChessPiece) e.getSource();

					boolean flag = false;
					for (int i = 1; i <= 9; i++) {
						for (int j = 1; j <= 10; j++) {
							ChessPiece tempPiece = chessPoints[i][j].getPiece();
							if (chessPoints[i][j].hasPiece()
									&& tempPiece.equals(piece)) {
								endI = i;
								endJ = j;
								System.out.println(piece.getCategory()
										+ "���� ��ѧ�ާѧ�ߧ�� �է��ܧ֣�");
								flag = true;
								break;
							}
						}
					}

					if (!flag) {
						if (!boardOwner.isLock) {
							startI = 0;
							startJ = 0;
							System.out.println("�������� ��ѧ� ��֧ݧܧߧ�� �� �ܧ�ݧ�ߧܧ� �٧ѧ�ѧ�ߧ��� ��ѧ��֧ۣ�"
									+ piece.getCategory());
							winkPiece.setVisible(true);
							winkPiece = piece;
							needWink = true;
							isSelected = true;
							winkPieceAtBoard = false;
						} else {
							return;
						}
					} else {
						System.out.println("�������� ��ѧ� ��֧ݧܧߧ�� �� �ܧ�ݧ�ߧܧ� �٧ѧ�ѧ�ߧ��� ��ѧ��֧ۣ�" + piece.getCategory());
						System.out.println("����� �ӧ����� ��֧ݧ�ܧ� ��� ��ѧ�ާѧ�ߧ�� ��ڧԧ��� �ܧ���էڧߧѧ�� �ܧ�ߧ֧�ߧ�� ����ܧ� ��ѧӧߧ�m=" + endI + "n="
								+ endJ);

						if (piece.getName().equals(winkPiece.getName())) {
							winkPiece.setVisible(true);
							winkPiece = piece;
							needWink = true;
							startI = endI;
							startJ = endJ;
							isSelected = true;
							winkPieceAtBoard = true;
							System.out.println("���� �ӧ����� ��ѧ� �� ��֧ݧܧߧ�� ��� ��ѧ�ާѧ�ߧ�� ��ڧԧ��� �ߧ� ���� �ا� ������ߧ� �է��ܧ� �� �ӧ��ҧ�ѧ�"
									+ piece.getCategory());
						}

						else {
							System.out.println("����ԧէ� �ӧ� ��֧ݧܧѧ֧�� ��� ��ڧԧ��� �����ڧӧߧڧܧ� �ӧ� �ӧ����� ��ѧ�, �ܧ���էڧߧѧ�� �ܧ�ߧ֧�ߧ�� ����ܧ� ��ѧӧߧ�m=" + endI
									+ "n=" + endJ);

							pieceRemoved = chessPoints[endI][endJ].getPiece();

							if (winkPieceAtBoard) {
								canMove = ChessRule
										.partialRule(winkPiece, startI, startJ,
												endI, endJ, chessPoints);
								if (canMove) {
									if (boardOwner.isLock) {
										board.addChessRecord(winkPiece, startI,
												startJ, endI, endJ);
										boardOwner.curIndex++;
										changeSide();

									}

									movePiece(winkPiece, startI, startJ, endI,
											endJ);

									boardOwner.piecesPanel.add(pieceRemoved);
									needWink = false;
									winkPiece.setVisible(true);
									isSelected = false;
									ChessUtil.playSound("eat.wav");

								}
							}

							else {
								canMove = ChessRule
										.partialRule(winkPiece, startI, startJ,
												endI, endJ, chessPoints);
								if (canMove) {
									board.remove(pieceRemoved);

									chessPoints[endI][endJ].setPiece(winkPiece,
											board);
									chessPoints[endI][endJ].setHasPiece(true);

									boardOwner.piecesPanel.add(pieceRemoved);
									needWink = false;
									winkPiece.setVisible(true);
									isSelected = false;
									ChessUtil.playSound("eat.wav");
								}
							}

						}
					}

				}

			}
			setCursor(defaultCursor);
			validateAll();
		}
	}


	public void changeSide() {
		if (playerName.equals(RED_NAME)) {
			playerName = BLACK_NAME;
		} else if (playerName.equals(BLACK_NAME)) {
			playerName = RED_NAME;
		}
	}

	public void validateAll() {
		System.out.println("���ҧߧ�ӧڧ�");
		validate();
		repaint();
		boardOwner.validate();
	}


	private Point isPieceAtBoard(ChessPiece piece) {
		for (int r = 1; r <= 9; r++) {
			for (int s = 1; s <= 10; s++) {
				ChessPiece p = chessPoints[r][s].getPiece();
				if (p != null && chessPoints[r][s].hasPiece()
						&& p.equals(piece)) {

					return new Point(r, s);
				}
			}
		}
		return null;
	}

	@Override
	protected Color getBackgroundColor() {
		return ColorUtil.getDefaultBgcolor();
	}

	@Override
	protected MouseAdapter getMouseAdapter() {
		return new PartialMouseAdapter(this);
	}

	@Override
	protected BoardType getBoardType() {
		return BoardType.printPartial;
	}

}
