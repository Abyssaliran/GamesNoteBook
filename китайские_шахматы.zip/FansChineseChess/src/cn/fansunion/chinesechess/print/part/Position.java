
package cn.fansunion.chinesechess.print.part;

import java.awt.Point;
import java.io.Serializable;

import cn.fansunion.chinesechess.core.ChessPiece.PieceId;



public class Position implements Serializable {

	private static final long serialVersionUID = 1L;

	private PieceId id;

	private Point point;

	public PieceId getId() {
		return id;
	}

	public void setId(PieceId id) {
		this.id = id;
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

}
