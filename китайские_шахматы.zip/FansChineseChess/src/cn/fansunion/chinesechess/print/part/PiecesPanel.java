
package cn.fansunion.chinesechess.print.part;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JPanel;

import cn.fansunion.chinesechess.ChessUtil;



public class PiecesPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private String imgName = "";

	public PiecesPanel(String imgName) {
		this.imgName = imgName;
	}

	public PiecesPanel(GridLayout layout) {
		super(layout);
	}

	protected void paintComponent(Graphics g) { 
		super.paintComponent(g);
		Dimension size = new Dimension(super.getWidth(), super.getHeight());
		g.drawImage(ChessUtil.getImage(imgName), 0, 0, size.width,
				size.height, null);
		//g.drawString("fans", 200, 20);
	}

}
