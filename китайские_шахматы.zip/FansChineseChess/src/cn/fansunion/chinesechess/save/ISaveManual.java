
package cn.fansunion.chinesechess.save;

import java.util.ArrayList;


public interface ISaveManual {

	public GameRecord getGameRecord();


	public ArrayList<String> getSavePaths();
}
