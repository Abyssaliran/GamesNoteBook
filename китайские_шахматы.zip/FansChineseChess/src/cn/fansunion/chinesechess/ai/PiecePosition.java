
package cn.fansunion.chinesechess.ai;

import java.awt.Point;

import cn.fansunion.chinesechess.core.ChessPiece;


public class PiecePosition {
	public ChessPiece piece;

	public Point pos;

}
