
package cn.fansunion.chinesechess.ai;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Stack;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.HelpDialog;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessBoard;
import cn.fansunion.chinesechess.core.ChessManual;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.ChessPoint;
import cn.fansunion.chinesechess.core.ChessRule;
import cn.fansunion.chinesechess.core.ManualItem;
import cn.fansunion.chinesechess.core.MoveStep;
import cn.fansunion.chinesechess.core.PieceUtil;
import cn.fansunion.chinesechess.core.ChessPiece.PieceId;
import cn.fansunion.chinesechess.save.GameRecord;
import cn.fansunion.chinesechess.save.ISaveManual;
import cn.fansunion.chinesechess.save.SaveAsDialog;
import cn.fansunion.chinesechess.save.SaveDialog;
import cn.fansunion.chinesechess.save.GameRecord.ManualType;



public class ManMachineGUI extends JFrame implements ActionListener,
		NAME, ISaveManual {

	private static final long serialVersionUID = 266L;

	private static final int MAX_VALUE = 3000;

	private int maxDepth;
	
	private ChessPoint[][] globalChessPoints;

	private ChessBoard globalBoard;

	private ManualItem bestChessMove;

	private JButton reprint, save, saveAs, set, exit, help, undo;

	private JButton manualBox;

	// private ArrayList<ChessMove> records;

	private ManMachineBoard board;

	private ChessManual chessManual;

	private ChessPoint[][] chessPoints;

	private JPanel gameStatusPanel;


	private Stack<ManualItem> moveStack = new Stack<ManualItem>();

	private JLabel gameStatusContent, gameStatusIcon;

	public int curIndex = -1;

	private JScrollPane manualScroll;

	private JList manual;

	private Vector descs;

	private Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);


	public ManMachineGUI() {

		board = new ManMachineBoard();
		board.initChess(true);
		board.boardOwner = this;

		chessManual = board.chessManual;
		manualScroll = chessManual.manualScroll;
		manual = chessManual.manualList;
		chessPoints = board.chessPoints;
		descs = chessManual.descs;
		// records = chessManual.getChessRecords();

		initButtons();
		initPanels();
		handleKeyEvent();

		setSize(660, 600);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setResizable(false);
		setIconImage(ChessUtil.getAppIcon());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}

		});
	}


	private void initPanels() {
		JPanel rightPanel = new JPanel(new BorderLayout());

		JPanel recordsPanel = new JPanel(new BorderLayout());

		TitledBorder recordsBorder = new TitledBorder(PropertyReader.get("CHESS_MESSAGE_TOOLTIP"));
		recordsPanel.setBorder(recordsBorder);
		recordsPanel.setPreferredSize(new Dimension(240, 330));
		recordsPanel.add(BorderLayout.CENTER, chessManual);

		/*
		 * //��ѧߧ֧ݧ� �ڧߧ����ާ֧ߧ���  manualTools = new JPanel(new FlowLayout(FlowLayout.CENTER)); //
		 * manualTools.setPreferredSize(new Dimension(220, 20));
		 * manualTools.add(first); manualTools.add(prev); manualTools.add(auto);
		 * manualTools.add(next); manualTools.add(last);
		 * 
		 * recordsPanel.add(BorderLayout.SOUTH, manualTools);
		 */
		JPanel controlPanel = new JPanel(new GridLayout(3, 1));

		FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
		JPanel one = new JPanel(layout);
		JPanel two = new JPanel(layout);
		JPanel three = new JPanel(layout);

		one.add(save);
		one.add(saveAs);

		two.add(reprint);
		two.add(undo);
		two.add(manualBox);

		three.add(help);
		three.add(set);
		three.add(exit);

		controlPanel.add(one);
		controlPanel.add(two);
		controlPanel.add(three);
		// controlPanel.add(four);
		rightPanel.add(BorderLayout.NORTH, recordsPanel);
		rightPanel.add(BorderLayout.CENTER, controlPanel);

		JSplitPane splitH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, board,
				rightPanel);
		splitH.setDividerSize(5);
		splitH.setDividerLocation(450);
		add(splitH, BorderLayout.CENTER);

		gameStatusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		gameStatusPanel.setPreferredSize(new Dimension(660, 80));
		// gameStatusPanel.setBackground(new Color(122, 146, 170));
		gameStatusIcon = new JLabel(ChessUtil.getImageIcon("hongshuai.png"));
		gameStatusContent = new JLabel("����ѧ�ߧѧ� ������ߧ� �էӧڧا֧��� ��֧�ӧ��");
		gameStatusContent.setFont(new Font("����", Font.PLAIN, 16));

		TitledBorder gameStatusBorder = new TitledBorder("��������ߧڧ� �ڧԧ��");
		gameStatusBorder.setTitleColor(Color.RED);
		gameStatusBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		gameStatusPanel.setToolTipText("��������ߧڧ� �ڧԧ��");
		gameStatusPanel.setBorder(gameStatusBorder);

		gameStatusPanel.add(gameStatusIcon);
		gameStatusPanel.add(gameStatusContent);

		add(BorderLayout.SOUTH, gameStatusPanel);

	}


	private void initButtons() {

		Insets insets = new Insets(1, 1, 1, 1);

		reprint = new JButton("��������ڧ٧ӧ֧���", ChessUtil.getImageIcon("reprint.gif"));
		reprint.setToolTipText("����ѧܧ�ڧܧ� ��ߧ�ӧ�");
		reprint.addActionListener(this);
		// reprint.setPreferredSize(dimension);
		reprint.setCursor(handCursor);
		reprint.setMargin(insets);

		save = new JButton("���ѧ���", ChessUtil.getImageIcon("save.gif"));
		save.addActionListener(this);
		save.setToolTipText("������ѧߧڧ�� �٧ѧ�ڧ�� �ڧԧ��");
		// save.setPreferredSize(dimension);
		save.setCursor(handCursor);
		save.setMargin(insets);

		saveAs = new JButton("������ѧߧڧ�� �ܧѧ�", ChessUtil.getImageIcon("saveas.gif"));
		saveAs.addActionListener(this);
		saveAs.setToolTipText("������ѧߧڧ�� �ܧѧ� �٧ѧ�ڧ�� �ڧԧ��");
		// saveAs.setPreferredSize(dimension);
		saveAs.setCursor(handCursor);
		saveAs.setMargin(insets);

		undo = new JButton("���֧�ߧ����� �� ���֧է��է��֧ާ� ��ѧԧ�", ChessUtil.getImageIcon("undo.gif"));
		undo.addActionListener(this);
		undo.setToolTipText("���֧�ߧ����� �� ���֧է��է��֧ާ� ��ѧԧ�");
		undo.setCursor(handCursor);
		undo.setMargin(insets);

		set = new JButton("���ѧ����ڧ��", ChessUtil.getImageIcon("welcome.gif"));
		set.setToolTipText("���ѧ����ڧ��");
		set.addActionListener(this);
		set.setCursor(handCursor);
		set.setMargin(insets);

		help = new JButton("����ާ�ԧڧ��", ChessUtil.getImageIcon("help.gif"));
		help.setToolTipText("����ާ�ԧڧ��");
		help.addActionListener(this);
		help.setCursor(handCursor);
		help.setMargin(insets);

		exit = new JButton("�ӧ��ҧ��ӧѧ��", ChessUtil.getImageIcon("stop.gif"));
		exit.setToolTipText("�ӧ��ҧ��ӧѧ��");
		exit.addActionListener(this);
		exit.setCursor(handCursor);
		exit.setMargin(insets);

		manualBox = new JButton("���ѧ�ާѧ�ߧ��� ��֧ܧ���", ChessUtil.getImageIcon("stop.gif"));
		manualBox.setToolTipText("���ѧ�ާѧ�ߧ��� ��֧ܧ���");
		manualBox.addActionListener(this);
		manualBox.setCursor(handCursor);
		manualBox.setMargin(insets);

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		if (source == help) {
			HelpDialog help = new HelpDialog();
			help.setVisible(true);
		} else if (source == set) {

		}

		else if (source == reprint) {
			int result = JOptionPane.showConfirmDialog(this, "���ѧ� �ߧ�اߧ� �����ѧߧڧ�� ��֧ܧ��ڧ� �ڧԧ��ӧ�� ��֧ܧ���?",
					"���ѧ� �ߧ�اߧ� �����ѧߧڧ�� ��֧ܧ��ڧ� �ڧԧ��ӧ�� ��֧ܧ���?", JOptionPane.YES_NO_OPTION);

			if (result == JOptionPane.YES_OPTION) {
				SaveDialog dialog = new SaveDialog(this);
				dialog.setVisible(true);
			}

			dispose();
			ManMachineGUI newPrint = new ManMachineGUI();
			newPrint.setVisible(true);

		}

		else if (source == undo) {

			boolean flag = chessManual.removeManualItem();
			if (flag) {
				if (board.getPlayerName().equals(RED_NAME)) {
					board.changeSide();
					updateGameStatus(2, "����ڧ�ݧ� ���֧�֧է� ��֧�ߧ��� �ڧէ�ڣ�");
				} else {
					board.changeSide();
					updateGameStatus(1, "���ѧ��ѧݧ� ���֧�֧է� �ܧ�ѧ�ߧ�� �ڧէ�ڣ�");
				}
			}
			curIndex--;
		} else if (source == save) {
			SaveDialog dialog = new SaveDialog(this);
			dialog.setVisible(true);

		} else if (source == saveAs) {
			SaveAsDialog dialog = new SaveAsDialog(this);
			dialog.setVisible(true);
		} else if (source == exit) {
			dispose();
		} else if (source == manualBox) {
			String manual = JOptionPane.showInputDialog(this, "����اѧݧ�ۧ���, �ӧӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��", "����اѧݧ�ۧ���, �ӧӧ֧էڧ�� �٧ѧ�ڧ�� �ڧԧ��",
					JOptionPane.OK_CANCEL_OPTION);
			if (manual != null) {
				manual = manual.trim();
			}
			movePieceByManual(manual);

		}

	}


	private void movePieceByManual(String manual) {
		if (manual != null && manual.length() == 4) {
			ChessPiece movePiece = board.getMovePiece(manual);
			if (movePiece == null) {
				return;
			}
			ChessPiece removedPiece = board.getRemovedPiece(manual);
			Point pStart = board.getStartPosition(manual);
			Point pEnd = board.getEndPosition(manual);

			int startX = (int) pStart.getX();
			int startY = (int) pStart.getY();
			int endX = (int) pEnd.getX();
			int endY = (int) pEnd.getY();
			System.out.println(movePiece.getCategory() + " :" + startX + startY
					+ endX + endY);
			boolean rule = ChessRule.allRule(movePiece, startX, startY, endX,
					endY, board.chessPoints);
			System.out.println("����ا֧� ��֧�֧ާ֧�ѧ�� ��ڧԧ�����" + rule);
			if (rule) {
				board.movePiece(movePiece, startX, startY, endX, endY);

				ManualItem record = new ManualItem();
				MoveStep moveStep = new MoveStep(new Point(startX, startY),
						new Point(endX, endY));
				record.setMoveStep(moveStep);
				if (removedPiece != null) {
					record.setEatedPieceId(removedPiece.getId());
				} else {
					record.setEatedPieceId(null);
				}
				record.setMovePieceId(movePiece.getId());
				board.chessManual.addManualItem(record);

				curIndex++;


				ChessUtil.playSound("eat.wav");

				
				validate();
				repaint();


				board.changeSide();

			}
		}
	}


	public void scrollToView() {
		if (curIndex >= 0 && curIndex < descs.size()) {

			System.out.println("���ݧ֧է�֧� �ӧ��ҧ�ѧ�� �����ܧ� N��" + curIndex);
			manual.setSelectedIndex(curIndex);

			int lastIndex = curIndex;
			Rectangle rect = manual.getCellBounds(lastIndex, lastIndex);
			manualScroll.getViewport().scrollRectToVisible(rect);

		}
		if (curIndex == -1) {
			board.setMoveFlag(false);

			System.out.println("������ܧ� �ߧ� �ӧ��ҧ�ѧߧѣ�" + curIndex);
			manual.setListData(descs);
		}
	}


	private void handleKeyEvent() {
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {
			public void eventDispatched(AWTEvent event) {
				if (((KeyEvent) event).getID() == KeyEvent.KEY_PRESSED) {
					int code = ((KeyEvent) event).getKeyCode();
					if (code == KeyEvent.VK_F1) {
						ChessUtil.showHelpDialog();
					}
				}
			}
		}, AWTEvent.KEY_EVENT_MASK);

	}

	private void handleExitGame() {
		if (board.getWinkThread() != null) {
			board.getWinkThread().interrupt();
			System.out.println("���ѧܧ����ڧ֣�");
		}
		dispose();
	}

	public void updateGameStatus(int state, String content) {

		switch (state) {
		case 1:
			gameStatusIcon.setIcon(ChessUtil.getImageIcon("hongshuai.png"));
			gameStatusIcon.setToolTipText("���ѧ��ѧݧ� ���֧�֧է� �ܧ�ѧ�ߧ�� �ڧէ�ڣ�");
			break;
		case 2:
			gameStatusIcon.setIcon(ChessUtil.getImageIcon("heijiang.png"));
			gameStatusIcon.setToolTipText("����ڧ�ݧ� ���֧�֧է� ��֧�ߧ��� �ڧէ�ڣ�");
			break;
		default:
			break;
		}

		if (content != null && !content.equals("")) {
			gameStatusContent.setText(content);
		}
	}


	private void minMaxSearch2(int depth) {
		if (board.getPlayerName().equals(RED_NAME)) {
			maxSearch(depth);
		} else {
			minSearch(depth);
		}
	}


	private int maxSearch(int depth) {
		int best = -MAX_VALUE;
		int value = 0;
		if (depth == 0) {
			return AIUtil.evaluate(board.getPlayerName(), globalChessPoints);
		}

		ArrayList<ManualItem> chessMoves = AIUtil.generateAllChessMove(board
				.getPlayerName(), globalChessPoints);
		int size = chessMoves.size();

		for (int index = 0; index < size; index++) {
			ManualItem chessMove = chessMoves.get(index);
			makeMove(chessMove);
			value = minSearch(depth - 1);
			unMakeMove();
			if (value > best) {
				best = value;
				if (depth == maxDepth) {
					bestChessMove = chessMove;
					System.out.println("maxSearch ���ѧ�֧� �ݧ���ڧ� ������ң�");
				}
			}
		}
		return best;

	}


	private int minSearch(int depth) {
		int best = MAX_VALUE;
		int value = 0;
		if (depth == 0) {
			return AIUtil.evaluate(board.getPlayerName(), globalChessPoints);
		}
		ArrayList<ManualItem> chessMoves = AIUtil.generateAllChessMove(board
				.getPlayerName(), globalChessPoints);
		int size = chessMoves.size();
		// System.out.println("���֧ܧ��ڧ� �ާ֧��� ���է�ҧ���" + size);
		for (int index = 0; index < size; index++) {
			ManualItem chessMove = chessMoves.get(index);
			makeMove(chessMove);
			value = maxSearch(depth - 1);
			unMakeMove();
			if (value < best) {
				best = value;
				if (depth == maxDepth) {
					System.out.println("minSearch ���ѧ�֧� �ݧ���ڧ� ������ң�");
					bestChessMove = chessMove;
				}
			}
		}
		return best;

	}

	private void makeMove(ManualItem chessMove) {
		moveStack.add(chessMove);
		MoveStep moveStep = chessMove.getMoveStep();
		int startX = (int) moveStep.getStart().getX();
		int startY = (int) moveStep.getStart().getY();
		int endX = (int) moveStep.getEnd().getX();
		int endY = (int) moveStep.getEnd().getY();

		ChessPiece piece = globalChessPoints[startX][startY].getPiece();
		ChessPiece eatedPiece = globalChessPoints[endX][endY].getPiece();
		globalChessPoints[endX][endY].removePiece(eatedPiece, globalBoard);
		globalChessPoints[endX][endY].setPiece(piece, globalBoard);
		globalChessPoints[startX][startY].setHasPiece(false);

		board.changeSide();
	}

	private void unMakeMove() {
		ManualItem chessMove = moveStack.pop();
		MoveStep moveStep = chessMove.getMoveStep();
		PieceId eatedPieceId = chessMove.getEatedPieceId();

		int startX = (int) moveStep.getStart().getX();
		int startY = (int) moveStep.getStart().getY();
		int endX = (int) moveStep.getEnd().getX();
		int endY = (int) moveStep.getEnd().getY();

		ChessPiece piece = globalChessPoints[endX][endY].getPiece();
		ChessPiece eatedPiece = PieceUtil.createPiece(eatedPieceId);

		globalChessPoints[startX][startY].setPiece(piece, globalBoard);
		globalChessPoints[endX][endY].setPiece(eatedPiece, globalBoard);

		board.changeSide();
	}


	public static void main(String[] args) {
		// int[][][][] is = AIUtil.positionValues;

		ManMachineGUI ai = new ManMachineGUI();
		ai.setVisible(true);
		// ai.computerThink();
		// ai.fenTest();

		// PieceUtil.printPieceLoations(ai.globalChessPoints);
	}

	/**
	 * @param printManual
	 */
	private void fenTest() {
		String arrayToFenString = FenUtil.arrayToFenString(board.chessPoints,
				board.getPlayerName());
		System.out.println(arrayToFenString + "\n");
		globalBoard = FenUtil.fenStringToArray(arrayToFenString);
		globalChessPoints = globalBoard.chessPoints;
		PieceUtil.printPieceLoations(globalBoard.chessPoints);

		ArrayList<ManualItem> chessMoves = AIUtil.generateAllChessMove(RED_NAME,
				globalBoard.chessPoints);
		printChessMove(chessMoves);
	}

	private void test() {
		String arrayToFenString = FenUtil.arrayToFenString(board.chessPoints,
				board.getPlayerName());
		System.out.println(arrayToFenString + "\n");
		globalBoard = FenUtil.fenStringToArray(arrayToFenString);
		globalChessPoints = globalBoard.chessPoints;
		PieceUtil.printPieceLoations(globalChessPoints);

	}

	private void printChessMove(ArrayList<ManualItem> chessMoves) {
		int size = chessMoves.size();
		for (int index = 0; index < size; index++) {
			ManualItem chessMove = chessMoves.get(index);

			MoveStep moveStep = chessMove.getMoveStep();
			Point start = moveStep.getStart();
			Point end = moveStep.getEnd();
			System.out.println("�ߧ�ާ֧�" + index + "�ާ֧��գ�(" + start.getX() + ","
					+ start.getY() + ")->" + end.getX() + "," + end.getY()
					+ ")");
		}

	}

	/**
	 * ���� Javadoc��
	 * 
	 * @see com.fans.chess.common.ISaveManual#getSavePaths()
	 */
	public ArrayList<String> getSavePaths() {
		ArrayList<String> paths = new ArrayList<String>();
		String path = "manuals/ai/";
		String path2 = "manuals/ai/";

		paths.add(path);
		paths.add(path2);
		return paths;
	}

	public GameRecord getGameRecord() {
		GameRecord gameRecord = new GameRecord(ManualType.MAN_MACHINE, ChessUtil
				.getDateAndTime(), "", board.chessManual.getManualItems(),
				board.chessManual.descs, null);
		return gameRecord;
	}

	public void computerThink() {
		test();

		// globalChessPoints = chessPoints.clone();
		/*
		 * System.out.println("globalChessPoints == chessPoints " +
		 * (globalChessPoints == chessPoints));
		 */
		bestChessMove = null;
		maxDepth = 4;
		// negalMaxSearch(MAX_DEPTH);
		alphaBetaSearch(maxDepth, -MAX_VALUE, MAX_VALUE);
		if (bestChessMove == null) {
			System.out.println("���� �ߧѧ�֧� �ݧ���֧ԧ� ����ڣ�");
			return;
		}
		MoveStep step = bestChessMove.getMoveStep();
		int startX = (int) step.getStart().getX();
		int startY = (int) step.getStart().getY();
		int endX = (int) step.getEnd().getX();
		int endY = (int) step.getEnd().getY();
		System.out.println("(" + startX + "," + startY + "),(" + endX + ","
				+ endY + ")");
		ChessPiece movePiece = chessPoints[startX][startY].getPiece();

		board.addChessRecord(movePiece, startX, startY, endX, endY);
		board.movePiece(movePiece, startX, startY, endX, endY);
		board.changeSide();

	}

	/**
	 * 
	 * 
	 * @param depth
	 * @return
	 */
	private int alphaBetaSearch(int depth, int alpha, int beta) {
		// int best = 0;
		int value = 0;

		// best = -MAX_VALUE;

		if (depth == 0) {
			return AIUtil.evaluate2(board.getPlayerName(), globalChessPoints);
		}

		ArrayList<ManualItem> chessMoves = AIUtil.generateAllChessMove(board
				.getPlayerName(), globalChessPoints);
		printChessMove(chessMoves);
		int size = chessMoves.size();

		for (int index = 0; index < size; index++) {
			ManualItem chessMove = chessMoves.get(index);
			makeMove(chessMove);
			value = -alphaBetaSearch(depth - 1, -beta, -alpha);
			unMakeMove();

			if (value >= beta) {
				return beta;
			}
			if (value > alpha) {
				alpha = value;
				if (depth == maxDepth) {
					bestChessMove = chessMove;
					System.out.println("maxSearch ���ѧ�֧� �ݧ���ڧ� ������ң�");
				}
			}

		}
		return alpha;

	}


	private int negalMaxSearch(int depth) {
		int best = 0;
		int value = 0;

		best = -MAX_VALUE;

		if (depth == 0) {
			return AIUtil.evaluate(board.getPlayerName(), globalChessPoints);
		}

		ArrayList<ManualItem> chessMoves = AIUtil.generateAllChessMove(board
				.getPlayerName(), globalChessPoints);
		printChessMove(chessMoves);
		int size = chessMoves.size();

		for (int index = 0; index < size; index++) {
			ManualItem chessMove = chessMoves.get(index);
			makeMove(chessMove);
			value = -negalMaxSearch(depth - 1);
			unMakeMove();

			if (value > best) {
				best = value;
				if (depth == maxDepth) {
					bestChessMove = chessMove;
					System.out.println("maxSearch ���ѧ�֧� �ݧ���ڧ� ������ң�");
				}
			}

		}
		return best;

	}


	private int minMaxSearch22(int depth) {
		int best = 0;
		int value = 0;
		if (board.getPlayerName().equals(RED_NAME)) {
			best = MAX_VALUE;
		} else {
			best = -MAX_VALUE;
		}

		if (depth == 0) {
			return AIUtil.evaluate(board.getPlayerName(), globalChessPoints);
		}

		ArrayList<ManualItem> chessMoves = AIUtil.generateAllChessMove(board
				.getPlayerName(), globalChessPoints);
		printChessMove(chessMoves);
		int size = chessMoves.size();

		for (int index = 0; index < size; index++) {
			ManualItem chessMove = chessMoves.get(index);
			makeMove(chessMove);
			value = minSearch(depth - 1);
			unMakeMove();
			if (board.getPlayerName().equals(RED_NAME)) {
				if (value < best) {
					best = value;
					if (depth == maxDepth) {
						bestChessMove = chessMove;
						System.out.println("maxSearch ���ѧ�֧� �ݧ���ڧ� ������ң�");
					}
				}
			} else {
				if (value > best) {
					best = value;
					if (depth == maxDepth) {
						bestChessMove = chessMove;
						System.out.println("maxSearch ���ѧ�֧� �ݧ���ڧ� ������ң�");
					}
				}
			}
		}
		return best;

	}

}
