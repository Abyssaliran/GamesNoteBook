
package cn.fansunion.chinesechess;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.net.NetworkConstants;
import cn.fansunion.chinesechess.net.common.Creator;
import cn.fansunion.chinesechess.net.common.CreatorTableModel;
import cn.fansunion.chinesechess.net.common.JTableUtil;
import cn.fansunion.chinesechess.net.common.Member;
import cn.fansunion.chinesechess.net.common.Message;
import cn.fansunion.chinesechess.net.common.MsgPacket;
import cn.fansunion.chinesechess.net.common.Player;
import cn.fansunion.chinesechess.net.common.PlayerTableModel;
import cn.fansunion.chinesechess.net.common.Message.MessageType;
import cn.fansunion.chinesechess.net.common.MsgPacket.MsgType;
import cn.fansunion.chinesechess.net.common.MsgPacket.PlayerRole;
import cn.fansunion.chinesechess.net.server.ListenPlayer;
import cn.fansunion.chinesechess.net.server.User;
import cn.fansunion.chinesechess.net.server.UserStream;



public class ServerGUI extends JFrame implements ActionListener, NAME {

	private static final long serialVersionUID = 1L;


	private int cid = 0;


	private JComboBox msgComboBox;


	private String[] initialMsgs = { "���ѧ� �ӧ���֧��", "���������ڧ��, �� ���է�اէ�, ���ܧ� ��ӧ֧�� ������ �ߧ� �ҧ�է�� �ҧݧѧԧ�էѧ�ߧ�", "���� ���ݧڧ�ߧ� ����ԧ�ѧ�",
			"���ԧ�ѧ� ��ߧ�ӧ� �� ��ݧ֧է���ڧ� ��ѧ�, �� ����ا�" };


	private String[] initialUsers = { "���ѧاէ���" };


	private JComboBox userComboBox;


	private JButton send;

	private JTextArea msgArea;

	private JTextArea inAndOutArea;

	private JTable leftTable, rightTable;

	private ServerSocket serverSocket;

	private final ExecutorService pool;


	private List<Player> players = Collections
			.synchronizedList(new ArrayList<Player>());


	private List<UserStream> userStreams = Collections
			.synchronizedList(new ArrayList<UserStream>());

	public List<Creator> creators = Collections
			.synchronizedList(new ArrayList<Creator>());


	public static void main(String[] args) {

		String lookAndFeel = null;
		lookAndFeel = UIManager.getSystemLookAndFeelClassName();
		try {
			UIManager.setLookAndFeel(lookAndFeel);
		} catch (Exception e) {
			System.out.println("����ڧҧܧ� ���� �ߧѧ����ۧܧ� �ݧ�ܧѧݧ�ߧ�ԧ� �ӧߧ֧�ߧ֧ԧ� �ӧڧէѣ�");
			e.printStackTrace();
		}

		ServerGUI serverFrame = new ServerGUI();
		serverFrame.setLocationRelativeTo(null);
		serverFrame.work();
	}


	public ServerGUI() {
		pool = Executors.newFixedThreadPool(NetworkConstants.POOL_SIZE);
		initButtons();// 
		initMenu();// 
		initPanels();// 

		addWindowListener(new WindowAdapter() {

			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}


			public void windowActivated(WindowEvent e) {
				msgComboBox.requestFocusInWindow();
			};
		});

		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setSize(1002, 700);
		setTitle("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��");
		setVisible(true);
		// setIconImage(FansUtil.getAppIcon());

	}

	protected boolean handleExitGame() {
		shutdownAndAwaitTermination();
		if (serverSocket != null) {
			try {
				serverSocket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.exit(0);
		return false;
	}


	private void shutdownAndAwaitTermination() {
		pool.shutdown(); // Disable new tasks from being submitted
		try {
			// Wait a while for existing tasks to terminate
			if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
				pool.shutdownNow(); // Cancel currently executing tasks
				// Wait a while for tasks to respond to being cancelled
				if (!pool.awaitTermination(60, TimeUnit.SECONDS))
					System.err.println("Pool did not terminate");
			}
		} catch (InterruptedException ie) {
			// (Re-)Cancel if current thread also interrupted
			pool.shutdownNow();
			// Preserve interrupt status
			Thread.currentThread().interrupt();
		}
	}


	private void initPanels() {
		JPanel leftPanel, rightPanel;

		int[] widths = { 8, 8, 2, 8 };

		leftTable = new JTable(new CreatorTableModel());
		leftTable.setGridColor(Color.BLUE);

		JTableUtil.fitTableColumns(leftTable, widths);

		TitledBorder gameBorder = new TitledBorder("���ߧ���ާѧ�ڧ� �� �ҧڧ�ӧ�");
		leftPanel = new JPanel(new BorderLayout());
		leftPanel.setBorder(gameBorder);
		leftPanel.setPreferredSize(new Dimension(500, 700));

		JScrollPane creatorScroll = new JScrollPane(leftTable);
		leftTable.setPreferredSize(new Dimension(470, 240));
		leftTable.setRowHeight(20);
		creatorScroll.setPreferredSize(new Dimension(474, 268));


		JPanel creatorPanel = new JPanel();
		creatorPanel.setPreferredSize(new Dimension(480, 300));
		TitledBorder creatorBorder = new TitledBorder("���ߧ���ާѧ�ڧ� �� �ӧݧѧէ֧ݧ���");
		creatorPanel.setBorder(creatorBorder);
		creatorPanel.add(creatorScroll);


		JPanel msgPanel = new JPanel(new BorderLayout());
		TitledBorder msgBorder = new TitledBorder("����ӧ���� �ڧԧ��ܧ��");
		msgPanel.setBorder(msgBorder);

		msgArea = new JTextArea();
		msgArea.setRows(10);
		msgArea.setFont(new Font("����", Font.PLAIN, 16));
		msgArea.setEditable(false);
		JScrollPane displayScroll = new JScrollPane(msgArea);


		JPanel sendMsgPanel = new JPanel(new BorderLayout());


		msgComboBox = new JComboBox(initialMsgs);
		msgComboBox.setSelectedIndex(-1);
		msgComboBox.setPreferredSize(new Dimension(290, 30));

		msgComboBox.setEditable(true);
		msgComboBox.setToolTipText(PropertyReader.get("MSG_JCOMBOBOX_TOOLTIP"));
		msgComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));
		msgComboBox.grabFocus();


		userComboBox = new JComboBox(initialUsers);

		userComboBox.setSelectedIndex(0);


		userComboBox.setEditable(false);
		userComboBox.setPreferredSize(new Dimension(80, 30));
		userComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));
		userComboBox.setToolTipText(PropertyReader
				.get("USER_JCOMBOBOX_TOOLTIP"));


		JPanel panel = new JPanel(new FlowLayout());
		panel.add(msgComboBox);
		panel.add(send);
		panel.add(userComboBox);
		sendMsgPanel.add(BorderLayout.NORTH, panel);

		msgPanel.add(BorderLayout.CENTER, displayScroll);
		msgPanel.add(BorderLayout.SOUTH, sendMsgPanel);

		leftPanel.add(BorderLayout.NORTH, creatorPanel);
		leftPanel.add(BorderLayout.CENTER, msgPanel);


		rightTable = new JTable(new PlayerTableModel());
		rightTable.setGridColor(Color.BLUE);
		rightTable.setRowHeight(20);
		rightTable.setPreferredSize(new Dimension(450, 400));
		JTableUtil.fitTableColumns(rightTable, widths);

		rightPanel = new JPanel(new BorderLayout());
		JScrollPane playersScroll = new JScrollPane(rightTable);
		playersScroll.setPreferredSize(new Dimension(470, 430));
		rightPanel.add(BorderLayout.NORTH, playersScroll);
		TitledBorder playerBorder = new TitledBorder("����ڧ��� �ڧԧ��ܧ��");
		rightPanel.setBorder(playerBorder);
		rightPanel.setPreferredSize(new Dimension(500, 700));

		JPanel inAndOutPanel = new JPanel();
		TitledBorder inAndOutBorder = new TitledBorder("�ӧ���֧�ڧ��񧱧���ѧ�");
		inAndOutPanel.setBorder(inAndOutBorder);

		inAndOutArea = new JTextArea();
		inAndOutArea.setRows(6);
		inAndOutArea.setFont(new Font("����", Font.PLAIN, 16));
		inAndOutArea.setEditable(false);
		inAndOutArea.setPreferredSize(new Dimension(440, 130));
		JScrollPane inAndOutAreaScroll = new JScrollPane(inAndOutArea);
		inAndOutAreaScroll.setPreferredSize(new Dimension(450, 150));
		inAndOutPanel.add(inAndOutAreaScroll);
		rightPanel.add(BorderLayout.CENTER, inAndOutPanel);


		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,
				leftPanel, rightPanel);
		split.setDividerSize(2);
		split.setDividerLocation(500);

		add(split, BorderLayout.CENTER);

	}


	private void initMenu() {

	}

	private void initButtons() {
		ImageIcon ii = ChessUtil.getImageIcon("send.png");
		int width = ii.getIconWidth();
		int height = ii.getIconHeight();
		send = new JButton(ChessUtil.getImageIcon("send.png"));
		send.addActionListener(this);
		send.setPreferredSize(new Dimension(width, height));
		send.setToolTipText(PropertyReader.get("SEND_JBUTTON_TOOLTIP"));
		send.setCursor(new Cursor(Cursor.HAND_CURSOR));

	}


	private void work() {
		try {

		 serverSocket = new ServerSocket(NetworkConstants.PORT);

			String time = ChessUtil.getTime();
			msgArea.append(SERVER_NAME + ":���ѧ�ѧ�� ���ڧ�ݧ��ڧӧѧ���� �� �٧ѧ����ѧ� ���ݧ�٧�ӧѧ�֧ݧ֧� --" + time + "\n");

			while (true) {
				Socket playerSocket = serverSocket.accept();

				ObjectOutputStream oos = new ObjectOutputStream(
						playerSocket.getOutputStream());
				ObjectInputStream ois = new ObjectInputStream(
						playerSocket.getInputStream());

				MsgPacket packet = (MsgPacket) ois.readObject();
				System.out.println("�����֧�ߧ� ���ݧ��ڧ�� �ڧާ� �ڧԧ��ܧѣ�" + packet.getName());
				MsgType status = packet.getMsgType();

				String name = "fans";
				if (status == MsgType.PLAYER_LOGIN) {
					name = packet.getName();
				}
				String loginTime = ChessUtil.getTime();
				inAndOutArea.append(name + "�����֧� �� �ܧ�ާߧѧ��  --" + loginTime + "\n");

				String ipAddress = playerSocket.getInetAddress()
						.getHostAddress();
				String gameStatus = "��ӧ�ҧէߧ�";

				User user = new User();
				user.setName(name);
				user.setIp(ipAddress);
				Player player = new Player(user, loginTime, ipAddress,
						gameStatus);
				players.add(player);
				updatePlayers();

				UserStream userStream = new UserStream(name, oos, ois,
						playerSocket);
				userStreams.add(userStream);

				System.out.println("���֧�ӧ֧� �����ѧӧڧ� ���ڧ��� ���٧էѧ�֧ݧ֧� �ߧ�ӧ��� �ڧԧ��ܧѧ�");
				MsgPacket serverPacket2 = new MsgPacket();
				serverPacket2.setMsgType(MsgType.CREATOR_LIST);
				serverPacket2.setCreators(creators);
				sendPacket(oos, serverPacket2);

				System.out.println("���֧�ӧ֧� �����ѧӧڧ� ���ڧ��� �ڧԧ��ܧ�� �ߧ�ӧ�ާ� �ڧԧ��ܧ�");
				MsgPacket serverPacket = new MsgPacket();
				serverPacket.setMsgType(MsgType.PLAYER_LIST);
				serverPacket.setPlayers(players);
				oos.writeObject(serverPacket);

				System.out.println("���֧�ӧ֧� �����ѧӧڧ� �ӧ�֧� �ڧԧ��ܧѧ� ����ҧ�֧ߧڧ� �� ���ڧ��֧էڧߧ֧ߧڧ� �ߧ�ӧ�ԧ� �ڧԧ��ܧ�.");
				MsgPacket serverPacket3 = new MsgPacket();
				serverPacket3.setMsgType(MsgType.ADD_PLAYER);
				serverPacket3.setPlayer(player);
				notifyAllPlayers(oos, serverPacket3);

				ListenPlayer task = new ListenPlayer(this, oos, ois,
						playerSocket);
				pool.execute(task);

			}
		} catch (IOException ex) {
			System.err.println(ex);
			ex.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


	public void sendPacket(ObjectOutputStream oos, MsgPacket packet) {
		try {
			if (oos != null) {
				oos.writeObject(packet);
				oos.flush();
				System.out.println("���֧�ӧ֧� ����֧�ߧ� �����ѧӧڧ� ����ҧ�֧ߧڧ� " + "����ѧ��� ����ҧ�֧ߧڧ�" + packet.getMsgType());
			} else {
				System.out.println("�������էߧ�� ������ �����, �էѧߧߧ��� �ߧ� �����ѧӧݧ�����");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	public void notifyAllPlayers(ObjectOutputStream oos, MsgPacket packet) {
		int size = userStreams.size();
		System.out.println("�� �ߧѧ�����֧� �ӧ�֧ާ�" + size + "���ԧ��ܧ�");
		boolean isConnected = true;

		for (int i = 0; i < size; i++) {
			try {
				UserStream userStream = userStreams.get(i);
				Socket s = userStream.getSocket();
				ObjectOutputStream out = userStream.getOos();
				isConnected = s.isConnected() && !s.isClosed();
				if (isConnected) {
					if (out != oos) {
						out.writeObject(packet);
					}
				} else {
					System.out.println("���ا� �٧ѧܧ����࣡");
				}
				System.out.println("���֧�ӧ֧� ��ܧѧا֧� �ڧԧ��ܧ�" + userStream.getName()
						+ "������ѧӧڧ�� �ڧߧ���ާѧ�ڧ� �� �ߧ�ӧ��� �ڧԧ��ܧѧ�");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


	public void notifyAllPlayers(MsgPacket packet) {
		int size = userStreams.size();

		boolean isConnected = true;

		for (int i = 0; i < size; i++) {
			try {
				UserStream userStream = userStreams.get(i);
				Socket s = userStream.getSocket();
				isConnected = s.isConnected() && !s.isClosed();
				ObjectOutputStream out = userStream.getOos();
				if (isConnected) {
					if (out != null) {
						out.writeObject(packet);
						System.out.println("���֧�ӧ֧� ��ܧѧا֧� �ڧԧ��ܧ�" + userStream.getName()
								+ "������ѧӧڧ�� �ڧߧ���ާѧ�ڧ� ����ѧ��� ����ҧ�֧ߧڧ�" + packet.getMsgType());
					} else {
						System.out.println("�������էߧ�� ������ �����, �ߧ֧ӧ�٧ާ�اߧ� �����ѧӧڧ�� �էѧߧߧ��֣�");
					}
				} else {
					System.out.println("���ѧܧ����࣡");
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


	public void subMember(MsgPacket packet) {
		Creator creator = packet.getCreator();
		String name = packet.getName();
		Creator tempCreator = null;
		for (int i = 0; i < creators.size(); i++) {
			tempCreator = creators.get(i);

			if ((creator != null) && (tempCreator.getCid() == creator.getCid())) {
				System.out.println("id" + creator.getCid() + "����ѧ��ߧڧ� �ڧ� ���ڧ�ܧ� �ѧӧ����� ���ܧڧߧ�ݣ�"
						+ name);

				for (int j = 0; j < tempCreator.getMembers().size(); j++) {
					if (tempCreator.getMembers().get(j).getName().equals(name)) {
						tempCreator.getMembers().remove(j);
						break;
					}
				}
			}
		}
		updateCreators();

		MsgPacket sp = new MsgPacket();
		sp.setMsgType(MsgType.PLAYER_EXIT_CREATED_GAME);
		sp.setCreator(creator);
		sp.setName(packet.getName());
		if (tempCreator != null) {
			for (int i = 0; i < tempCreator.getMembers().size(); i++) {
				sp.members.add(tempCreator.getMembers().get(i));
			}
		}
		notifyAllPlayers(sp);
	}


	public void updateCreators() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				leftTable.setValueAt("", i, j);
			}
		}

		int size = creators.size();
		System.out.println("��֧�֧�� ������" + size + "���٧էѧ�֧ݧ�");

		for (int index = 0; index < size; index++) {
			Creator creator = creators.get(index);
			leftTable.setValueAt(creator.getUser().getName(), index, 0);
			leftTable.setValueAt(creator.getDate(), index, 1);
			leftTable.setValueAt(1 + creator.getMembers().size(), index, 2);
			leftTable.setValueAt(creator.getGameStatus(), index, 3);
		}
	}


	public void addMemer(MsgPacket packet) {
		Member member = packet.getMember();
		int cid = member.getCid();
		MsgPacket membersPacket = new MsgPacket();

		membersPacket.setName(packet.getName());
		System.out.println("�������� �ڧԧ��ܧ�� id" + cid);
		Creator creator;
		for (int index = 0; index < creators.size(); index++) {
			creator = creators.get(index);
			if (creator.getCid() == cid) {
				System.out.println("���ԧ��� ����֧�ߧ� �է�ҧѧӧݧ֧� �� ���ڧ��� ���ѧ��ߧڧܧ�ӣ�");
				creator.getMembers().add(member);
				membersPacket.setMsgType(MsgType.PLAYER_JOIN_CREATED_GAME);
				membersPacket.setCreator(creator);

				for (int m = 0; m < creator.getMembers().size(); m++) {
					membersPacket.members.add(creator.getMembers().get(m));
				}
				break;
			}
		}
		updateCreators();
		notifyAllPlayers(membersPacket);
	}


	public void addCreator(MsgPacket serverPacket) {

		Creator creator = serverPacket.getCreator();
		creator.setCid(cid++);

		creators.add(0, creator);
		updateCreators();

		for (int m = 0; m < creators.size(); m++) {
			serverPacket.getCreators().add(creators.get(m));
		}
		serverPacket.setCreator(creator);
		notifyAllPlayers(serverPacket);

	
		MsgPacket sp = new MsgPacket();

		sp.setCreator(creator);

		sp.setMsgType(MsgType.CREATOR_AND_MEMBER);
		int num = userStreams.size();
		for (int index = 0; index < num; index++) {
			UserStream userStream = userStreams.get(index);
			if (userStream.getName().equals(creator.getUser().getName())) {
				System.out.println("���֧�ӧ֧� �����ѧӧڧ� ���٧էѧ�֧ݧ� �� ��ݧ֧ߧ� �ڧߧ���ާѧ�ڧ� ���٧էѧ�֧ݧ�");
				sendPacket(userStream.getOos(), sp);
				break;
			}
		}

	}


	public void subCreator(MsgPacket packet) {
		String name = packet.getName();

		int size = creators.size();
		for (int index = 0; index < size; index++) {
			Creator creator = creators.get(index);
			if (creator.getUser().getName().equals(name)) {
				System.out.println("���ӧ��� ��էѧݧ֧�");
				creators.remove(index);
				break;
			}
		}
		updateCreators();


		MsgPacket sp = new MsgPacket();
		sp.setMsgType(MsgType.SUB_CREATOR);
		sp.setName(name);
		System.out.println("���ӧ֧է�ާڧ�� �ܧݧڧ֧ߧ�� �� ���ܧ�ѧ�֧ߧڧ� ��էߧ�ԧ� ���٧էѧ�֧ݧ�");
		notifyAllPlayers(sp);

		MsgPacket spExit = new MsgPacket();
		spExit.setMsgType(MsgType.CREATOR_EXIT_CREATED_GAME);
		spExit.setName(name);
		notifyAllPlayers(spExit);
	}


	public void subPlayer(MsgPacket packet) {
		String name = packet.getName();
		inAndOutArea.append(name + "����ܧڧߧ��� �ܧ�ާߧѧ��  --" + ChessUtil.getTime() + "\n");
		int size = players.size();
		for (int i = 0; i < size; i++) {
			Player player = players.get(i);
			if (player.getUser().getName().equals(name)) {
				System.out.println("����ڧ��� �ڧԧ��ܧ�� ��֧�ӧ֧�� ��էѧݧ֧�" + name);
				players.remove(i);
				break;
			}
		}
		updatePlayers();

		int uSize = userStreams.size();
		for (int i = 0; i < uSize; i++) {
			if (userStreams.get(i).getName().equals(name)) {
				MsgPacket sp = new MsgPacket();
				sp.setMsgType(MsgType.SUB_PLAYER);
				sp.setName(name);
				notifyAllPlayers(userStreams.get(i).getOos(), sp);
				break;
			}
		}

		int userSize = userStreams.size();
		for (int index = 0; index < userSize; index++) {
			if (userStreams.get(index).getName().equals(name)) {
				userStreams.remove(index);
				break;
			}
		}
	}


	private void updatePlayers() {

		for (int i = 0; i < NetworkConstants.PLAYER_MAX_SIZE; i++) {
			for (int j = 0; j < 4; j++) {
				rightTable.setValueAt("", i, j);
			}
		}

		userComboBox.removeAllItems();
		userComboBox.addItem("���ѧاէ���");


		int size = players.size();
		for (int i = 0; i < size; i++) {
			Player p = players.get(i);
			rightTable.setValueAt(p.getUser().getName(), i, 0);
			rightTable.setValueAt(p.getIpAddress(), i, 1);
			rightTable.setValueAt(p.getLoginTime(), i, 2);
			rightTable.setValueAt(p.getGameStatus(), i, 3);
			userComboBox.addItem(p.getUser().getName());
		}

	}


	public void startGame(MsgPacket packet) {
		String name = packet.getName();
		Creator creator = new Creator();
		int size = creators.size();
		for (int index = 0; index < size; index++) {
			creator = creators.get(index);
			if (creator.getUser().getName().equals(name)) {
				creator.setGameStatus(CREATOR_PK);
				break;
			}
		}

		int mSize = creator.getMembers().size();
		for (int i = 0; i < mSize; i++) {
			String n = creator.getMembers().get(i).getName();

			int userSize = userStreams.size();
			for (int index = 0; index < userSize; index++) {
				if (userStreams.get(index).getName().equals(n)) {
					sendPacket(userStreams.get(index).getOos(), packet);
					System.out.println("�� �ڧԧ��ܧ�" + n + "������ѧӧڧ�� ���ѧ���ӧ�� ����ҧ�֧ߧڧ֣�");
				}
			}

			int playersSize = players.size();
			for (int m = 0; m < playersSize; m++) {
				String name2 = players.get(m).getUser().getName();
				if (name2.equals(n)
						|| name2.equals(creator.getUser().getName())) {
					players.get(m).setGameStatus(CREATOR_PK);
				}
			}
		}

		updateCreators();
		updatePlayers();

		MsgPacket sp = new MsgPacket();
		sp.setMsgType(MsgType.CHANGE_GAME_STATUS);
		sp.setCreator(creator);
		notifyAllPlayers(sp);

	}


	public void handleDataPacket(MsgPacket packet) {
		MsgType status = packet.getMsgType();


		if (status == MsgType.GAME_EXIT) {
			notifyGroupOtherPlayers(packet);

			PlayerRole role = packet.getRole();
			String name = packet.getName();
			if (role == PlayerRole.ROLE_OBSERVER) {
				System.out.println("���ѧҧݧ�էѧ�֧ݧ�" + "�����ۧ�� �ڧ� �ڧԧ��");
			} else if (role == PlayerRole.ROLE_BLACK) {

				System.out.println("���ԧ���" + "�����ۧ�� �ڧ� �ڧԧ��");
			} else if (role == PlayerRole.ROLE_RED) {
				int size = creators.size();
				for (int index = 0; index < size; index++) {
					Creator creator = creators.get(index);
					if (creator.getUser().getName().equals(name)) {

						creators.remove(index);
						updateCreators();
						break;
					}
				}
				MsgPacket sp = new MsgPacket();
				sp.setMsgType(MsgType.SUB_CREATOR);
				sp.setName(packet.getName());
				notifyAllPlayers(sp);
				System.out.println("���٧էѧ�֧ݧ�" + "�����ۧ�� �ڧ� �ڧԧ��");
			}

		}

		else if (status == MsgType.GAME_MESSAGE) {
			System.out.println("���֧�ӧ֧� ���ݧ��ڧ� �ڧԧ��ӧ�� ����ҧ�֧ߧڧ�");
			MessageType state = packet.getMessage().getStatus();
			if (state == MessageType.TO_ALL) {
				System.out.println("���֧�ӧ֧� �����ѧӧݧ�֧� ����ҧ�֧ߧڧ� �է��ԧڧ� ���ѧ��ߧڧܧѧ� �ԧ�����");
				notifyGroupOtherPlayers(packet);
			} else if (state == MessageType.TO_SOME) {
				System.out.println("���֧�ӧ֧� �����ѧӧݧ�֧� ����ҧ�֧ߧڧ� ��ݧ֧ߧ� �ԧ�����");
				notifyPlayersByName(packet.names, packet);
			}
		} else {

		}

	}


	public void handleChangeRole(MsgPacket packet) {
		System.out.println("���֧�ӧ֧� ��ҧ�ѧҧѧ���ӧѧ֧� ����ҧ�֧ߧڧ� ��� �ڧ٧ާ֧ߧ֧ߧڧ� ���ݧڣ�");
		notifyGroupOtherPlayers(packet);
	}


	public void notifyGroupOtherPlayers(MsgPacket sp) {

		String name = sp.getName();

		ArrayList<String> dest = new ArrayList<String>();
		Creator creator = new Creator();


		int size = creators.size();
		for (int index = 0; index < size; index++) {
			creator = creators.get(index);

			if (creator.getUser().getName().equals(name)) {
				int memberSize = creator.getMembers().size();
				for (int i = 0; i < memberSize; i++) {
					String n = creator.getMembers().get(i).getName();
					dest.add(n);
				}
				break;
			}

			boolean flag = false;
			int mSize = creator.getMembers().size();
			for (int i = 0; i < mSize; i++) {
				String n = creator.getMembers().get(i).getName();
				if (n.equals(name)) {
					flag = true;
				}
			}


			if (flag) {
				dest.add(creator.getUser().getName());
				for (int i = 0; i < creator.getMembers().size(); i++) {
					String n = creator.getMembers().get(i).getName();
					if (!n.equals(name)) {
						dest.add(n);
					}
				}
			}
		}
		this.notifyPlayersByName(dest, sp);
	}


	public void notifyPlayersByName(ArrayList<String> names, MsgPacket sp) {
		for (int i = 0; i < names.size(); i++) {
			String n = names.get(i);


			for (int j = 0; j < userStreams.size(); j++) {
				UserStream userStream = userStreams.get(j);
				if (userStream.getName().equals(n)) {
					sendPacket(userStream.getOos(), sp);
				}
			}
		}
	}


	public void handleRoomMessage(MsgPacket packet) {
		Message m = packet.getMessage();
		msgArea.append(packet.getName() + ":" + m.getContent() + "\n");
	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == send) {

			send();
		}
	}


	private void send() {
		String msg = (String) msgComboBox.getSelectedItem();

		if (msg == null || msg.equals("")) {
			JOptionPane.showMessageDialog(null, "����է֧�اѧߧڧ� ��ѧ�� �ߧ� �ާ�ا֧� �ҧ���� ��������.");
			return;
		}


		Message message = new Message();
		message.setContent(msg);
		message.setDate(ChessUtil.getDateAndTime());
		message.setStatus(MessageType.SYSTEM);


		MsgPacket sp = new MsgPacket();
		sp.setMessage(message);
		sp.setMsgType(MsgType.ROOM_MESSAGE);
		sp.setName(SERVER_NAME);


		String dest = (String) userComboBox.getSelectedItem();

		ArrayList<String> names = new ArrayList<String>();
		names.add(dest);

		if (dest.equals("���ѧاէ���")) {
			notifyAllPlayers(sp);
		} else {
			notifyPlayersByName(names, sp);
		}

		msgComboBox.setSelectedIndex(-1);
		msgArea.append(SERVER_NAME + ":" + msg + "\n");

	}
}
