
package cn.fansunion.chinesechess.core;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;

import javax.swing.JPanel;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.ColorUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessPiece.PieceCategory;
import cn.fansunion.chinesechess.core.ChessPiece.PieceId;



public abstract class ChessBoard extends JPanel implements NAME, Runnable {

	private static final long serialVersionUID = 1L;

	// ����ݧڧ�֧��ӧ� ���ܧ��, �ܧ������� �ާ�ԧ�� ��է֧�اڧӧѧ�� ��ѧ�ާѧ�ߧ��� ��ڧԧ��� �� �ԧ��ڧ٧�ߧ�ѧݧ�ߧ�� �ߧѧ��ѧӧݧ֧ߧڧ� ��ѧ�ާѧ�ߧ�� �է��ܧ�.
	public static final int X = 9;

	// ����ݧڧ�֧��ӧ� ���ܧ��, �ܧ������� �ާ�ԧ�� ��է֧�اڧӧѧ�� ��ѧ�ާѧ�ߧ��� ��ڧԧ��� �� �ӧ֧��ڧܧѧݧ�ߧ�� �ߧѧ��ѧӧݧ֧ߧڧ� ��ѧ�ާѧ�ߧ�� �է��ܧ�.
	public static final int Y = 10;

	// ���ڧ�ڧߧ� �� �ӧ������ �ܧݧ֧�ܧ� ��ѧ�ާѧ�ߧ�� �է��ܧ�
	public static int UNIT_WIDTH = ChessPiece.UNIT_WIDTH;

	public static int UNIT_HEIGHT = ChessPiece.UNIT_HEIGHT;

	public static int PIECE_WIDTH = ChessPiece.PIECE_WIDTH;

	public static int PIECE_HEIGHT = ChessPiece.PIECE_HEIGHT;


	public enum BoardType {
		printWhole, printPartial, network, manMachine, eightEmpress, horseMaze
	}

	protected ArrayList<Point> sidePoints = new ArrayList<Point>(14);

	// ���ݧ��֧�ߧѧ�ڧӧߧ��� ���է� ��֧ܧ��֧� ��ڧԧ���
	protected ArrayList<Point> tipPoints = new ArrayList<Point>();

	public ChessPoint chessPoints[][];

	protected boolean moveFlag = false;

	// MoveStep
	public Point[] movePoints = new Point[] { new Point(), new Point() };

	// 16 �ܧ�ѧ�ߧ��� ��ѧ�ާѧ�ߧ��� ��ڧԧ��
	public ChessPiece ��܇1, ��܇2, ���R1, ���R2, ����1, ����2, �쎛, ����1, ����2, ���1, ���2,
			���3, ���4, ���5, ����1, ����2;

	// 16 ��֧�ߧ��� ��ѧ�ާѧ�ߧ��� ��ڧԧ��
	public ChessPiece ��܇1, ��܇2, ���R1, ���R2, ����1, ����2, �ڌ�, ��ʿ1, ��ʿ2, ����1, ����2,
			����3, ����4, ����5, ����1, ����2;

	// �������� �� �ӧڧէ� ���ܧ�
	public static Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);

	// �������� ��� ��ާ�ݧ�ѧߧڧ�
	public static Cursor defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);


	protected ChessPiece winkPiece;


	protected boolean isSelected = false;


	protected boolean needWink = false;


	protected boolean move = false;


	protected Thread winkThread;

	protected int startI, startJ;

	public ChessManual chessManual = null;

	protected String playerName;


	public ChessBoard() {
		super();
		setLayout(null);
		setBackground(getBackgroundColor());
		addMouseListener(getMouseAdapter());


		chessPoints = new ChessPoint[X + 1][Y + 1];
		for (int i = 1; i <= X; i++) {
			for (int j = 1; j <= Y; j++) {
				chessPoints[i][j] = new ChessPoint(i * UNIT_WIDTH, j
						* UNIT_HEIGHT);
			}
		}
		init32Pieces();
		init32PiecesTooltip();


		chessManual = new ChessManual(this);


		initPBFlag();

		winkThread = new Thread(this);
		winkThread.start();
	}


	protected Color getBackgroundColor() {
		return ColorUtil.getDefaultBgcolor();
	}


	private void init32PiecesTooltip() {
		��܇1.setToolTipText(PropertyReader.get("JU_TOOLTIP"));
		��܇2.setToolTipText(PropertyReader.get("JU_TOOLTIP"));
		��܇1.setToolTipText(PropertyReader.get("JU_TOOLTIP"));
		��܇2.setToolTipText(PropertyReader.get("JU_TOOLTIP"));

		����1.setToolTipText(PropertyReader.get("PAO_TOOLTIP"));
		����2.setToolTipText(PropertyReader.get("PAO_TOOLTIP"));
		����1.setToolTipText(PropertyReader.get("PAO_TOOLTIP"));
		����2.setToolTipText(PropertyReader.get("PAO_TOOLTIP"));

		���R1.setToolTipText(PropertyReader.get("MA_TOOLTIP"));
		���R2.setToolTipText(PropertyReader.get("MA_TOOLTIP"));
		���R1.setToolTipText(PropertyReader.get("MA_TOOLTIP"));
		���R2.setToolTipText(PropertyReader.get("MA_TOOLTIP"));

		���1.setToolTipText(PropertyReader.get("BING_TOOLTIP"));
		���2.setToolTipText(PropertyReader.get("BING_TOOLTIP"));
		���3.setToolTipText(PropertyReader.get("BING_TOOLTIP"));
		���4.setToolTipText(PropertyReader.get("BING_TOOLTIP"));
		���5.setToolTipText(PropertyReader.get("BING_TOOLTIP"));

		����1.setToolTipText(PropertyReader.get("ZU_TOOLTIP"));
		����2.setToolTipText(PropertyReader.get("ZU_TOOLTIP"));
		����3.setToolTipText(PropertyReader.get("ZU_TOOLTIP"));
		����4.setToolTipText(PropertyReader.get("ZU_TOOLTIP"));
		����5.setToolTipText(PropertyReader.get("ZU_TOOLTIP"));

		����1.setToolTipText(PropertyReader.get("HONGSHI_TOOLTIP"));
		����2.setToolTipText(PropertyReader.get("HONGSHI_TOOLTIP"));

		��ʿ1.setToolTipText(PropertyReader.get("HEISHI_TOOLTIP"));
		��ʿ2.setToolTipText(PropertyReader.get("HEISHI_TOOLTIP"));

		����1.setToolTipText(PropertyReader.get("HEIXIANG_TOOLTIP"));
		����2.setToolTipText(PropertyReader.get("HEIXIANG_TOOLTIP"));

		����1.setToolTipText(PropertyReader.get("HONGXIANG_TOOLTIP"));

		����2.setToolTipText(PropertyReader.get("HONGXIANG_TOOLTIP"));

		�쎛.setToolTipText(PropertyReader.get("SHUAI_TOOLTIP"));
		�ڌ�.setToolTipText(PropertyReader.get("JIANG_TOOLTIP"));

	}


	private void init32Pieces() {
		��܇1 = PieceUtil.createPiece(PieceId.HONGJU1);
		��܇2 = PieceUtil.createPiece(PieceId.HONGJU2);
		���R1 = PieceUtil.createPiece(PieceId.HONGMA1);
		���R2 = PieceUtil.createPiece(PieceId.HONGMA2);
		����1 = PieceUtil.createPiece(PieceId.HONGPAO1);
		����2 = PieceUtil.createPiece(PieceId.HONGPAO2);
		����1 = PieceUtil.createPiece(PieceId.HONGXIANG1);
		����2 = PieceUtil.createPiece(PieceId.HONGXIANG2);
		����1 = PieceUtil.createPiece(PieceId.HONGSHI1);
		����2 = PieceUtil.createPiece(PieceId.HONGSHI2);
		�쎛 = PieceUtil.createPiece(PieceId.SHUAI);
		���1 = PieceUtil.createPiece(PieceId.BING1);
		���2 = PieceUtil.createPiece(PieceId.BING2);
		���3 = PieceUtil.createPiece(PieceId.BING3);
		���4 = PieceUtil.createPiece(PieceId.BING4);
		���5 = PieceUtil.createPiece(PieceId.BING5);

		�ڌ� = PieceUtil.createPiece(PieceId.JIANG);
		��ʿ1 = PieceUtil.createPiece(PieceId.HEISHI1);
		��ʿ2 = PieceUtil.createPiece(PieceId.HEISHI2);
		��܇1 = PieceUtil.createPiece(PieceId.HEIJU1);
		��܇2 = PieceUtil.createPiece(PieceId.HEIJU2);
		����1 = PieceUtil.createPiece(PieceId.HEIPAO1);
		����2 = PieceUtil.createPiece(PieceId.HEIPAO2);
		����1 = PieceUtil.createPiece(PieceId.HEIXIANG1);
		����2 = PieceUtil.createPiece(PieceId.HEIXIANG2);
		���R1 = PieceUtil.createPiece(PieceId.HEIMA1);
		���R2 = PieceUtil.createPiece(PieceId.HEIMA2);
		����1 = PieceUtil.createPiece(PieceId.ZU1);
		����2 = PieceUtil.createPiece(PieceId.ZU2);
		����3 = PieceUtil.createPiece(PieceId.ZU3);
		����4 = PieceUtil.createPiece(PieceId.ZU4);
		����5 = PieceUtil.createPiece(PieceId.ZU5);

		�쎛.addMouseListener(getMouseAdapter());
		����1.addMouseListener(getMouseAdapter());
		����2.addMouseListener(getMouseAdapter());
		����1.addMouseListener(getMouseAdapter());
		����2.addMouseListener(getMouseAdapter());
		��܇1.addMouseListener(getMouseAdapter());
		��܇2.addMouseListener(getMouseAdapter());
		���R1.addMouseListener(getMouseAdapter());
		���R2.addMouseListener(getMouseAdapter());
		����1.addMouseListener(getMouseAdapter());
		����2.addMouseListener(getMouseAdapter());
		���1.addMouseListener(getMouseAdapter());
		���2.addMouseListener(getMouseAdapter());
		���3.addMouseListener(getMouseAdapter());
		���4.addMouseListener(getMouseAdapter());
		���5.addMouseListener(getMouseAdapter());

		�ڌ�.addMouseListener(getMouseAdapter());
		��ʿ1.addMouseListener(getMouseAdapter());
		��ʿ2.addMouseListener(getMouseAdapter());
		����1.addMouseListener(getMouseAdapter());
		����2.addMouseListener(getMouseAdapter());
		����1.addMouseListener(getMouseAdapter());
		����2.addMouseListener(getMouseAdapter());
		��܇1.addMouseListener(getMouseAdapter());
		��܇2.addMouseListener(getMouseAdapter());
		���R1.addMouseListener(getMouseAdapter());
		���R2.addMouseListener(getMouseAdapter());
		����1.addMouseListener(getMouseAdapter());
		����2.addMouseListener(getMouseAdapter());
		����3.addMouseListener(getMouseAdapter());
		����4.addMouseListener(getMouseAdapter());
		����5.addMouseListener(getMouseAdapter());
	}


	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		drawBackgroundImage(g);

		Graphics2D g2 = (Graphics2D) g;

		BasicStroke bsFlag = new BasicStroke(2);		
		BasicStroke bsLine = new BasicStroke(2);


		BasicStroke bs1 = new BasicStroke(1);

		drawLines(g2, bsLine, bs1);

		drawJiuGongLines(g2, bs1);

		drawChuheHanjieString(g2);

		drawPaoBingFlag(g2, bsFlag);


		drawMoveFlag(g2);
		drawWillMoveFlag(g2);


		BasicStroke bsOld = new BasicStroke(1);
		g2.setStroke(bsOld);
		g2.setFont(new Font("����", Font.PLAIN, 14));
		g2.setColor(new Color(0, 0, 0));
		drawShuXianFlag(g2);
	}

	private void drawBackgroundImage(Graphics g) {

		Image image = getBackgroundImage();
		if (image != null) {
			Dimension size = new Dimension(super.getWidth(), super.getHeight());
			g.drawImage(image, 0, 0, size.width, size.height, null);
		}

	}

	protected Image getBackgroundImage() {
		return null;
	}


	protected void drawShuXianFlag(Graphics2D g2) {

		for (int i = 1; i <= X; i++) {
			g2.drawString("" + i, i * UNIT_WIDTH - 4, UNIT_HEIGHT / 2 - 4);
		}

		for (int i = 1; i <= X; i++) {
			g2.drawString("" + ChessUtil.numToZi(10 - i), i * UNIT_WIDTH - 4,
					10 * UNIT_HEIGHT + 34);
		}
	}

	/**
	 * @param g2
	 */
	private void drawWillMoveFlag(Graphics2D g2) {

		int tipSize = tipPoints.size();
		int distance = PIECE_WIDTH - 6;

		for (int i = 0; i < tipSize; i++) {
			int a = (int) tipPoints.get(i).getX();
			int b = (int) tipPoints.get(i).getY();


			int boardX = chessPoints[a][b].getX();
			int boardY = chessPoints[a][b].getY();

			Color color;

			color = new Color(82, 72, 255);
			BasicStroke bs = new BasicStroke(2);
			g2.setStroke(bs);
			ChessPiece piece = chessPoints[a][b].getPiece();
			if (piece != null && !piece.getName().equals(playerName)) {
				if (playerName.equals(RED_NAME)) {

					color = new Color(255, 0, 0);
				} else {

					color = new Color(0, 0, 0);
				}
				drawMoveTips2(g2, boardX, boardY, color);
			} else {

				drawMoveTips(g2, distance, boardX, boardY, color);
			}
		}
	}


	private void drawMoveFlag(Graphics2D g2) {
		if (moveFlag) {
			int d = PIECE_WIDTH - 6;
			int a = 0, b = 0;
			for (int i = 0; i < movePoints.length; i++) {

				a = (int) movePoints[i].getX();
				b = (int) movePoints[i].getY();

				int boardX = chessPoints[a][b].getX();
				int boardY = chessPoints[a][b].getY();
				Color c = new Color(0, 128, 0);
				BasicStroke bs = new BasicStroke(2);
				g2.setStroke(bs);
				drawMoveTips(g2, d, boardX, boardY, c);
			}
		}
	}


	private void drawPaoBingFlag(Graphics2D g2, BasicStroke bsFlag) {

		int size = sidePoints.size();
		double x = PIECE_WIDTH / 9;
		double side = PIECE_WIDTH / 6;
		for (int i = 0; i < size; i++) {
			double a = sidePoints.get(i).getX();
			double b = sidePoints.get(i).getY();
			g2.setStroke(bsFlag);
			if (i >= 0 && i <= 9) {
				drawPBMiddle(g2, x, side, a, b);
			} else if (i == 10 || i == 11) {
				drawPBRight(g2, x, side, a, b);
			} else if (i == 12 || i == 13) {
				drawPBLeft(g2, x, side, a, b);
			}

		}
	}


	private void drawChuheHanjieString(Graphics2D g2) {

		g2.setFont(new Font("����", Font.PLAIN, 32));
		g2.drawString("�h ��", chessPoints[2][5].getX(), chessPoints[2][5].getY()
				+ 2 * UNIT_HEIGHT / 3 + 2);
		g2.drawString("�� ��", chessPoints[6][5].getX(), chessPoints[2][5].getY()
				+ 2 * UNIT_HEIGHT / 3 + 2);
	}


	private void drawJiuGongLines(Graphics2D g2, BasicStroke bs1) {

		g2.setStroke(bs1);
		g2.drawLine(chessPoints[4][1].getX(), chessPoints[4][1].getY(),
				chessPoints[6][3].getX(), chessPoints[6][3].getY());
		g2.drawLine(chessPoints[6][1].getX(), chessPoints[6][1].getY(),
				chessPoints[4][3].getX(), chessPoints[4][3].getY());
		g2.drawLine(chessPoints[4][8].getX(), chessPoints[4][8].getY(),
				chessPoints[6][Y].getX(), chessPoints[6][Y].getY());
		g2.drawLine(chessPoints[4][Y].getX(), chessPoints[4][Y].getY(),
				chessPoints[6][8].getX(), chessPoints[6][8].getY());
	}


	private void drawLines(Graphics2D g2, BasicStroke bsLine, BasicStroke bs1) {

		for (int j = 1; j <= Y; j++) {
			if (j == 1 || j == 5 || j == 6 || j == 10) {
				g2.setStroke(bsLine);
				g2.drawLine(chessPoints[1][j].getX(), chessPoints[1][j].getY(),
						chessPoints[X][j].getX(), chessPoints[X][j].getY());
			} else {
				g2.setStroke(bs1);
				g2.drawLine(chessPoints[1][j].getX(), chessPoints[1][j].getY(),
						chessPoints[X][j].getX(), chessPoints[X][j].getY());
			}
		}


		for (int i = 1; i <= X; i++) {
			if (i != 1 && i != X) {

				g2.setStroke(bs1);
				g2.drawLine(chessPoints[i][1].getX(), chessPoints[i][1].getY(),
						chessPoints[i][Y - 5].getX(),
						chessPoints[i][Y - 5].getY());
				g2.drawLine(chessPoints[i][Y - 4].getX(),
						chessPoints[i][Y - 4].getY(), chessPoints[i][Y].getX(),
						chessPoints[i][Y].getY());
			} else {

				g2.setStroke(bsLine);
				g2.drawLine(chessPoints[i][1].getX(), chessPoints[i][1].getY(),
						chessPoints[i][Y].getX(), chessPoints[i][Y].getY());
			}
		}
	}

	private void drawMoveTips2(Graphics2D g2, int boardX, int boardY,
			Color color) {
		BasicStroke bs = new BasicStroke(2);
		g2.setStroke(bs);
		g2.setColor(color);
		g2.drawLine(boardX - PIECE_WIDTH / 2, boardY - PIECE_HEIGHT / 2, boardX
				+ PIECE_WIDTH / 2, boardY + PIECE_HEIGHT / 2);
		g2.drawLine(boardX - PIECE_WIDTH / 2, boardY + PIECE_HEIGHT / 2, boardX
				+ PIECE_WIDTH / 2, boardY - PIECE_HEIGHT / 2);

	}


	protected void initTipPoints(ChessPiece piece, int startX, int startY) {
		BoardType boardType = getBoardType();
		if (boardType == null) {
			return;
		}

		boolean rule = false;
		for (int i = 1; i <= 9; i++) {
			for (int j = 1; j <= 10; j++) {
				if (boardType == BoardType.printWhole
						|| boardType == BoardType.manMachine
						|| boardType == BoardType.horseMaze) {
					rule = ChessRule.allRule(piece, startX, startY, i, j,
							chessPoints);
				} else if (boardType == BoardType.printPartial) {
					rule = ChessRule.partialRule(piece, startX, startY, i, j,
							chessPoints);
				} else if (boardType == BoardType.network) {
					rule = ChessRule.networkRule(piece, startX, startY, i, j,
							chessPoints);
				}

				if (rule) {
					boolean flag = ChessRule.isWillDangerous(startX, startY, i,
							j, chessPoints, this);
					if (!flag) {
						tipPoints.add(new Point(i, j));
					}
				}
			}
		}

		repaint();
		validate();
	}

	protected abstract BoardType getBoardType();


	protected void initTipPoints2(ChessPiece piece, int startX, int startY) {
		BoardType boardType = getBoardType();
		PieceCategory pc = piece.getCategory();
		System.out.println("���ѧ�ڧ��ӧѧ�� �ާ֧�ܧڣ�" + pc + startX + "," + startY);
		boolean rule = false;

		switch (pc) {
		case JU:
			for (int i = 1; i <= 9; i++) {
				if (boardType == BoardType.printWhole
						|| boardType == BoardType.manMachine
						|| boardType == BoardType.horseMaze) {
					rule = ChessRule.allRule(piece, startX, startY, i, startY,
							chessPoints);
				} else if (boardType == BoardType.printPartial) {
					rule = ChessRule.partialRule(piece, startX, startY, i,
							startY, chessPoints);
				} else if (boardType == BoardType.network) {
					rule = ChessRule.networkRule(piece, startX, startY, i,
							startY, chessPoints);
				}
				if (rule) {
					tipPoints.add(new Point(i, startY));
				}

			}
			for (int j = 1; j <= 10; j++) {
				if (boardType == BoardType.printWhole) {
					rule = ChessRule.allRule(piece, startX, startY, startX, j,
							chessPoints);
				} else if (boardType == BoardType.printPartial) {
					rule = ChessRule.partialRule(piece, startX, startY, startX,
							j, chessPoints);
				} else if (boardType == BoardType.network) {
					rule = ChessRule.networkRule(piece, startX, startY, startX,
							j, chessPoints);
				}

				if (rule) {
					tipPoints.add(new Point(startX, j));
				}
			}
			break;
		case MA:
			for (int endX = startX - 2; endX <= startX + 2; endX++) {
				for (int endY = startY - 2; endY <= startY + 2; endY++) {
					if (boardType == BoardType.printWhole) {
						rule = ChessRule.allRule(piece, startX, startY, endX,
								endY, chessPoints);
					} else if (boardType == BoardType.printPartial) {
						rule = ChessRule.partialRule(piece, startX, startY,
								endX, endY, chessPoints);
					} else if (boardType == BoardType.network) {
						rule = ChessRule.networkRule(piece, startX, startY,
								endX, endY, chessPoints);
					}

					if (rule) {
						tipPoints.add(new Point(startX, endX));
					}
				}
			}
			break;
		case PAO:
			for (int i = 1; i <= 9; i++) {
				if (boardType == BoardType.printWhole) {
					rule = ChessRule.allRule(piece, startX, startY, i, startY,
							chessPoints);
				} else if (boardType == BoardType.printPartial) {
					rule = ChessRule.partialRule(piece, startX, startY, i,
							startY, chessPoints);
				} else if (boardType == BoardType.network) {
					rule = ChessRule.networkRule(piece, startX, startY, i,
							startY, chessPoints);
				}

				if (rule) {
					tipPoints.add(new Point(i, startY));
				}
			}
			for (int j = 1; j <= 10; j++) {
				if (boardType == BoardType.printWhole) {
					rule = ChessRule.allRule(piece, startX, startY, startX, j,
							chessPoints);
				} else if (boardType == BoardType.printPartial) {
					rule = ChessRule.partialRule(piece, startX, startY, startX,
							j, chessPoints);
				} else if (boardType == BoardType.network) {
					rule = ChessRule.networkRule(piece, startX, startY, startX,
							j, chessPoints);
				}

				if (rule) {
					tipPoints.add(new Point(startX, j));
				}
			}
			break;
		case HONGXIANG:
			break;
		case HEIXIANG:
			break;
		case HONGSHI:
			break;
		case HEISHI:
			break;
		case BING:

			break;
		case ZU:

			break;
		case JIANG:

			break;
		case SHUAI:

			for (int endX = startX - 1; endX <= startX + 1; endX++) {
				for (int endY = startY - 1; endY <= startY + 1; endY++) {
					if (boardType == BoardType.printWhole) {
						rule = ChessRule.allRule(piece, startX, startY, endX,
								endY, chessPoints);
					} else if (boardType == BoardType.printPartial) {
						rule = ChessRule.partialRule(piece, startX, startY,
								endX, endY, chessPoints);
					} else if (boardType == BoardType.network) {
						rule = ChessRule.networkRule(piece, startX, startY,
								endX, endY, chessPoints);
					}

					if (rule) {
						tipPoints.add(new Point(endX, startY));
					}
				}
			}

		}
	}


	private void drawMoveTips(Graphics2D g2, int d, double a, double b,
			Color color) {
		g2.setColor(color);

		g2.drawLine((int) (a - d / 2), (int) (b - d / 2), (int) (a - d / 2),
				(int) (b - d / 4));
		g2.drawLine((int) (a - d / 2), (int) (b - d / 2), (int) (a - d / 4),
				(int) (b - d / 2));

		g2.drawLine((int) (a + d / 2), (int) (b - d / 2), (int) (a + d / 4),
				(int) (b - d / 2));
		g2.drawLine((int) (a + d / 2), (int) (b - d / 2), (int) (a + d / 2),
				(int) (b - d / 4));

		g2.drawLine((int) (a - d / 2), (int) (b + d / 2), (int) (a - d / 2),
				(int) (b + d / 4));
		g2.drawLine((int) (a - d / 2), (int) (b + d / 2), (int) (a - d / 4),
				(int) (b + d / 2));

		g2.drawLine((int) (a + d / 2), (int) (b + d / 2), (int) (a + d / 4),
				(int) (b + d / 2));
		g2.drawLine((int) (a + d / 2), (int) (b + d / 2), (int) (a + d / 2),
				(int) (b + d / 4));
	}

	private void drawPBLeft(Graphics2D g2, double x, double side, double a,
			double b) {

		g2.drawLine((int) (a - x), (int) (b - x), (int) (a - x),
				(int) (b - x - side));
		g2.drawLine((int) (a - x), (int) (b - x), (int) (a - x - side),
				(int) (b - x));

		g2.drawLine((int) (a - x), (int) (b + x), (int) (a - x),
				(int) (b + x + side));
		g2.drawLine((int) (a - x), (int) (b + x), (int) (a - x - side),
				(int) (b + x));
	}

	private void drawPBRight(Graphics2D g2, double x, double side, double a,
			double b) {

		g2.drawLine((int) (a + x), (int) (b - x), (int) (a + x),
				(int) (b - x - side));
		g2.drawLine((int) (a + x), (int) (b - x), (int) (a + x + side),
				(int) (b - x));

		g2.drawLine((int) (a + x), (int) (b + x), (int) (a + x),
				(int) (b + x + side));
		g2.drawLine((int) (a + x), (int) (b + x), (int) (a + x + side),
				(int) (b + x));
	}

	private void drawPBMiddle(Graphics2D g2, double x, double side, double a,
			double b) {

		g2.drawLine((int) (a - x), (int) (b - x), (int) (a - x),
				(int) (b - x - side));
		g2.drawLine((int) (a - x), (int) (b - x), (int) (a - x - side),
				(int) (b - x));

		g2.drawLine((int) (a - x), (int) (b + x), (int) (a - x),
				(int) (b + x + side));
		g2.drawLine((int) (a - x), (int) (b + x), (int) (a - x - side),
				(int) (b + x));


		g2.drawLine((int) (a + x), (int) (b - x), (int) (a + x),
				(int) (b - x - side));
		g2.drawLine((int) (a + x), (int) (b - x), (int) (a + x + side),
				(int) (b - x));

		g2.drawLine((int) (a + x), (int) (b + x), (int) (a + x),
				(int) (b + x + side));
		g2.drawLine((int) (a + x), (int) (b + x), (int) (a + x + side),
				(int) (b + x));
	}


	private void initPBFlag() {

		sidePoints.add(new Point(chessPoints[2][3].getX(), chessPoints[2][3]
				.getY()));
		sidePoints.add(new Point(chessPoints[8][3].getX(), chessPoints[8][3]
				.getY()));
		sidePoints.add(new Point(chessPoints[2][8].getX(), chessPoints[2][8]
				.getY()));
		sidePoints.add(new Point(chessPoints[8][8].getX(), chessPoints[8][8]
				.getY()));


		sidePoints.add(new Point(chessPoints[3][4].getX(), chessPoints[3][4]
				.getY()));
		sidePoints.add(new Point(chessPoints[5][4].getX(), chessPoints[5][4]
				.getY()));
		sidePoints.add(new Point(chessPoints[7][4].getX(), chessPoints[7][4]
				.getY()));
		sidePoints.add(new Point(chessPoints[3][7].getX(), chessPoints[3][7]
				.getY()));
		sidePoints.add(new Point(chessPoints[5][7].getX(), chessPoints[5][7]
				.getY()));
		sidePoints.add(new Point(chessPoints[7][7].getX(), chessPoints[7][7]
				.getY()));


		sidePoints.add(new Point(chessPoints[1][4].getX(), chessPoints[1][4]
				.getY()));
		sidePoints.add(new Point(chessPoints[1][7].getX(), chessPoints[1][7]
				.getY()));
		sidePoints.add(new Point(chessPoints[9][4].getX(), chessPoints[9][4]
				.getY()));
		sidePoints.add(new Point(chessPoints[9][7].getX(), chessPoints[9][7]
				.getY()));

	}


	protected int getPieceYByCategory(int x, PieceCategory pc) {
		if (pc == null) {
			System.out.println("getPieceYByCategory:pc == null");
			return 0;
		}
		int y = 0;
		if (x < 1 || x > 9) {
			return y;
		}

		for (int j = 1; j <= 10; j++) {
			ChessPiece piece = chessPoints[x][j].getPiece();
			if (piece != null && pc.equals(piece.getCategory())
					&& piece.getName().equals(playerName)) {
				System.out.println(playerName + piece.getCategory() + x + ","
						+ +j);
				y = j;
				break;
			}
		}
		return y;

	}


	public ChessPiece getMovePiece(String manual) {
		if (manual == null || manual.length() != 4) {
			return null;
		}

		Point point = getStartPosition(manual);
		int startX = (int) point.getX();
		int startY = (int) point.getY();

		if (startX < 1 || startX > 9 || startY < 1 || startY > 10) {
			return null;
		}
		ChessPiece piece = chessPoints[startX][startY].getPiece();
		System.out.println("���ӧڧا��ڧ֧�� ��ѧ��ڣ�" + piece.getName() + " "
				+ piece.getCategory());
		return piece;

	}


	public ChessPiece getRemovedPiece(String manual) {
		Point point = getEndPosition(manual);

		int endX = (int) point.getX();
		int endY = (int) point.getY();
		if (endX < 1 || endX > 9 || endY < 1 || endY > 10) {
			return null;
		}
		return chessPoints[endX][endY].getPiece();

	}


	public Point getStartPosition(String manual) {
		char name = manual.charAt(0);

		PieceCategory pc = getPieceCategory(manual);

		Point p1 = null;
		Point p2 = null;
		if (name == 'ǰ' || name == '��') {
			for (int i = 1; i <= 9; i++) {
				for (int j = 1; j <= 10; j++) {
					ChessPiece piece = chessPoints[i][j].getPiece();
					if (piece != null && piece.getCategory().equals(pc)
							&& piece.getName().equals(playerName)) {
						if (p1 == null) {
							p1 = new Point(i, j);
						} else {
							p2 = new Point(i, j);
						}
					}
				}
			}
			if (name == 'ǰ' && playerName.equals(RED_NAME)) {
				return p1;
			} else if (name == '��' && playerName.equals(RED_NAME)) {
				return p2;
			} else if (name == 'ǰ' && playerName.equals(BLACK_NAME)) {
				return p2;
			} else if (name == '��' && playerName.equals(BLACK_NAME)) {
				return p1;
			}

		}
		int startX = ChessUtil.ziToNum(manual.substring(1, 2));

		if (playerName.equals(RED_NAME)) {
			startX = 10 - startX;
		}
		int startY = getPieceYByCategory(startX, pc);
		System.out.println(pc + "getStartPosition������էڧߧѧ�� �ߧѧ�ѧݧ�ߧ�� ����ܧڣ�" + startX + startY);

		return new Point(startX, startY);
	}


	public Point getEndPosition(String manual) {
		Point pStart = getStartPosition(manual);
		String third = manual.substring(2, 3);
		String fourth = String.valueOf((manual.charAt(3)));
		PieceCategory pc = getPieceCategory(manual);

		int endX = 0;
		int endY = 0;

		int jbzpjs = ChessUtil.ziToNum(fourth);
		int msx = ChessUtil.ziToNum(fourth);
		if (playerName.equals(RED_NAME)) {
			msx = 10 - msx;
		}

		if (third.equals("��")) {
			switch (pc) {
			case JU:
			case ZU:
			case BING:
			case PAO:
			case JIANG:
			case SHUAI:

				endX = (int) pStart.getX();
				if (playerName.equals(RED_NAME)) {
					endY = (int) (pStart.getY() - jbzpjs);
				} else {
					endY = (int) (pStart.getY() + jbzpjs);
				}
				break;


			case MA:
				endX = msx;
				int startX = (int) pStart.getX();
				int xDistance = Math.abs(startX - endX);
				if (playerName.equals(RED_NAME)) {
					if (xDistance == 1) {
						endY = (int) (pStart.getY() - 2);
					} else {
						endY = (int) (pStart.getY() - 1);
					}
				} else {
					if (xDistance == 1) {
						endY = (int) (pStart.getY() + 2);
					} else {
						endY = (int) (pStart.getY() + 1);
					}
				}
				break;

			case HONGSHI:
				endX = msx;
				endY = (int) (pStart.getY() - 1);

				break;
			case HEISHI:
				endX = msx;
				endY = (int) (pStart.getY() + 1);
				break;
			case HEIXIANG:
				endX = msx;
				endY = (int) (pStart.getY() + 2);
				break;
			case HONGXIANG:
				endX = msx;
				endY = (int) (pStart.getY() - 2);
				break;

			}
		} else if (third.equals("��")) {
			switch (pc) {
			case JU:
			case ZU:
			case BING:
			case PAO:
			case JIANG:
			case SHUAI:

				endX = (int) pStart.getX();
				if (playerName.equals(RED_NAME)) {
					endY = (int) (pStart.getY() + jbzpjs);
				} else {
					endY = (int) (pStart.getY() - jbzpjs);
				}
				break;


			case MA:
				endX = msx;
				int startX = (int) pStart.getX();
				int xDistance = Math.abs(startX - endX);
				if (playerName.equals(RED_NAME)) {
					if (xDistance == 1) {
						endY = (int) (pStart.getY() + 2);
					} else {
						endY = (int) (pStart.getY() + 1);
					}
				} else {
					if (xDistance == 1) {
						endY = (int) (pStart.getY() - 2);
					} else {
						endY = (int) (pStart.getY() - 1);
					}
				}
				break;

			case HONGSHI:
				endX = msx;
				endY = (int) (pStart.getY() + 1);

				break;
			case HEISHI:
				endX = msx;
				endY = (int) (pStart.getY() - 1);
				break;
			case HEIXIANG:
				endX = msx;
				endY = (int) (pStart.getY() - 2);
				break;
			case HONGXIANG:
				endX = msx;
				endY = (int) (pStart.getY() + 2);
				break;
			}
		} else if (third.equals("ƽ")) {
			endX = msx;
			endY = (int) pStart.getY();
		}
		System.out.println("getEndPosition" + pStart.getX() + pStart.getY()
				+ endX + endY);
		return new Point(endX, endY);

	}


	private PieceCategory getPieceCategory(String manual) {
		String name = manual.substring(0, 1);

		if (name.equals("ǰ") || name.equals("��")) {
			name = manual.substring(1, 2);
		}

		return PieceUtil.getPieceCategory(name);
	}


	public void run() {
		while (true) {
			try {
				if (needWink) {
					winkPiece.setVisible(false);
					Thread.sleep(600);
					winkPiece.setVisible(true);
					Thread.sleep(600);
				} else {
					Thread.sleep(500);
				}
			} catch (InterruptedException ex) {
				break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void clearTipPoints() {
		tipPoints.clear();
	}

	public String getPlayerName() {
		return playerName;
	}

	public Thread getWinkThread() {
		return winkThread;
	}

	public ChessPoint[][] getChessPoints() {
		return chessPoints;
	}

	public void addPiece(ChessPiece piece) {
		if (piece == null) {
			return;
		}
		add(piece);
	}

	public void removePiece(ChessPiece piece) {
		if (piece == null) {
			return;
		}
		remove(piece);

	}

	public void setMoveFlag(boolean moveFlag) {
		this.moveFlag = moveFlag;

	}

	public void setMoveFlagPoints(Point start, Point end) {
		movePoints[0] = start;
		movePoints[1] = end;
	}

	protected abstract MouseAdapter getMouseAdapter();


	public void movePiece(ChessPiece movePiece, int startX, int startY,
			int endX, int endY) {
		System.out.println("�����ڧ�� ��֧�֧ާ֧��ڧ�� ��ѧ�ާѧ�ߧ��� ��ڧԧ���, �ܧ���էڧߧѧ����(" + startX + "," + startY + "),(" + endX
				+ "," + endY + ")");
		ChessPiece pieceRemoved = chessPoints[endX][endY].getPiece();
		if (pieceRemoved != null) {
			chessPoints[endX][endY].removePiece(pieceRemoved, this);
		}
		chessPoints[endX][endY].setPiece(movePiece, this);
		chessPoints[startX][startY].setHasPiece(false);
		System.out.println("�ާ�ҧڧݧ�ߧ��ۣ�" + movePiece.getCategory());

		setMoveFlag(true);
		movePoints[0] = new Point(endX, endY);
		movePoints[1] = new Point(startX, startY);
		clearTipPoints();

		validate();
		repaint();

	}


	public void addChessRecord(ChessPiece movePiece, int startX, int startY,
			int endX, int endY) {

		if (movePiece == null) {
			System.out.println("movePiece == null");
			return;
		}
		ManualItem moveRecord = new ManualItem();
		ChessPiece pieceRemoved = chessPoints[endX][endY].getPiece();

		moveRecord.setMovePieceId(movePiece.getId());
		if (pieceRemoved != null) {
			moveRecord.setEatedPieceId(pieceRemoved.getId());
		} else {
			moveRecord.setEatedPieceId(null);
		}

		moveRecord.setMoveStep(new MoveStep(new Point(startX, startY),
				new Point(endX, endY)));
		chessManual.addManualItem(moveRecord);

	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public boolean isSelected() {
		return isSelected;
	}

	public void setNeedWink(boolean needWink) {
		this.needWink = needWink;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
}
