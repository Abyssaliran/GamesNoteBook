
package cn.fansunion.chinesechess.core;

import java.awt.Point;

import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.core.ChessPiece.PieceCategory;
import cn.fansunion.chinesechess.core.ChessPiece.PieceId;


public final class ChessRule implements NAME {

	private ChessRule() {

	}


	public static boolean networkRule(ChessPiece piece, int startX, int startY,
			int endX, int endY, ChessPoint chessPoints[][]) {

		if (!rangeCheck(startX, startY, endX, endY)) {
			return false;
		}


		if (isSameColor(chessPoints, startX, startY, endX, endY)) {
			return false;
		}

		boolean canMove = false;


		PieceCategory category = piece.getCategory();

		if (category.equals(PieceCategory.JU)
				|| category.equals(PieceCategory.MA)
				|| category.equals(PieceCategory.PAO)) {
			return jmpRule(category, startX, startY, endX, endY, chessPoints);
		}


		else if (category.equals(PieceCategory.HEIXIANG)
				|| category.equals(PieceCategory.HONGXIANG)) {
			int centerI = (startX + endX) / 2;
			int centerJ = (startY + endY) / 2;
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);

			if (xAxle == 2 && yAxle == 2 && endY >= 6) {

				if (chessPoints[centerI][centerJ].hasPiece()) {
					canMove = false;
				} else {
					canMove = true;
				}
			} else {
				canMove = false;
			}
		}


		else if (category.equals(PieceCategory.BING)
				|| category.equals(PieceCategory.ZU)) {
			int xAxle = Math.abs(startX - endX);


			if (endY >= 6) {
				if (startY - endY == 1 && xAxle == 0) {
					canMove = true;
				} else {
					canMove = false;
				}
			}


			else if (endY <= 5) {
				if ((startY - endY == 1) && (xAxle == 0)) {
					canMove = true;
				} else if ((endY - startY == 0) && (xAxle == 1)) {
					canMove = true;
				} else {
					canMove = false;
				}
			}
		}


		else if (category.equals(PieceCategory.HEISHI)
				|| category.equals(PieceCategory.HONGSHI)) {
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);
			if (xAxle == 1 && yAxle == 1 && endX <= 6 && endX >= 4) {
				if (endY >= 8 && endY <= 10) {
					canMove = true;
				}
			} else {
				canMove = false;
			}
		}


		else if ((category.equals(PieceCategory.SHUAI))
				|| (category.equals(PieceCategory.JIANG))) {
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);

			if (endX <= 6 && endX >= 4) {

				if ((xAxle == 1 && yAxle == 0) || (xAxle == 0 && yAxle == 1)) {

					if (endY >= 8 && endY <= 10) {

						if (!ChessRule
								.isDuiLian(piece, endX, endY, chessPoints)) {
							canMove = true;
						}
					}
				} else {
					canMove = false;
				}
			} else {
				canMove = false;
			}
		}

		return canMove;

	}


	public static boolean allRule(ChessPiece piece, int startX, int startY,
			int endX, int endY, ChessPoint[][] chessPoints) {


		if (!rangeCheck(startX, startY, endX, endY)) {
			return false;
		}


		if (isSameColor(chessPoints, startX, startY, endX, endY)) {
			return false;
		}


		if (isDuiLian(piece, endY, endY, chessPoints)) {
			return false;
		}

		// ���� �ާ�ا֧� �էӧڧԧѧ���� ��� ��ާ�ݧ�ѧߧڧ�, ������� ���ҧݧ�էѧۧ�� ���ѧӧڧݧ�(canMove = true)
		boolean canMove = false;


		PieceCategory category = piece.getCategory();


		if (category == PieceCategory.JU || category == PieceCategory.MA
				|| category == PieceCategory.PAO) {
			return jmpRule(category, startX, startY, endX, endY, chessPoints);
		}


		if (category.equals(PieceCategory.SHUAI)
				|| category.equals(PieceCategory.HONGSHI)
				|| category.equals(PieceCategory.BING)
				|| category.equals(PieceCategory.HONGXIANG)
				|| category.equals(PieceCategory.JIANG)
				|| category.equals(PieceCategory.HEISHI)
				|| category.equals(PieceCategory.ZU)
				|| (category.equals(PieceCategory.HEIXIANG))) {
			return ssxbRule(piece, startX, startY, endX, endY, chessPoints);
		}

		return canMove;
	}


	public static boolean isWillDangerous(int startX, int startY, int endX,
			int endY, ChessPoint[][] chessPoints, ChessBoard board) {

		// System.out.println("���֧�֧� �ӧ�֧ާ֧ߧߧ��� ��֧�֧ާ֧�֧ߧڧ֧� ��ڧԧ�����");
		// PieceUtil.printPieceLoations(chessPoints);

		ChessPiece pieceRemoved = chessPoints[endX][endY].getPiece();
		PieceId id = null;
		if (pieceRemoved != null) {
			id = pieceRemoved.getId();
			// System.out.println("���է֧ߧ�ڧ�ڧܧѧ��� ���֧է֧ߧߧ�ԧ� �ܧ��ܧѣ�" + id);
		}
		ChessPiece movePiece = chessPoints[startX][startY].getPiece();

		chessPoints[endX][endY].removePiece(pieceRemoved, board);
		chessPoints[endX][endY].setPiece(movePiece, board);
		chessPoints[startX][startY].setHasPiece(false);

		// System.out.println("�����ݧ� �ӧ�֧ާ֧ߧߧ�ԧ� ��֧�֧ާ֧�֧ߧڧ� ��ڧԧ�⣺");
		// PieceUtil.printPieceLoations(chessPoints);
		boolean flag = isDangerous(true, movePiece.getName(), chessPoints);

		// System.out.println(movePiece.getId() + "����է� ��� �ԧ֧ߧ֧�ѧݣ�(" + startX + ","+
		// startY + "),(" + endX + "),(" + endY + ")" + flag);

		ChessPiece piece = chessPoints[endX][endY].getPiece();
		chessPoints[startX][startY].setPiece(piece, board);
		if (pieceRemoved == null) {
			chessPoints[endX][endY].setHasPiece(false);
		} else {
			ChessPiece pieceRemoved2 = PieceUtil.createPiece(id);
			chessPoints[endX][endY].setPiece(pieceRemoved2, board);
			pieceRemoved2.addMouseListener(board.getMouseAdapter());
			// System.out.println("���է֧ߧ�ڧ�ڧܧѧ��� ���֧է֧ߧߧ�ԧ� �ܧ��ܧ�22��" + pieceRemoved2.getId());
		}

		// System.out.println("���֧�֧� �ӧ�٧�ҧߧ�ӧݧ֧ߧڧ֧� ��֧�֧֧٧էѣ�");
		// PieceUtil.printPieceLoations(chessPoints);

		return flag;
	}


	public static boolean partialRule(ChessPiece piece, int startX, int startY,
			int endX, int endY, ChessPoint[][] chessPoints) {


		if (isSameColor(chessPoints, startX, startY, endX, endY)) {
			return false;
		}

		System.out.println("startX=" + startX + " startY= " + startY
				+ " endX= " + endX + " endY= " + endY);
		PieceCategory category = piece.getCategory();


		if (startX == 0 && startY == 0) {


			if (category.equals(PieceCategory.HONGSHI)) {
				if (endX == 4 || endX == 6) {
					if (endY == 8 || endY == 10) {
						return true;
					}
				} else if (endX == 5 && endY == 9) {
					return true;
				}
				return false;
			}

			else if (category.equals(PieceCategory.HEISHI)) {
				if (endX == 4 || endX == 6) {
					if (endY == 1 || endY == 3) {
						return true;
					}
				} else if (endX == 5 && endY == 2) {
					return true;
				}
				return false;
			}

			else if (category.equals(PieceCategory.HEIXIANG)) {
				if (endX == 1 || endX == 5 || endX == 9) {
					if (endY == 3) {
						return true;
					}
				} else if (endX == 3 || endX == 7) {
					if (endY == 1 || endY == 5) {
						return true;
					}
				}
				return false;
			}

			else if (category.equals(PieceCategory.HONGXIANG)) {
				if (endX == 1 || endX == 5 || endX == 9) {
					if (endY == 8) {
						return true;
					}
				} else if (endX == 3 || endX == 7) {
					if (endY == 6 || endY == 10) {
						return true;
					}
				}
				return false;
			}

			else if (category.equals(PieceCategory.JIANG)) {
				if (endX >= 4 && endX <= 6) {
					if (endY >= 1 && endY <= 3) {
						if (ChessRule.isDuiLian(piece, endX, endY, chessPoints)) {
							return false;
						}
						return true;
					}
				}
				return false;
			}

			else if (category.equals(PieceCategory.SHUAI)) {
				if (endX >= 4 && endX <= 6) {
					if (endY >= 8 && endY <= 10) {
						if (ChessRule.isDuiLian(piece, endX, endY, chessPoints)) {
							return false;
						}
						return true;
					}
				}
				return false;
			}

			else if (category.equals(PieceCategory.BING)) {
				if (endY == 6 || endY == 7) {
					if (endX == 1 || endX == 3 || endX == 5 || endX == 7
							|| endX == 9) {
						return true;
					}
					return false;
				} else if (endY < 6) {
					return true;
				} else {
					return false;
				}

			}
			else if (category.equals(PieceCategory.ZU)) {
				if (endY == 4 || endY == 5) {
					if (endX == 1 || endX == 3 || endX == 5 || endX == 7
							|| endX == 9) {
						return true;
					}
					return false;
				} else if (endY > 5) {
					return true;
				} else {
					return false;
				}

			}

			else {
				return true;
			}
		}
		if (category.equals(PieceCategory.JU)
				|| category.equals(PieceCategory.MA)
				|| category.equals(PieceCategory.PAO)) {
			return jmpRule(category, startX, startY, endX, endY, chessPoints);
		}

		else if (category.equals(PieceCategory.HONGSHI)
				|| category.equals(PieceCategory.HEISHI)
				|| category.equals(PieceCategory.HONGXIANG)
				|| category.equals(PieceCategory.BING)
				|| category.equals(PieceCategory.HEIXIANG)
				|| category.equals(PieceCategory.ZU)
				|| category.equals(PieceCategory.JIANG)
				|| (category.equals(PieceCategory.SHUAI))) {
			return ssxbRule(piece, startX, startY, endX, endY, chessPoints);
		}
		return false;
	}


	public static boolean jmpRule(PieceCategory category, int startX,
			int startY, int endX, int endY, ChessPoint[][] chessPoints) {
		/*
		 * System.out.println("�ԧ֧ߧ֧�ѧݧ�ߧ��ۣ�(" + startX + "," + startY + "),(" + endX
		 * + "," + endY + ")");
		 */
		int minX = Math.min(startX, endX);
		int maxX = Math.max(startX, endX);
		int minY = Math.min(startY, endY);
		int maxY = Math.max(startY, endY);


		if (category.equals(PieceCategory.JU)) {

			if (startX == endX) {
				int j = 0;
				for (j = minY + 1; j <= maxY - 1; j++) {

					if (chessPoints[startX][j].hasPiece()) {
						return false;
					}
				}
				if (j == maxY) {
					return true;
				}
			}

			else if (startY == endY) {
				int i = 0;
				for (i = minX + 1; i <= maxX - 1; i++) {
					if (chessPoints[i][startY].hasPiece()) {
						return false;
					}
				}
				if (i == maxX) {
					return true;
				}
			} else {
				return false;
			}
		}


		else if (category.equals(PieceCategory.MA)) {
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);


			if (xAxle == 2 && yAxle == 1) {
				if (endX > startX) {

					if (chessPoints[startX + 1][startY].hasPiece()) {
						return false;
					}
					return true;
				}
				if (endX < startX) {

					if (chessPoints[startX - 1][startY].hasPiece()) {
						return false;
					}
					return true;
				}

			}


			else if (xAxle == 1 && yAxle == 2) {
				if (endY > startY) {

					if (chessPoints[startX][startY + 1].hasPiece()) {
						return false;
					}
					return true;
				}
				if (endY < startY) {

					if (chessPoints[startX][startY - 1].hasPiece()) {
						return false;
					}
					return true;
				}

			} else {
				return false;
			}
		}


		else if (category.equals(PieceCategory.PAO)) {

			int number = 0;

			if (startX == endX) {
				int j = 0;
				for (j = minY + 1; j <= maxY - 1; j++) {
					if (chessPoints[startX][j].hasPiece()) {
						number++;
					}
				}


				if (number == 0 && !chessPoints[endX][endY].hasPiece()) {
					return true;
				}


				else if (number == 1) {
					if (chessPoints[endX][endY].hasPiece()) {
						return true;
					}
				}


				else if (number > 1) {
					return false;
				}

			}


			else if (startY == endY) {
				int i = 0;
				for (i = minX + 1; i <= maxX - 1; i++) {
					if (chessPoints[i][startY].hasPiece()) {
						number++;
					}
				}

				if (number > 1) {
					return false;
				} else if (number == 1) {
					if (chessPoints[endX][endY].hasPiece()) {
						return true;
					}
				}

				else if (number == 0 && !chessPoints[endX][endY].hasPiece()) {
					return true;
				}
			} else {
				return false;
			}
		}
		return false;

	}


	private static boolean ssxbRule(ChessPiece piece, int startX, int startY,
			int endX, int endY, ChessPoint[][] chessPoints) {
		PieceCategory category = piece.getCategory();

		if (category.equals(PieceCategory.HEIXIANG)
				|| category.equals(PieceCategory.HONGXIANG)) {
			int centerI = (startX + endX) / 2;
			int centerJ = (startY + endY) / 2;
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);

			if (xAxle == 2 && yAxle == 2) {

				if (!chessPoints[centerI][centerJ].hasPiece()) {
					if (category.equals(PieceCategory.HEIXIANG)) {
						if (endY <= 5) {
							return true;
						}
					} else if (category.equals(PieceCategory.HONGXIANG)) {
						if (endY >= 6) {
							return true;
						}
					}
				}
			}
		}


		else if (category.equals(PieceCategory.BING)
				|| category.equals(PieceCategory.ZU)) {
			int xAxle = Math.abs(startX - endX);


			if (category.equals(PieceCategory.BING)) {
				if (endY >= 6) {
					if (startY - endY == 1 && xAxle == 0) {
						return true;
					}
				}


				else if (endY <= 5) {
					if ((startY - endY == 1) && (xAxle == 0)) {
						return true;
					} else if ((endY - startY == 0) && (xAxle == 1)) {
						return true;
					}
				}
			}


			else {
				if (endY < 6) {
					if (startY - endY == -1 && xAxle == 0) {
						return true;
					}
				}


				else if (endY >= 6) {
					if ((startY - endY == -1) && (xAxle == 0)) {
						return true;
					} else if ((endY - startY == 0) && (xAxle == 1)) {
						return true;
					}
				}
			}
		}


		else if (category.equals(PieceCategory.HEISHI)
				|| category.equals(PieceCategory.HONGSHI)) {
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);
			if (xAxle == 1 && yAxle == 1 && endX <= 6 && endX >= 4) {
				if (category.equals(PieceCategory.HONGSHI)
						&& (endY >= 8 && endY <= 10)) {
					return true;
				} else if (category.equals(PieceCategory.HEISHI)
						&& (endY >= 1 && endY <= 3)) {
					return true;
				}
			}
		}


		else if ((category.equals(PieceCategory.SHUAI))
				|| (category.equals(PieceCategory.JIANG))) {
			int xAxle = Math.abs(startX - endX);
			int yAxle = Math.abs(startY - endY);

			if ((xAxle == 1 && yAxle == 0) || (xAxle == 0 && yAxle == 1)) {
				if (endX <= 6 && endX >= 4) {

					if (ChessRule.isDuiLian(piece, endX, endY, chessPoints)) {
						return false;
					}


					if (category.equals(PieceCategory.SHUAI) && endY >= 8
							&& endY <= 10) {
						return true;
					}
					if (category.equals(PieceCategory.JIANG) && endY >= 1
							&& endY <= 3) {
						return true;
					}
				}
			}
		}
		return false;
	}


	public static boolean isDangerous(boolean flag, String playerName,
			ChessPoint[][] chessPoints) {
		Point leaderPosition;
		Point[] paoPositions;
		Point[] juPositions;
		Point[] maPositions;
		Point[] zuPositions;
		// System.out.println("�ж�" + playerName + "����է� ��� �ԧ֧ߧ֧�ѧݣ�");
		// PieceUtil.printPieceLoations(chessPoints);

		// ���ѧ�� ������ߧ� - �ܧ�ѧ�ߧѧ�, ���էڧ��, ��֧�ߧ��� �ݧ� �ԧ֧ߧ֧�ѧ�
		if (playerName.equals(RED_NAME)) {
			leaderPosition = PieceUtil.getLeaderPosition(PieceCategory.SHUAI,
					chessPoints);

			if (leaderPosition == null) {
				System.out.println("���֧� �ܧ�ѧ�ڧӧ�ԧ࣡");
				return false;
			}

			juPositions = PieceUtil.getPositionByCategory(BLACK_NAME,
					PieceCategory.JU, chessPoints);
			paoPositions = PieceUtil.getPositionByCategory(BLACK_NAME,
					PieceCategory.PAO, chessPoints);
			maPositions = PieceUtil.getPositionByCategory(BLACK_NAME,
					PieceCategory.MA, chessPoints);
			zuPositions = PieceUtil.getPositionByCategory(BLACK_NAME,
					PieceCategory.ZU, chessPoints);

			int leaderX = (int) leaderPosition.getX();
			int leaderY = (int) leaderPosition.getY();


			for (int i = 0; i < juPositions.length; i++) {
				int x = (int) juPositions[i].getX();
				int y = (int) juPositions[i].getY();

				if (ChessRule.jmpRule(PieceCategory.JU, x, y, leaderX, leaderY,
						chessPoints)) {
					return true;
				}
			}

			for (int i = 0; i < paoPositions.length; i++) {
				int x = (int) paoPositions[i].getX();
				int y = (int) paoPositions[i].getY();

				if (ChessRule.jmpRule(PieceCategory.PAO, x, y, leaderX,
						leaderY, chessPoints)) {
					return true;
				}
			}

			for (int i = 0; i < maPositions.length; i++) {
				int x = (int) maPositions[i].getX();
				int y = (int) maPositions[i].getY();

				if (ChessRule.jmpRule(PieceCategory.MA, x, y, leaderX, leaderY,
						chessPoints)) {
					return true;
				}
			}

			for (int i = 0; i < zuPositions.length; i++) {
				int x = (int) zuPositions[i].getX();
				int y = (int) zuPositions[i].getY();

				int xAxle = Math.abs(x - leaderX);

				if ((leaderY - y == 0) && (xAxle == 1)) {
					return true;
				} else if ((y - leaderY == -1) && (xAxle == 0) && flag) {
					return true;
				} else if ((y - leaderY == 1) && (xAxle == 0) && !flag) {
					return true;
				}

			}
		}

		else if (playerName.equals(BLACK_NAME)) {
			leaderPosition = PieceUtil.getLeaderPosition(PieceCategory.JIANG,
					chessPoints);

			if (leaderPosition == null) {
				System.out.println("���� �ߧѧۧէ֧ߣ�");
				return false;
			}

			juPositions = PieceUtil.getPositionByCategory(RED_NAME,
					PieceCategory.JU, chessPoints);
			paoPositions = PieceUtil.getPositionByCategory(RED_NAME,
					PieceCategory.PAO, chessPoints);
			maPositions = PieceUtil.getPositionByCategory(RED_NAME,
					PieceCategory.MA, chessPoints);
			zuPositions = PieceUtil.getPositionByCategory(RED_NAME,
					PieceCategory.BING, chessPoints);

			int leaderX = (int) leaderPosition.getX();
			int leaderY = (int) leaderPosition.getY();


			for (int i = 0; i < juPositions.length; i++) {
				int x = (int) juPositions[i].getX();
				int y = (int) juPositions[i].getY();

				if (ChessRule.jmpRule(PieceCategory.JU, x, y, leaderX, leaderY,
						chessPoints)) {
					return true;
				}
			}


			for (int i = 0; i < paoPositions.length; i++) {
				int x = (int) paoPositions[i].getX();
				int y = (int) paoPositions[i].getY();

				if (ChessRule.jmpRule(PieceCategory.PAO, x, y, leaderX,
						leaderY, chessPoints)) {
					return true;
				}
			}


			for (int i = 0; i < maPositions.length; i++) {
				int x = (int) maPositions[i].getX();
				int y = (int) maPositions[i].getY();

				if (ChessRule.jmpRule(PieceCategory.MA, x, y, leaderX, leaderY,
						chessPoints)) {
					return true;
				}
			}


			for (int i = 0; i < zuPositions.length; i++) {
				int x = (int) zuPositions[i].getX();
				int y = (int) zuPositions[i].getY();

				int xAxle = Math.abs(x - leaderX);

				if ((leaderY - y == 0) && (xAxle == 1)) {
					return true;
				} else if ((y - leaderY == 1) && (xAxle == 0) && flag) {
					return true;
				} else if ((y - leaderY == -1) && (xAxle == 0) && !flag) {
					return true;
				}

			}
		}
		return false;

	}


	private static boolean isSameColor(ChessPoint[][] chessPoints, int startX,
			int startY, int endX, int endY) {

		if (startX < 1 || startX > 9 || startY < 1 || startY > 10) {
			return false;
		}

		if (endX < 1 || endX > 10 || endY < 1 || endY > 10) {
			return false;
		}
		/*
		 * System.out.println("����է� ��� ��� �ا� ��ѧ�ާѧ�ߧѧ� ��ڧԧ���:" + startX + "," + startY + "," + endX +
		 * "," + endY);
		 */
		ChessPiece startPiece = chessPoints[startX][startY].getPiece();
		ChessPiece endPiece = chessPoints[endX][endY].getPiece();

		if (startPiece != null && endPiece != null) {
			String startPlayerName = startPiece.getName();
			String endPlayerName = endPiece.getName();
			if (startPlayerName.equals(endPlayerName)) {
				/*
				 * System.out.println("����է� ��� ��� �ا� ��ѧ�ާѧ�ߧѧ� ��ڧԧ��ѣ�" + startPiece.getCategory() +
				 * "" + startX + "," + startY + "," + endX + "," + endY);
				 */
				return true;
			}
		}

		return false;
	}


	private static boolean rangeCheck(int startX, int startY, int endX, int endY) {
		if (startX < 1 || startX > 9 || startY < 1 || startY > 10) {
			return false;
		}

		if (endX < 1 || endX > 10 || endY < 1 || endY > 10) {
			return false;
		}

		return true;
	}


	public static boolean isDuiLian(ChessPiece piece, int endX, int endY,
			ChessPoint[][] chessPoints) {

		int shuaiI = 0, shuaiJ = 0;
		int jiangI = 0, jiangJ = 0;
		PieceCategory pc = piece.getCategory();

		for (int i = 4; i <= 6; i++) {
			for (int j = 1; j <= 10; j++) {
				if (chessPoints[i][j].hasPiece()) {
					if (chessPoints[i][j].getPiece().getCategory()
							.equals(PieceCategory.JIANG)) {
						jiangI = i;
						jiangJ = j;
						break;
					}
				}
			}
		}

		for (int i = 4; i <= 6; i++) {
			for (int j = 1; j <= 10; j++) {
				if (chessPoints[i][j].hasPiece()) {
					if (chessPoints[i][j].getPiece().getCategory()
							.equals(PieceCategory.SHUAI)) {
						shuaiI = i;
						shuaiJ = j;
						break;
					}
				}
			}
		}
		if (pc == PieceCategory.SHUAI || pc == PieceCategory.JIANG) {
			int startX = 0;
			int startY = 0;
			if (pc == PieceCategory.SHUAI) {
				startX = jiangI;
				startY = jiangJ;
			} else {
				startX = shuaiI;
				startY = shuaiJ;
			}
			boolean flag = false;
			if (startX == endX) {
				int y2 = Math.max(endY, startY);
				int y1 = Math.min(endY, startY);
				for (int j = y1 + 1; j < y2; j++) {
					if (chessPoints[startX][j].hasPiece()) {
						flag = true;
					}
				}
				if (!flag) {
					return true;
				}
			}
		}
		else {
			if (shuaiI == jiangI) {
				boolean flag = false;
				int y2 = Math.max(shuaiJ, jiangJ);
				int y1 = Math.min(shuaiJ, jiangJ);
				for (int j = y1 + 1; j < y2; j++) {
					if (j != endY && chessPoints[shuaiI][j].hasPiece()) {
						flag = true;
					}
				}
				if (!flag) {
					return true;
				}
			}
		}
		// System.out.println(piece.getCategory()+"Test" + shuaiI + shuaiJ + ","
		// + endX + endY);

		return false;

	}
}
