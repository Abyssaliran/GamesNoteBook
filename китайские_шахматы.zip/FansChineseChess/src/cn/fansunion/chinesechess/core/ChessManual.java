
package cn.fansunion.chinesechess.core;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessPiece.PieceCategory;
import cn.fansunion.chinesechess.net.client.NetworkBoard;
import cn.fansunion.chinesechess.print.part.PrintPartBoard;



public class ChessManual extends JPanel implements NAME {

	private static final long serialVersionUID = 1L;

	public JList manualList = null;

	public JScrollPane manualScroll = null;

	private ChessBoard board = null;

	private ChessPoint[][] chessPoints;

	private ArrayList<ManualItem> manualItems;

	public Vector<String> descs;


	public ChessManual(ChessBoard board) {
		this.board = board;
		this.chessPoints = board.getChessPoints();
		manualItems = new ArrayList<ManualItem>();
		descs = new Vector<String>();

		manualList = new JList();
		manualList.setFont(new Font("����", Font.PLAIN, 14));
		manualList.setToolTipText(PropertyReader.get("CHESS_MESSAGE_TOOLTIP"));
		// manual.setPreferredSize(new Dimension(160,180));
		manualList.setVisibleRowCount(12);
		manualList.setAutoscrolls(true);

		manualScroll = new JScrollPane(manualList);
		// manualScroll.setPreferredSize(new Dimension(200,210));
		setLayout(new BorderLayout());
		setSize(220, 260);
		add(manualScroll, BorderLayout.CENTER);
	}


	public void addManualItem(ManualItem manualItem) {

		manualItems.add(manualItem);

		System.out.println("���է֧ߧ�ڧ�ڧܧѧ��� �էӧڧا��֧ۧ�� ��ѧ��ڣ�" + manualItem.getMovePieceId());
		ChessPiece piece = PieceUtil.searchPieceById(manualItem
				.getMovePieceId(), chessPoints);
		MoveStep moveStep = manualItem.getMoveStep();
		Point pStart = moveStep.getStart();
		Point pEnd = moveStep.getEnd();

		String name = piece.getName();
		PieceCategory category = piece.getCategory();
		int index = 1;
		if (name.equals(RED_NAME)) {
			index = manualItems.size() / 2 + 1;
		} else {
			index = manualItems.size() / 2;
		}

		if (board instanceof PrintPartBoard) {
			PrintPartBoard board2 = (PrintPartBoard) (board);
			if (!board2.boardOwner.redFirst) {
				if (name.equals(BLACK_NAME)) {
					index = manualItems.size() / 2 + 1;
				} else {
					index = manualItems.size() / 2;
				}
			}
		}

		int startX = (int) pStart.getX();
		int startY = (int) pStart.getY();
		int endX = (int) pEnd.getX();
		int endY = (int) pEnd.getY();
		String desc = name;
		if (index < 10) {
			desc += "  " + index + ": ";
		} else {
			desc += " " + index + ": ";
		}


		desc += PieceUtil.catetoryToZi(category);


		if (name.equals(RED_NAME)) {
			desc += ChessUtil.numToZi(10 - startX);
		} else {
			desc += (" " + startX);
		}

		for (int j = 1; j <= 10; j++) {
			if (j == startY || j == endY) {
				continue;
			}

			if (chessPoints[startX][j].hasPiece()) {
				ChessPiece tempPiece = chessPoints[startX][j].getPiece();

				if (tempPiece.getCategory().equals(category)
						&& tempPiece.getName().equals(name)) {
					String category2 = PieceUtil.catetoryToZi(category);
					if (index < 10) {
						desc = name + "  " + index + ": ";
					} else {
						desc = name + " " + index + ": ";
					}

					if ((board instanceof NetworkBoard)) {
						if (board.getPlayerName().equals(name)) {
							if (startY > j) {
								desc += "��" + category2;
							} else if (startY < j) {
								desc += "ǰ" + category2;
							}
						} else {
							if (startY > j) {
								desc += "ǰ" + category2;
							} else if (startY < j) {
								desc += "��" + category2;
							}
						}
					} else {
						if (board.getPlayerName().equals(RED_NAME)) {
							if (startY > j) {
								desc += "��" + category2;
							} else if (startY < j) {
								desc += "ǰ" + category2;
							}
						} else if (board.getPlayerName().equals(BLACK_NAME)) {
							if (startY > j) {
								desc += "ǰ" + category2;
							} else if (startY < j) {
								desc += "��" + category2;
							}
						}
					}
				}
			}

		}


		if (board instanceof NetworkBoard) {

			if (board.getPlayerName().equals(name)) {
				if (startY == endY) {
					desc += "ƽ";
				} else if (startY > endY) {
					desc += "��";
				} else {
					desc += "��";
				}
			} else {
				if (startY == endY) {
					desc += "ƽ";
				} else if (startY > endY) {
					desc += "��";
				} else {
					desc += "��";
				}
			}
		} else {
			if (name.equals(RED_NAME)) {
				if (startY == endY) {
					desc += "ƽ";
				} else if (startY > endY) {
					desc += "��";
				} else {
					desc += "��";
				}
			} else if (name.equals(BLACK_NAME)) {
				if (startY == endY) {
					desc += "ƽ";
				} else if (startY > endY) {
					desc += "��";
				} else {
					desc += "��";
				}
			}
		}


		if (startX == endX) {
			if (name.equals(RED_NAME)) {
				desc += ChessUtil.numToZi(Math.abs(startY - endY));
			} else {
				desc += (" " + Math.abs(startY - endY));
			}
		} else {
			if (name.equals(RED_NAME)) {
				desc += ChessUtil.numToZi(10 - endX);
			} else {
				desc += (" " + endX);
			}
		}


		descs.add(desc);
		manualList.setListData(descs);

		scrollToView();
	}


	public ArrayList<ManualItem> getManualItems() {
		return manualItems;
	}

	public void setManualItems(ArrayList<ManualItem> manualItems) {
		this.manualItems = manualItems;
	}


	public boolean removeManualItem() {

		int size = manualItems.size();

		if (size <= 0) {
			return false;
		}

		descs.remove(size - 1);
		manualList.setListData(descs);


		ManualItem record = new ManualItem();
		MoveStep moveStep;

		ChessPiece eatedPiece;
		int startI = 0;
		int startJ = 0;
		int endI = 0;
		int endJ = 0;

		if (size > 0) {

			record = (ManualItem) manualItems.remove(manualItems.size() - 1);
			eatedPiece = PieceUtil.createPiece(record.getEatedPieceId());

			moveStep = record.getMoveStep();
			startI = moveStep.start.x;
			startJ = moveStep.start.y;
			endI = moveStep.end.x;
			endJ = moveStep.end.y;

			ChessPiece piece = chessPoints[endI][endJ].getPiece();
			chessPoints[startI][startJ].setPiece(piece, board);
			if (eatedPiece == null) { 
				chessPoints[endI][endJ].setHasPiece(false);
			} else {
				chessPoints[endI][endJ].setPiece(eatedPiece, board);
				eatedPiece.addMouseListener(board.getMouseAdapter());
			}
		}


		if (descs.size() >= 1) {
			record = (ManualItem) manualItems.get(descs.size() - 1);
			moveStep = record.getMoveStep();
			startI = moveStep.start.x;
			startJ = moveStep.start.y;
			endI = moveStep.end.x;
			endJ = moveStep.end.y;
		}


		Point start = new Point(endI, endJ);
		Point end = new Point(startI, startJ);

		if (descs.size() > 0) {
			board.setMoveFlag(true);
			board.setMoveFlagPoints(start, end);
		} else {
			board.setMoveFlag(false);
		}

		scrollToView();

		board.validate();
		board.repaint();

		return true;
	}

	private void scrollToView() {
		int lastIndex = descs.size();

		manualList.setSelectedIndex(lastIndex - 1);

		Rectangle rect = manualList.getCellBounds(lastIndex - 1, lastIndex - 1);
		if (rect == null) {
			return;
		}
		System.out.println(rect == null);
		if ((manualScroll != null) && (manualScroll.getViewport() != null)
				&& (rect != null)) {
			// �� ��ݧ��ѧ� rect==null������ܧݧ��֧ߧڧ� �ߧ�ݧ֧ӧ�ԧ� ��ܧѧ٧ѧ�֧ݧ�
			manualScroll.getViewport().scrollRectToVisible(rect);
		}
	}
}
