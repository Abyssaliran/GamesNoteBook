
package cn.fansunion.chinesechess.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Vector;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.print.part.Position;
import cn.fansunion.chinesechess.save.GameRecord;
import cn.fansunion.chinesechess.save.GameRecord.ManualType;



public final class ManualUtil implements NAME {
	private ManualUtil() {

	}


	public static boolean saveManual(String filePath, String descPath,
			GameRecord gameRecord) {


		String allDescs = "";
		for (int i = 0; i < gameRecord.getDescs().size(); i++) {
			allDescs += gameRecord.getDescs().get(i) + "\r\n\r\n";
		}
		ChessUtil.writeStringToFile(descPath, allDescs);


		try {
			FileOutputStream outOne = new FileOutputStream(filePath);
			ObjectOutputStream outTwo = new ObjectOutputStream(outOne);

			outTwo.writeObject(gameRecord.getFlag());
			outTwo.writeObject(gameRecord.getDateAndTime());
			outTwo.writeObject(gameRecord.getDesc());
			outTwo.writeObject(gameRecord.getRecords());
			outTwo.writeObject(gameRecord.getDescs());
			outTwo.writeObject(gameRecord.getInitLocations());

			outOne.close();
			outTwo.close();

		} catch (NotSerializableException nse) {
			nse.printStackTrace();
			return false;
		} catch (IOException ex) {
			ex.printStackTrace();
			return false;
		}

		return true;
	}


	@SuppressWarnings("unchecked")

	public static GameRecord readManual(File file) {
		GameRecord record = null;
		try {
			FileInputStream inOne = new FileInputStream(file);
			ObjectInputStream inTwo = new ObjectInputStream(inOne);
			ManualType flag = null;

			flag = (ManualType) inTwo.readObject();
			String dateAndTime = (String) inTwo.readObject();
			String desc = (String) inTwo.readObject();
			ArrayList<ManualItem> records = (ArrayList<ManualItem>) inTwo
					.readObject();
			Vector<String> descs = (Vector<String>) inTwo.readObject();
			ArrayList<Position> initLocations = null;
			if (flag == ManualType.PRINT_PARTIAL) {
				initLocations = (ArrayList<Position>) inTwo.readObject();
			}
			record = new GameRecord(flag, dateAndTime, desc, records, descs,
					initLocations);

			inOne.close();
			inTwo.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return record;

	}
}
