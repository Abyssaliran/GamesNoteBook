
package cn.fansunion.chinesechess.core;

import java.awt.Point;


public class ChessPoint{

	public static final long serialVersionUID = 261L;

	private int x, y;

	private ChessPiece piece = null;

	public ChessPoint(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public ChessPoint(int x, int y, ChessPiece piece, ChessBoard board) {
		this(x, y);
		setPiece(piece, board);
	}

	public ChessPoint() {
	}

	public boolean hasPiece() {
		return piece != null;
	}

	public void setHasPiece(boolean hasPiece) {
		if (!hasPiece) {
			piece = null;
		}
	}

	public Point getPoint() {
		return new Point(x, y);
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}


	public void setPiece(ChessPiece piece, ChessBoard board) {
		if (piece == null) {
			return;
		}
		this.piece = piece;

		if (board == null) {
			return;
		}

		board.addPiece(piece);
		piece.setBounds(x - ChessPiece.UNIT_WIDTH / 2, y
				- ChessPiece.UNIT_HEIGHT / 2, ChessPiece.UNIT_WIDTH,
				ChessPiece.UNIT_HEIGHT);
		if (piece != null && piece.getPosition() != null) {
			System.out.println(piece.getCategory() + "setPiece:"
					+ piece.getPosition().getX() + piece.getPosition().getY());
		}
	}


	public void setPiece(ChessPiece piece) {
		this.piece = piece;
	}


	public void removePiece(ChessPiece piece, ChessBoard board) {
		if (piece == null) {
			return;
		}
		if (board == null) {
			return;
		}
		board.removePiece(piece);
		piece = null;
	}

	public ChessPiece getPiece() {
		return piece;
	}

	public Object clone() throws CloneNotSupportedException {
		ChessPoint cp = new ChessPoint();
		cp.x = this.x;
		cp.y = this.y;
		cp.piece = (ChessPiece) this.piece.clone();
		return cp;
	}
}
