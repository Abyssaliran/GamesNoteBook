
package cn.fansunion.chinesechess.core;

import java.io.Serializable;

import cn.fansunion.chinesechess.core.ChessPiece.PieceId;



public class ManualItem implements Serializable {

	private static final long serialVersionUID = 259L;

	private PieceId eatedPieceId;

	private MoveStep moveStep;

	private PieceId movePieceId;

	public ManualItem() {
		moveStep = null;
		eatedPieceId = null;
	}

	public ManualItem(PieceId movePieceId, PieceId eatedPieceId,
			MoveStep moveStep) {
		this.movePieceId = movePieceId;
		this.eatedPieceId = eatedPieceId;
		this.moveStep = moveStep;
	}

	public MoveStep getMoveStep() {
		return moveStep;
	}

	public PieceId getEatedPieceId() {
		return eatedPieceId;
	}

	public void setEatedPieceId(PieceId eatedPieceId) {
		this.eatedPieceId = eatedPieceId;
	}

	public PieceId getMovePieceId() {
		return movePieceId;
	}

	public void setMovePieceId(PieceId movePieceId) {
		this.movePieceId = movePieceId;
	}

	public void setMoveStep(MoveStep moveStep) {
		this.moveStep = moveStep;
	}
}
