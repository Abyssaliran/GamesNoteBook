
package cn.fansunion.chinesechess.net.common;

import javax.swing.table.AbstractTableModel;


public class CreatorTableModel extends AbstractTableModel {

	private static final long serialVersionUID = 2;

	private String[] columnNames = { "���٧էѧ�֧ݧ�", "����֧ާ� ���٧էѧߧڧ�", "���֧ܧ��ڧ� �ߧ�ާ֧�", "��������ߧڧ� �ڧԧ��" };

	private Object[][] data = { { "", "", "", "" }, { "", "", "", "" },
			{ "", "", "", "" }, { "", "", "", "" }, { "", "", "", "" },
			{ "", "", "", "" }, { "", "", "", "" }, { "", "", "", "" },
			{ "", "", "", "" }, { "", "", "", "" } };

	public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;
	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
	}

	public Class<?> getColumnClass(int c) {
		return getValueAt(0, c).getClass();
	}

	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}
}
