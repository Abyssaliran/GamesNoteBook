
package cn.fansunion.chinesechess.net.common;

import java.io.Serializable;

import cn.fansunion.chinesechess.net.common.MsgPacket.PlayerRole;



public class Member implements Serializable {

	private static final long serialVersionUID = 22103L;

	private String name;

	private PlayerRole role;

	private String ip;

	private String desc;

	private int cid;

	private int mid;

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PlayerRole getRole() {
		return role;
	}

	public void setRole(PlayerRole role) {
		this.role = role;
	}

}
