
package cn.fansunion.chinesechess.net.common;

import java.io.Serializable;

import cn.fansunion.chinesechess.net.server.User;



public class Player implements Serializable {

	private static final long serialVersionUID = 2581L;


	private User user;


	private String loginTime;


	private String ipAddress;


	private String gameStatus;
	
	public Player() {

	}

	public Player(User user, String loginTime, String ipAddress,String gameStatus) {
		this.user = user;
		this.loginTime = loginTime;
		this.ipAddress = ipAddress;
		this.gameStatus = gameStatus;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getGameStatus() {
		return gameStatus;
	}

	public void setGameStatus(String gameStatus) {
		this.gameStatus = gameStatus;
	}

}
