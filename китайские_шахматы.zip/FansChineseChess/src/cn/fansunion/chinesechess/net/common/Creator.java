
package cn.fansunion.chinesechess.net.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cn.fansunion.chinesechess.net.server.User;



public class Creator implements Serializable {

	private static final long serialVersionUID = 1L;


	private User user;


	private String date;

	private List<Member> members;


	private String gameStatus;

	private String ip;

	private int cid;

	public Creator() {
		members = Collections.synchronizedList(new ArrayList<Member>(3));
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getGameStatus() {
		return gameStatus;
	}

	public void setGameStatus(String gameStatus) {
		this.gameStatus = gameStatus;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Member> getMembers() {
		return members;
	}

	public void setMembers(List<Member> members) {
		this.members = members;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

}
