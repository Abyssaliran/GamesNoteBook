
package cn.fansunion.chinesechess.net.common;

import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;


public class PlayerGroupModel extends DefaultTableModel {
	private static final long serialVersionUID = 2;

	public static String[] columnNames = { "���ާ� �ڧԧ��ܧ�", "����ݧ�", "�ѧۧ�� �ѧէ�֧�", "��ӧ֧�" };



	public PlayerGroupModel(String[] tableHead, int column) {
		super(tableHead, column);
	}

	public PlayerGroupModel(Vector data, Vector columns) {
		super(data, columns);
	}

	public Class<?> getColumnClass(int c) {

		if (c == 1) {
			return JComboBox.class;
		} else if (c == 3) {
			return Icon.class;
		} else {
			return String.class;
		}
	}


	public boolean isCellEditable(int row, int col) {
		if (col != 1) {
			return false;
		}
		return true;
	}


}
