
package cn.fansunion.chinesechess.net.common;

import java.io.Serializable;


public class Message implements Serializable {

	private static final long serialVersionUID = 124L;

	public enum MessageType {
		TO_ALL, TO_SOME,SYSTEM
	};


	private String content;


	private String date;


	private MessageType status;

	public MessageType getStatus() {
		return status;
	}

	public void setStatus(MessageType status) {
		this.status = status;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
