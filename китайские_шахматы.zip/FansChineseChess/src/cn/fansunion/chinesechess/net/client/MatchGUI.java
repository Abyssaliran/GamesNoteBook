
package cn.fansunion.chinesechess.net.client;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.core.ChessManual;
import cn.fansunion.chinesechess.net.common.Message;
import cn.fansunion.chinesechess.net.common.MsgPacket;
import cn.fansunion.chinesechess.net.common.Message.MessageType;
import cn.fansunion.chinesechess.net.common.MsgPacket.MsgType;
import cn.fansunion.chinesechess.save.GameRecord;
import cn.fansunion.chinesechess.save.ISaveManual;
import cn.fansunion.chinesechess.save.MsgRecordDialog;
import cn.fansunion.chinesechess.save.SaveAsDialog;
import cn.fansunion.chinesechess.save.SaveDialog;
import cn.fansunion.chinesechess.save.GameRecord.ManualType;



public class MatchGUI extends JFrame implements ActionListener, ISaveManual,
		NAME {

	private static final long serialVersionUID = 101L;


	private JPanel control, gameStatusPanel;

	public JButton exit, undo, pause, save, giveIn, qiuhe, send;


	public NetworkBoard board = null;

	public ChessManual records = null;

	JComboBox msgComboBox;


	public JMenuBar bar;

	JMenu fileMenu, settingMenu, chattingMenu, helpMenu;

	JMenuItem saveManual, saveManualAs, pauseGame, exitGame;

	JMenuItem setting, helpContent, aboutGame, saveMsgAs, clearMsg, recoverMsg,
			msgHistory, welcome;

	JCheckBoxMenuItem bgSound;

	public String msgRecord = "";

	private Cursor handCursor;


	JLabel gameStatusContent, gameStatusIcon;


	public PlayerGroupGUI parent;


	String[] initialMsg = { "Я так рада тебя видеть »,« Поторопись, я подожду, пока не исчезнут цветы »,« У тебя такие хорошие шахматные ходы »,« Сыграй снова в следующий раз, я ухожу." };

	public JTextArea msgArea;


	String[] initialUsers = { "Все" };

	private JComboBox userComboBox;

	public static String SPACE = "    ";


	public MatchGUI(PlayerGroupGUI parent) {
		this.parent = parent;
		handCursor = new Cursor(Cursor.HAND_CURSOR);


		initButtons();
		initMenus();

		board = new NetworkBoard();
		records = board.chessManual;

		initPanels();

		addWindowListener(new WindowAdapter() {

			public void windowActivated(WindowEvent e) {
				msgComboBox.requestFocusInWindow();
			};
		});
		handleKeyEvent();
	}


	private void handleKeyEvent() {
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {

			public void eventDispatched(AWTEvent event) {

				KeyEvent keyEvent = (KeyEvent) event;
				int id = keyEvent.getID();

				if (id == KeyEvent.KEY_PRESSED) {
					int code = (keyEvent).getKeyCode();
					if (code == KeyEvent.VK_F1) {
						ChessUtil.showHelpDialog();
					}
				}


				else if (id == (KeyEvent.VK_ENTER & KeyEvent.CTRL_MASK)) {

				}
			}
		}, AWTEvent.KEY_EVENT_MASK);

	}


	private void initPanels() {

		JPanel rightPanel = new JPanel(new BorderLayout());


		JPanel recordsPanel = new JPanel(new BorderLayout());

		TitledBorder recordsBorder = new TitledBorder(PropertyReader
				.get("CHESS_MESSAGE_TOOLTIP"));
		recordsPanel.setBorder(recordsBorder);
		recordsPanel.setPreferredSize(new Dimension(240, 200));
		recordsPanel.add(BorderLayout.CENTER, records);


		BorderLayout msgLayout = new BorderLayout();
		JPanel msgPanel = new JPanel();
		msgPanel.setLayout(msgLayout);
		TitledBorder msgBorder = new TitledBorder(PropertyReader
				.get("PLAYER_MESSAGE_TOOLTIP"));
		msgPanel.setBorder(msgBorder);

		msgArea = new JTextArea();
		msgArea.setToolTipText(PropertyReader.get("PLAYER_MESSAGE_TOOLTIP"));
		msgArea.setRows(7);
		msgArea.setFont(new Font("宋体", Font.PLAIN, 16));
		msgArea.setEditable(false);
		msgArea.setWrapStyleWord(true);
		msgArea.setLineWrap(true);
		JScrollPane displayScroll = new JScrollPane(msgArea);

		// board.msgArea = msgArea;

		msgComboBox = new JComboBox(initialMsg);
		msgComboBox.setSelectedIndex(-1);
		msgComboBox.setEditable(true);
		msgComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));
		msgComboBox.setToolTipText(PropertyReader.get("MSG_JCOMBOBOX_TOOLTIP"));


		userComboBox = new JComboBox(initialUsers);

		userComboBox.setSelectedIndex(0);
		userComboBox.setCursor(handCursor);
		userComboBox.setToolTipText(PropertyReader
				.get("USER_JCOMBOBOX_TOOLTIP"));

		userComboBox.setEditable(false);
		userComboBox.setPreferredSize(new Dimension(80, 30));


		JPanel sendMsgPanel = new JPanel(new BorderLayout());
		sendMsgPanel.add(BorderLayout.NORTH, msgComboBox);

		JPanel panel = new JPanel(new FlowLayout());
		panel.add(send);
		panel.add(userComboBox);
		sendMsgPanel.add(BorderLayout.CENTER, panel);

		msgPanel.add(BorderLayout.CENTER, displayScroll);
		msgPanel.add(BorderLayout.SOUTH, sendMsgPanel);


		rightPanel.add(BorderLayout.NORTH, recordsPanel);
		rightPanel.add(BorderLayout.CENTER, msgPanel);


		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,
				board, rightPanel);
		split.setDividerSize(5);
		split.setDividerLocation(460);
		add(split, BorderLayout.CENTER);

		control = new JPanel();
		BorderLayout layout = new BorderLayout();
		control.setLayout(layout);

		JPanel controlPanel = new JPanel();

		FlowLayout flowLayout = new FlowLayout(FlowLayout.LEFT);
		controlPanel.setLayout(flowLayout);

		TitledBorder controlBorder = new TitledBorder("Управление игрой");

		controlPanel.setBorder(controlBorder);

		controlPanel.add(pause);
		controlPanel.add(undo);
		controlPanel.add(giveIn);
		controlPanel.add(qiuhe);
		controlPanel.add(exit);
		controlPanel.add(save);

		control.add(BorderLayout.CENTER, controlPanel);


		gameStatusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		gameStatusPanel.setPreferredSize(new Dimension(660, 80));
		gameStatusIcon = new JLabel(ChessUtil.getImageIcon("hongshuai.png"));

		gameStatusContent = new JLabel("Красная сторона движется первой");
		gameStatusContent.setFont(new Font("宋体", Font.PLAIN, 16));
		// gameStatus.setForeground(Color.BLACK);

		TitledBorder gameStatusBorder = new TitledBorder("Состояние игры");
		gameStatusBorder.setTitleColor(Color.RED);
		gameStatusBorder.setTitleFont(new Font("宋体", Font.PLAIN, 16));
		gameStatusPanel.setToolTipText("Состояние игры");
		gameStatusPanel.setBorder(gameStatusBorder);

		gameStatusPanel.add(gameStatusIcon);
		gameStatusPanel.add(gameStatusContent);

		control.add(BorderLayout.SOUTH, gameStatusPanel);

		add(BorderLayout.SOUTH, control);
		board.gameStatusContent = gameStatusContent;

	}


	private void initButtons() {


		ImageIcon ii = ChessUtil.getImageIcon("save.png");
		int width = ii.getIconWidth();
		int height = ii.getIconHeight();


		save = new JButton(ChessUtil.getImageIcon("save.png"));
		save.setPreferredSize(new Dimension(width, height));
		save.setToolTipText(PropertyReader.get("SAVE_JBUTTON_TOOLTIP"));
		save.setCursor(handCursor);
		save.addActionListener(this);

		pause = new JButton(ChessUtil.getImageIcon("pause.png"));
		pause.setPreferredSize(new Dimension(width, height));
		pause.setToolTipText(PropertyReader.get("PAUSE_JBUTTON_TOOLTIP"));
		pause.setCursor(handCursor);
		pause.addActionListener(this);

		undo = new JButton(ChessUtil.getImageIcon("undo.png"));
		undo.setPreferredSize(new Dimension(width, height));
		undo.setToolTipText(PropertyReader.get("UNDO_JBUTTON_TOOLTIP"));
		undo.setCursor(handCursor);
		undo.addActionListener(this);

		giveIn = new JButton(ChessUtil.getImageIcon("giveIn.png"));
		giveIn.setPreferredSize(new Dimension(width, height));
		giveIn.setToolTipText(PropertyReader.get("GIVEIN_JBUTTON_TOOLTIP"));
		giveIn.setCursor(handCursor);
		giveIn.addActionListener(this);

		qiuhe = new JButton(ChessUtil.getImageIcon("qiuhe.png"));
		qiuhe.setPreferredSize(new Dimension(width, height));
		qiuhe.setToolTipText(PropertyReader.get("qiuhe"));
		qiuhe.setCursor(handCursor);
		qiuhe.addActionListener(this);

		exit = new JButton(ChessUtil.getImageIcon("exit2.png"));
		exit.setPreferredSize(new Dimension(width, height));
		exit.setToolTipText(PropertyReader.get("EXIT_GAME_JBUTTON_TOOLTIP"));
		exit.setCursor(handCursor);
		exit.addActionListener(this);

		ImageIcon sendIcon = ChessUtil.getImageIcon("send.png");
		send = new JButton(sendIcon);
		send.setToolTipText(PropertyReader.get("SEND_JBUTTON_TOOLTIP"));
		send.setCursor(handCursor);
		send.setPreferredSize(new Dimension(sendIcon.getIconWidth(), sendIcon
				.getIconHeight()));
		send.addActionListener(this);

	}


	private void initMenus() {

		bar = new JMenuBar();
		fileMenu = new JMenu("китайские шахматы(G)");

		pauseGame = new JMenuItem("Приостановить игру");
		saveManual = new JMenuItem("Сохраните запись игры", ChessUtil.getImageIcon("save.gif"));
		saveManualAs = new JMenuItem("Сохранить как запись игры", ChessUtil
				.getImageIcon("saveas.gif"));
		exitGame = new JMenuItem("выйти из игры", ChessUtil.getImageIcon("exit.gif"));

		fileMenu.add(saveManual);
		fileMenu.add(saveManualAs);
		fileMenu.add(pauseGame);
		fileMenu.add(exitGame);
		bar.add(fileMenu);

		chattingMenu = new JMenu("болтать с(C)");
		msgHistory = new JMenuItem("запись чата");
		saveMsgAs = new JMenuItem("Сохранить историю чата как", ChessUtil
				.getImageIcon("saveas.gif"));
		clearMsg = new JMenuItem("Понятная информация об интерфейсе");
		recoverMsg = new JMenuItem("Восстановить информацию об интерфейсе");

		chattingMenu.add(msgHistory);
		chattingMenu.add(saveMsgAs);
		chattingMenu.add(clearMsg);
		chattingMenu.add(recoverMsg);

		bar.add(chattingMenu);

		helpMenu = new JMenu("Помогите(H)");
		welcome = new JMenuItem("добро пожаловать", ChessUtil.getImageIcon("welcome.gif"));
		helpContent = new JMenuItem("Содержание справки", ChessUtil.getImageIcon("help.gif"));
		aboutGame = new JMenuItem("О китайских шахматах", ChessUtil.getImageIcon("info.gif"));

		settingMenu = new JMenu("Настроить(S)");
		bgSound = new JCheckBoxMenuItem("Фоновая музыка");
		bgSound.setSelected(true);
		setting = new JMenuItem("Общие настройки");
		settingMenu.add(bgSound);
		settingMenu.add(setting);
		bar.add(settingMenu);

		helpMenu.add(welcome);
		helpMenu.add(helpContent);
		helpMenu.add(helpContent);
		helpMenu.add(helpContent);
		helpMenu.add(aboutGame);
		bar.add(helpMenu);

		setJMenuBar(bar);


		saveManual.setAccelerator(KeyStroke.getKeyStroke('S',
				InputEvent.CTRL_DOWN_MASK));
		saveManualAs.setAccelerator(KeyStroke.getKeyStroke('U',
				InputEvent.CTRL_DOWN_MASK));
		pauseGame.setAccelerator(KeyStroke.getKeyStroke('P',
				InputEvent.CTRL_DOWN_MASK));
		exitGame.setAccelerator(KeyStroke.getKeyStroke('E',
				InputEvent.CTRL_DOWN_MASK));

		welcome.setAccelerator(KeyStroke.getKeyStroke('W',
				InputEvent.CTRL_DOWN_MASK));
		helpContent.setAccelerator(KeyStroke.getKeyStroke('H',
				InputEvent.CTRL_DOWN_MASK));
		aboutGame.setAccelerator(KeyStroke.getKeyStroke('A',
				InputEvent.CTRL_DOWN_MASK));

		msgHistory.setAccelerator(KeyStroke.getKeyStroke('C',
				InputEvent.CTRL_DOWN_MASK));
		saveMsgAs.setAccelerator(KeyStroke.getKeyStroke('M',
				InputEvent.CTRL_DOWN_MASK));
		clearMsg.setAccelerator(KeyStroke.getKeyStroke('Q',
				InputEvent.CTRL_DOWN_MASK));
		recoverMsg.setAccelerator(KeyStroke.getKeyStroke('H',
				InputEvent.CTRL_DOWN_MASK));

		bgSound.setAccelerator(KeyStroke.getKeyStroke('B',
				InputEvent.CTRL_DOWN_MASK));
		setting.setAccelerator(KeyStroke.getKeyStroke('T',
				InputEvent.CTRL_DOWN_MASK));


		fileMenu.setMnemonic(KeyEvent.VK_G);
		chattingMenu.setMnemonic(KeyEvent.VK_C);
		settingMenu.setMnemonic(KeyEvent.VK_S);
		helpMenu.setMnemonic(KeyEvent.VK_H);


		saveManual.addActionListener(this);
		saveManualAs.addActionListener(this);
		pauseGame.addActionListener(this);
		exitGame.addActionListener(this);

		setting.addActionListener(this);
		bgSound.addActionListener(this);

		welcome.addActionListener(this);
		helpContent.addActionListener(this);
		aboutGame.addActionListener(this);

		msgHistory.addActionListener(this);
		saveMsgAs.addActionListener(this);
		clearMsg.addActionListener(this);
		recoverMsg.addActionListener(this);

	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		MsgPacket sp = new MsgPacket();

		boolean isSend = false;


		if ((source == exitGame) || (source == exit)) {
			int result = JOptionPane.showConfirmDialog(parent, "Вы уверены, что хотите выйти？",
					"Уволиться？", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {

				parent.parent.isJoin = false;
				sp.setMsgType(MsgType.GAME_EXIT);
				parent.parent.setMenuAndButtonEnabled(true);
				isSend = true;

			} else {
				isSend = false;
			}
		}

		else if ((source == pause) || (source == pauseGame)) {
			isSend = true;

			if (board.isPause) {
				board.isPause = false;

				pause.setIcon(ChessUtil.getImageIcon("pause.png"));
				pauseGame.setText(PropertyReader.get("PAUSE_JBUTTON_TOOLTIP"));
				pause.setToolTipText(PropertyReader
						.get("PAUSE_JBUTTON_TOOLTIP"));
				sp.setMsgType(MsgType.GAME_CONTINUE);

				if (board.otherIsPause) {
					gameStatusContent.setText(SPACE + "Противник приостановил игру! пожалуйста, подождите терпеливо！");
				} else {
					if (board.myTurn) {
						gameStatusContent.setText(SPACE + "Моя очередь идти！");
					} else {
						gameStatusContent.setText(SPACE + "Ожидание движения противника！");
					}
				}
			}

			else {
				board.isPause = true;
				pause.setIcon(ChessUtil.getImageIcon("continue.png"));
				pauseGame.setText(PropertyReader
						.get("CONTINUE_JBUTTON_TOOLTIP"));
				pause.setToolTipText(PropertyReader
						.get("CONTINUE_JBUTTON_TOOLTIP"));
				sp.setMsgType(MsgType.GAME_PAUSE);
			}

			if (board.otherIsPause) {
				gameStatusContent.setText(SPACE + "И вы, и ваш собеседник приостановили игру.！");
			} else {
				gameStatusContent.setText(SPACE + "Вы поставили игру на паузу！");
			}

		}

		else if (source == giveIn) {
			int result = JOptionPane.showConfirmDialog(this, "Вы уверены, что сдадитесь？");
			if (result == JOptionPane.YES_OPTION) {
				isSend = true;
				sp.setMsgType(MsgType.PLAYER_GIVEIN);
				gameStatusContent.setText(SPACE + "продолжай усердно работать！");
				ChessUtil.playSound("gameover.wav");
				board.myTurn = false;
			} else {
				isSend = false;
			}
		}


		else if (source == undo) {
			isSend = true;

			sp.setMsgType(MsgType.GAME_UNDO);

			updateGameStatus(RED_TURN_GAME_STATUS, "Прошу сожаления");
		}

		else if (source == qiuhe) {
			isSend = true;
		}

		else if (source == send) {
			String msg = (String) msgComboBox.getSelectedItem();
			if (msg != null && !msg.equals("")) {
				isSend = true;

				Message message = new Message();
				message.setContent(msg);
				message.setDate(ChessUtil.getDateAndTime());

				String dest = (String) userComboBox.getSelectedItem();
				ArrayList<String> names = new ArrayList<String>();
				names.add(dest);

				if (dest.equals("Все")) {

					message.setStatus(MessageType.TO_ALL);
				} else {
					sp.names = names;
					message.setStatus(MessageType.TO_SOME);
				}
				sp.setMessage(message);
				sp.setMsgType(MsgType.GAME_MESSAGE);
				sp.setName(board.userName);


				msgComboBox.setSelectedIndex(-1);
				msgComboBox.requestFocusInWindow();

				String tempMsg = board.userName + " " + ChessUtil.getTime()
						+ "\n   " + msg + "\n";
				msgArea.append(tempMsg);
				msgRecord = msgRecord + tempMsg;
				msgArea.setCaretPosition(msgArea.getText().length());
			}
		} else {
			isSend = false;
		}


		if (isSend) {
			sp.setName(board.userName);
			sp.setRole(parent.role);
			sendPacket(sp);

			if (sp.getMsgType() == MsgType.GAME_EXIT) {
				System.out.println("Пытаюсь отключить фоновую музыку！");
				parent.switchBgsound(false);
				if (board.getWinkThread() != null) {
					board.getWinkThread().interrupt();
				}
				this.dispose();
				parent.dispose();
			}
		}


		if ((source == save) || (source == saveManual)) {
			SaveDialog dialog = new SaveDialog(this);
			dialog.setVisible(true);
		} else if (source == saveManualAs) {
			SaveAsDialog dialog = new SaveAsDialog(this);
			dialog.setVisible(true);
		} else if (source == clearMsg) {
			msgArea.setText("");
		} else if (source == recoverMsg) {
			msgArea.setText(msgRecord);
		} else if (source == msgHistory) {
			MsgRecordDialog recordDialog = new MsgRecordDialog(this);
			recordDialog.setVisible(true);
		} else if (source == saveMsgAs) {
			saveMsgAs();
		} else if (source == aboutGame) {
			ChessUtil.showAboutDialog();
		} else if (source == helpContent) {
			ChessUtil.showHelpDialog();
		} else if (source == bgSound) {
			parent.switchBgsound(bgSound.getState());
		} else if (source == setting) {
			JOptionPane.showMessageDialog(this, "В настоящее время нет параметров для установки", "В настоящее время нет параметров для установки",
					JOptionPane.INFORMATION_MESSAGE);
		} else if (source == welcome) {
			ChessUtil.showWelcomeDialog();
		}

	}


	public void saveMsgAs() {
		JFileChooser fileChooser = new JFileChooser();

		int state = fileChooser.showSaveDialog(null);
		File saveFile = fileChooser.getSelectedFile();
		if (saveFile != null && state == JFileChooser.APPROVE_OPTION) {
			String path = saveFile.getPath() + ".txt";
			System.out.println("Путь истории чата:" + path);
			ChessUtil.writeStringToFile(msgRecord, path);
		}

	}


	public void sendPacket(MsgPacket sp) {
		System.out.println("Клиент отправляет сообщение" + sp.getMsgType());
		parent.parent.sendPacket(sp);
	}


	public void updateNames() {
		userComboBox.removeAllItems();
		userComboBox.addItem("Все");

		int size = parent.names.size();
		for (int index = 0; index < size; index++) {
			String name = parent.names.get(index);
			if (!name.equals(board.userName)) {
				userComboBox.addItem(name);
			}
		}
	}


	public void updateGameStatus(int state, String content) {

		switch (state) {
		case RED_TURN_GAME_STATUS:
			gameStatusIcon.setIcon(ChessUtil.getImageIcon("hongshuai.png"));
			break;
		case BLACK_TURN_GAME_STATUS:
			gameStatusIcon.setIcon(ChessUtil.getImageIcon("heijiang.png"));
			break;
		default:
			break;
		}

		if (content != null && !content.equals("")) {
			gameStatusContent.setText(content);
		}
	}

	public void addMsg(String msg) {
		msgArea.append(msg);
	}

	@Override
	public GameRecord getGameRecord() {
		ManualType manualType = null;
		switch (parent.role) {
		case ROLE_RED:
			manualType = ManualType.NETWORK_RED;
			break;
		case ROLE_BLACK:
			manualType = ManualType.NETWORK_BLACK;
			break;
		case ROLE_OBSERVER:
			manualType = ManualType.NETWORK_OBSERVER;
			break;
		case ROLE_JUDGMENT:
			manualType = ManualType.NETWORK_JUDGEMENT;
			break;
		default:
			break;
		}
		GameRecord gameRecord = new GameRecord(manualType, ChessUtil
				.getDateAndTime(), "", board.chessManual.getManualItems(),
				board.chessManual.descs, null);
		return gameRecord;
	}

	@Override
	public ArrayList<String> getSavePaths() {
		ArrayList<String> paths = new ArrayList<String>();
		String path = "manuals/network/";
		String path2 = "manuals/network/";

		paths.add(path);
		paths.add(path2);
		return paths;
	}

}
