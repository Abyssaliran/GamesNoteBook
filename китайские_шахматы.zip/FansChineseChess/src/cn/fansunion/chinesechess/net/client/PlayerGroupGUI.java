
package cn.fansunion.chinesechess.net.client;

import java.applet.AudioClip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableColumn;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.net.common.Creator;
import cn.fansunion.chinesechess.net.common.JTableUtil;
import cn.fansunion.chinesechess.net.common.Member;
import cn.fansunion.chinesechess.net.common.Message;
import cn.fansunion.chinesechess.net.common.MsgPacket;
import cn.fansunion.chinesechess.net.common.PlayerGroupModel;
import cn.fansunion.chinesechess.net.common.Message.MessageType;
import cn.fansunion.chinesechess.net.common.MsgPacket.MsgType;
import cn.fansunion.chinesechess.net.common.MsgPacket.PlayerRole;



public class PlayerGroupGUI extends JFrame implements ActionListener,
		NAME {

	private static final long serialVersionUID = 1L;

	JTable groupTable = new JTable();


	public JButton start, exit, send;


	public JComboBox comboBox;


	public ArrayList<String> names = new ArrayList<String>();


	private JComboBox userComboBox;


	private JComboBox msgComboBox;


	private boolean gameStart = false;


	String[] initialMsgs = { "���ѧ� �٧ߧѧܧ�ާ��ӧ�", "���������ڧ��, �� ���է�اէ�, ���ܧ� ����ѧէ� �ߧ� ��ۧէ֧�", "���ѧ�� ��ѧ�ާѧ�ߧ��� ���է� ��ѧ� �������", "���ԧ�ѧ� ��ߧ�ӧ� �� ��ݧ֧է���ڧ� ��ѧ�, �� ����ا�" };


	String[] initialUsers = { "�����" };

	public JTextArea msgArea;


	public PlayerRole role = null;


	RoomGUI parent;

	MatchGUI client = new MatchGUI(this);


	URL url = ChessUtil.class.getResource("/sounds/back.mid");

	AudioClip bgSound = JApplet.newAudioClip(url);
	
	public static String SPACE = "    ";

	public PlayerGroupGUI(RoomGUI parent) {
		this.parent = parent;
		initButtons();

		setSize(650, 700);
		setTitle(PropertyReader.get("GAME_TITLE"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setLocationRelativeTo(null);


		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}


			public void windowActivated(WindowEvent e) {
				msgComboBox.requestFocusInWindow();
			};

		});

		int[] widths = { 60, 60, 80, 32 };
		String[] columnNames = { "���ާ� �ڧԧ��ܧ�", "����ݧ�", "�ѧۧ�� �ѧէ�֧�", "�ڧܧ�ߧ�" };
		PlayerGroupModel model = new PlayerGroupModel(columnNames, 4);

		groupTable.setPreferredSize(new Dimension(400, 120));
		groupTable.setModel(model);
		groupTable.setGridColor(Color.BLUE);
		groupTable.setRowHeight(32);

		TableColumn sportColumn = groupTable.getColumnModel().getColumn(1);

		comboBox = new JComboBox();
		comboBox.addActionListener(this);
		comboBox.addItem("���֧�ߧ���");
		comboBox.addItem("���ѧҧݧ�էѧ�֧ݧ�");
		comboBox.addItem("��֧�֧��");
		comboBox.setSelectedIndex(0);
		sportColumn.setCellEditor(new DefaultCellEditor(comboBox));
		groupTable.repaint();

		JTableUtil.fitTableColumns(groupTable, widths);

		JScrollPane scroll = new JScrollPane(groupTable);
		scroll.setPreferredSize(new Dimension(500, 150));

		JPanel playersPanel = new JPanel();
		playersPanel.setPreferredSize(new Dimension(500, 180));
		TitledBorder playersBorder = new TitledBorder("���ߧ���ާѧ�ڧ� ��� �ڧԧ��ܧ�");
		playersPanel.setBorder(playersBorder);
		playersPanel.add(scroll);

		JPanel msgPanel = new JPanel(new BorderLayout());
		TitledBorder msgBorder = new TitledBorder("���ߧ���ާѧ�ڧ� ��� �ڧԧ��ܧ�");
		msgPanel.setBorder(msgBorder);

		msgArea = new JTextArea();
		msgArea.setRows(10);
		msgArea.setFont(new Font("����", Font.PLAIN, 16));
		msgArea.setEditable(false);
		JScrollPane displayScroll = new JScrollPane(msgArea);
		msgPanel.add(BorderLayout.CENTER, displayScroll);

		JPanel sendMsgPanel = new JPanel(new BorderLayout());


		msgComboBox = new JComboBox(initialMsgs);
		msgComboBox.setSelectedIndex(-1);
		msgComboBox.setPreferredSize(new Dimension(400, 30));

		msgComboBox.setEditable(true);
		msgComboBox.setToolTipText(PropertyReader.get("MSG_JCOMBOBOX_TOOLTIP"));
		msgComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));


		userComboBox = new JComboBox(initialUsers);

		userComboBox.setSelectedIndex(0);
		// userComboBox

		userComboBox.setEditable(false);
		userComboBox.setPreferredSize(new Dimension(80, 30));
		userComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));
		userComboBox.setToolTipText(PropertyReader
				.get("USER_JCOMBOBOX_TOOLTIP"));

		JPanel panel = new JPanel(new FlowLayout());
		panel.add(msgComboBox);
		panel.add(send);
		panel.add(userComboBox);
		sendMsgPanel.add(BorderLayout.NORTH, panel);
		msgPanel.add(BorderLayout.SOUTH, sendMsgPanel);

		JPanel controlPanel = new JPanel();
		controlPanel.add(start);
		controlPanel.add(exit);

		this.add(BorderLayout.NORTH, playersPanel);
		this.add(BorderLayout.CENTER, msgPanel);
		this.add(BorderLayout.SOUTH, controlPanel);
	}


	private void initButtons() {

		ImageIcon ii = ChessUtil.getImageIcon("create.png");
		int width = ii.getIconWidth();
		int height = ii.getIconHeight();

	
		start = new JButton(ChessUtil.getImageIcon("start.png"));
		start.setPreferredSize(new Dimension(width, height));
		start.setToolTipText("���ѧ�ѧݧ� �ڧԧ��");
		start.setCursor(new Cursor(Cursor.HAND_CURSOR));
		start.addActionListener(this);

		exit = new JButton(ChessUtil.getImageIcon("exit.png"));
		exit.setPreferredSize(new Dimension(width, height));
		exit.setToolTipText("�ӧ��ۧ�� �ڧ� �ڧԧ��");
		exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
		exit.addActionListener(this);

		send = new JButton(ChessUtil.getImageIcon("send.png"));
		send.setPreferredSize(new Dimension(width, height));
		send.setToolTipText("�����ѧӧݧ��� ����ҧ�֧ߧڧ�");
		send.setCursor(new Cursor(Cursor.HAND_CURSOR));
		send.addActionListener(this);
	}


	public void updateGroup(MsgPacket serverPacket) {
		Creator creator = serverPacket.getCreator();
		for (int k = 0; k < serverPacket.members.size(); k++) {
			System.out
					.println("���ާ� �ԧ����� ���ѧ��ߧڧܧ�ӣ�" + serverPacket.members.get(k).getName());
		}


		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				groupTable.setValueAt(null, i, j);
			}
		}


		groupTable.setValueAt(creator.getUser().getName(), 0, 0);
		groupTable.setValueAt("�췽", 0, 1);
		groupTable.setValueAt(creator.getIp(), 0, 2);
		groupTable.setValueAt(ChessUtil.getImageIcon("hongshuai.gif"), 0, 3);

		System.out.println("���ާ� ���٧էѧ�֧ݧ�" + creator.getUser().getName());
		System.out.println("����ݧڧ�֧��ӧ� ���ѧ��ߧڧܧ�ӣ�" + serverPacket.members.size());
		System.out.println("����٧էѧ�֧ݧ� IP��" + creator.getIp());


		for (int index = 0; index < serverPacket.members.size(); index++) {
			Member member = serverPacket.members.get(index);
			PlayerRole role = member.getRole();
			groupTable.setValueAt(member.getName(), index + 1, 0);

			groupTable.setValueAt(member.getIp(), index + 1, 2);

			if (role == PlayerRole.ROLE_BLACK) {
				groupTable.setValueAt("���֧�ߧ���", index + 1, 1);
				groupTable.setValueAt(ChessUtil.getImageIcon("heijiang.gif"),
						index + 1, 3);
			} else if (role == PlayerRole.ROLE_OBSERVER) {
				groupTable.setValueAt("���ѧҧݧ�էѧ�֧ݧ�", index + 1, 1);
				groupTable.setValueAt(ChessUtil.getImageIcon("observer.png"),
						index + 1, 3);
			} else if (role == PlayerRole.ROLE_JUDGMENT) {
				groupTable.setValueAt("��֧�֧��", index + 1, 1);
				groupTable.setValueAt(ChessUtil.getImageIcon("judgment.png"),
						index + 1, 3);
			}

		}


		for (int m = 0; m < parent.creators.size(); m++) {
			List<Member> temp = new ArrayList<Member>();
			Creator creator2 = parent.creators.get(m);

			for (int n = 0; n < serverPacket.members.size(); n++) {
				Member member = serverPacket.members.get(n);

				if (member.getCid() == creator2.getCid()) {
					temp.add(member);
				}
			}

			creator.setMembers(temp);
		}

		parent.updateCreators();


		updateNames();
	}


	public void handleCreatorStartGame() {

		for (int i = 0; i < 4; i++) {
			String name = (String) groupTable.getValueAt(i, 0);
			if ((name != null)
					&& (!name.equals("") && (!name.equals(parent.userName)))) {
				names.add(name);
			}
		}
		updateNames();

		setTitle(PropertyReader.get("GAME_TITLE"));
		setSize(730, 700);
		setIconImage(ChessUtil.getAppIcon2());
		setJMenuBar(client.bar);
		setResizable(false);
		setLocationRelativeTo(null);
		setContentPane(client.getContentPane());
		client.board.userName = parent.userName;
		client.board.client = client;


		gameStart = true;
		System.out.println("����ѧ��ߧڧܧ� �ߧѧ�ѧݧ� �ڧԧ�壡");

		if (role == PlayerRole.ROLE_BLACK) {
			client.board.initChess(false);
		} else {

			client.board.initChess(true);
			client.board.myTurn = false;
			client.pauseGame.setEnabled(false);
			client.pause.setEnabled(false);
			client.giveIn.setEnabled(false);
			client.undo.setEnabled(false);
		}


		ChessUtil.playSound("begin.wav");

		bgSound.loop();
		validateAll();
	}


	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		if (source == start) {
			int playerNum = 0;
			String role0 = (String) groupTable.getValueAt(0, 1);
			String role1 = (String) groupTable.getValueAt(1, 1);
			String role2 = (String) groupTable.getValueAt(2, 1);
			String role3 = (String) groupTable.getValueAt(3, 1);

			System.out.println("����ݧ� ���٧էѧ�֧ݧ�" + role0);
			System.out.println("���ԧ��� 1��" + role1);
			System.out.println("���ԧ��� 2��" + role2);
			System.out.println("���ԧ��� 3��" + role3);

			if (role1 != null && role1.equals("���֧�ߧ���")) {
				playerNum++;
			}
			if (role2 != null && role2.equals("���֧�ߧ���")) {
				playerNum++;
			}
			if (role3 != null && role3.equals("���֧�ߧ���")) {
				playerNum++;
			}
			if (playerNum != 1) {
				if (playerNum == 0) {
					JOptionPane.showMessageDialog(this, "���֧է���ѧ���ߧ� �ڧԧ��ܧ��", "���֧է���ѧ���ߧ� �ڧԧ��ܧ��",
							JOptionPane.YES_OPTION);
					return;
				}
				if (playerNum == 2 || playerNum == 3) {
					JOptionPane.showMessageDialog(this, "���ݧڧ�ܧ�� �ާߧ�ԧ� �ڧԧ��ܧ��",
							"����ا֧� �ҧ���� ���ݧ�ܧ� 2 �ڧԧ��ܧ� �� �ާ�ԧ�� �ҧ���� �ߧѧҧݧ�էѧ�֧ݧ�.", JOptionPane.YES_OPTION);
					return;
				}
			} else {
				MsgPacket sp = new MsgPacket();
				sp.setMsgType(MsgType.CREATOR_START_CREATED_GAME);
				sp.setName(parent.userName);

				for (int i = 0; i < parent.creators.size(); i++) {
					String creatorName = (String) groupTable.getValueAt(0, 0);
					if (parent.creators.get(i).getUser().getName().equals(
							creatorName)) {
						sp.setCreator(parent.creators.get(i));
						break;
					}
				}
				parent.sendPacket(sp);
				updateNames();

				setTitle(PropertyReader.get("GAME_TITLE"));
				setSize(730, 700);
				setJMenuBar(client.bar);
				setIconImage(ChessUtil.getAppIcon());
				setResizable(false);
				setLocationRelativeTo(null);
				setContentPane(client.getContentPane());

				client.board.initChess(true);
				client.board.client = client;
				client.board.userName = parent.userName;


				gameStart = true;
				System.out.println("����٧էѧ�֧ݧ� �٧ѧ����ڧ� �ڧԧ�壡");

				ChessUtil.playSound("begin.wav");
				bgSound.loop();
				validateAll();
			}
		}
		else if (source == exit) {
			handleExitGame();
		} else if (source == comboBox) {
			//
			String chooice = comboBox.getSelectedItem().toString();
			PlayerRole selectedRole =null;
			if(RED_NAME.equals(chooice)){
				selectedRole = PlayerRole.ROLE_RED;
			}else if(BLACK_NAME.equals(chooice)){
				selectedRole = PlayerRole.ROLE_BLACK;
			}else if("".equals(chooice)){
				
			}else if("".equals(chooice)){
				
			}
			if (selectedRole != role) {
				role = selectedRole;
				updateRole(parent.userName, role);

				MsgPacket sp = new MsgPacket();
				sp.setMsgType(MsgType.CHANGE_ROLE);
				sp.setName(parent.userName);
				sp.setRole(role);
				parent.sendPacket(sp);
			}
			System.out.println("����ݧ� ��� ���ڧ�ܧ��");
			String s = (String) comboBox.getItemAt(comboBox.getSelectedIndex());
			System.out.println("�����ݧ֧էߧڧ� ��֧���ߧѧ� �ڧԧ��ܧѣ�" + s);
		}


		else if (source == send) {
			String msg = (String) msgComboBox.getSelectedItem();
			if (msg != null && !msg.equals("")) {
				MsgPacket sp = new MsgPacket();
				// DataPacket dataPacket = new DataPacket();

				Message message = new Message();
				message.setContent(msg);
				message.setDate(ChessUtil.getDateAndTime());
				String dest = (String) userComboBox.getSelectedItem();
				ArrayList<String> names = new ArrayList<String>();
				names.add(dest);

				if (dest.equals("�����")) {

					message.setStatus(MessageType.TO_ALL);
				} else {
					sp.names = names;
					message.setStatus(MessageType.TO_SOME);
				}
				sp.setMessage(message);
				// sp.setDataPacket(dataPacket);
				sp.setMsgType(MsgType.GROUP_MESSAGE);
				sp.setName(parent.userName);


				parent.sendPacket(sp);

				msgComboBox.setSelectedIndex(-1);
				msgArea.append(parent.userName + ":" + msg + "\n");
			}
		}
	}


	private void handleExitGame() {
		int result = JOptionPane.showConfirmDialog(this, "���� ��ӧ֧�֧ߧ�, ���� ����ڧ�� �ӧ��ۧ�� �ڧ� �ڧԧ��?��",
				"���� ��ӧ֧�֧ߧ�, ���� ����ڧ�� �ӧ��ۧ�� �ڧ� �ڧԧ��??", JOptionPane.YES_NO_OPTION,
				JOptionPane.INFORMATION_MESSAGE);

		if (result == JOptionPane.NO_OPTION) {
			System.out.println("���ԧ��� �ߧ� �ӧ���֧� �ڧ� �ڧԧ����");
			return;
		}
		System.out.println("���ԧ��� ���ҧڧ�ѧ֧��� ���ܧڧߧ��� �ڧԧ�壡");
		MsgPacket packet = new MsgPacket();
		packet.setName(parent.userName);
		packet.setRole(role);
		if (role == PlayerRole.ROLE_BLACK) {
			packet.setMsgType(MsgType.PLAYER_EXIT_CREATED_GAME);
			int size = parent.creators.size();
			for (int index = 0; index < size; index++) {
				Creator creator = parent.creators.get(index);
				for (int m = 0; m < creator.getMembers().size(); m++) {
					if (creator.getMembers().get(m).getName().equals(
							parent.userName)) {
						packet.setCreator(creator);
						System.out.println("���ѧ�ݧ� �ڧߧ���ާѧ�ڧ� �� �ԧ����� �ڧԧ��ܧѣ�");
						break;
					}
				}
			}

		} else if (role == PlayerRole.ROLE_RED) {
			packet.setMsgType(MsgType.CREATOR_EXIT_CREATED_GAME);
		}

		if (gameStart) {
			// packet.setStatus(DATA_PACKET);
			packet.setMsgType(MsgType.GAME_EXIT);

			System.out.println("������ѧ��� ���ܧݧ��ڧ�� ���ߧ�ӧ�� �ާ�٧��ܧ壡");
			bgSound.stop();
			client.board.getWinkThread().interrupt();

		}
		parent.isJoin = false;
		parent.setMenuAndButtonEnabled(true);
		parent.sendPacket(packet);

		this.dispose();

	}


	public void handleDataPacket(MsgPacket packet) {
		MsgType status = packet.getMsgType();
		JLabel gameStatus = client.board.gameStatusContent;

		if (status == MsgType.GAME_UNDO) {
			MsgPacket sp = new MsgPacket();
			sp.setName(parent.userName);
			sp.names.add(packet.getName());
			int result = JOptionPane.showConfirmDialog(this, "������ڧӧߧѧ� ������ߧ� �����ڧ� ���اѧݧ֧ߧڧ�, �ӧ� ���ԧݧѧ�ߧ���",
					"������ڧӧߧѧ� ������ߧ� �����ڧ� ���اѧݧ֧ߧڧ�, �ӧ� ���ԧݧѧ�ߧ���", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {
				// sp.setStatus(DATA_PACKET);
				sp.setMsgType(MsgType.GAME_BACK_YES);
				client.board.myTurn = !client.board.myTurn;
				if (client.board.myTurn) {
					client.board.gameStatusContent.setText(SPACE
							+ "������ڧӧߧѧ� ������ߧ� �����ڧ� ���اѧݧ֧ߧڧ�! ���֧�֧�� �ާ�� ���֧�֧է� �ڧէ�ڣ�");
				} else {
					client.board.gameStatusContent.setText(SPACE
							+ "������ڧӧߧѧ� ������ߧ� �����ڧ� ���اѧݧ֧ߧڧ�! ���اڧէѧߧڧ� �էӧڧا֧ߧڧ� �����ڧӧߧڧܧѣ�");
				}
				client.board.chessManual.removeManualItem();
			} else {
				sp.setMsgType(MsgType.GAME_BACK_NO);
				// sp.getDataPacket().setStatus(GAME_BACK_NO);
			}
			parent.sendPacket(sp);
		}
		else if (status == MsgType.GAME_BACK_YES) {
			int size = client.records.getManualItems().size();
			if (size > 0) {
				client.records.removeManualItem();
				client.board.myTurn = !client.board.myTurn;

				if (client.board.myTurn) {
					gameStatus.setText(SPACE + "���֧�֧�� �ާ�� ���֧�֧է� �ڧէ�ڣ�");
				} else {
					gameStatus.setText(SPACE + "���اڧէѧߧڧ� �էӧڧا֧ߧڧ� �����ڧӧߧڧܧѣ�");
				}
			} else {
				gameStatus.setText(gameStatus.getText() + "���� �ާ�ԧ� �ҧ�ݧ��� ���اѧݧ֧�� �� ��ѧ�ާѧ�ѧ磡");
			}
			client.msgArea.append(SERVER_NAME + ":" + packet.getName()
					+ "����ԧݧѧ�֧� �ߧ� �ӧѧ� �٧ѧ���� ���اѧݧ֧ߧڧ�\n");
		} else if (status == MsgType.GAME_BACK_NO) {
			client.msgArea.append(SERVER_NAME + ":" + packet.getName()
					+ "���� ���ԧݧѧ�֧� �ߧ� �ӧѧ�� ������ҧ� �� ���اѧݧ֧ߧڧڣ�\n");
		}


		else if (status == MsgType.PIECE_MOVING) {
			try {
				client.board.handleMoveMessage(packet);
			} catch (Exception e) {
				System.out.println("���� ��էѧݧ��� ���ݧ��ڧ�� �ާ�ҧڧݧ�ߧ�� ����ҧ�֧ߧڧ֣�");
				e.printStackTrace();
			}
		}

		else if (status == MsgType.GAME_EXIT) {
			gameStatus.setText(SPACE + packet.getName() + "������֧� �ڧ� �ڧԧ����");
			String name = packet.getName();
			System.out.println(name + "�����ۧ�� �ڧ� �ڧԧ��");
			PlayerRole role = packet.getRole();

			if (role == PlayerRole.ROLE_OBSERVER
					|| role == PlayerRole.ROLE_JUDGMENT) {
				client.msgArea.append(SERVER_NAME + ":" + name + "������֧� �ڧ� �ڧԧ����");
			} else if (role == PlayerRole.ROLE_RED
					|| role == PlayerRole.ROLE_BLACK) {
				client.msgArea.append(SERVER_NAME + ":" + name + "������֧� �ڧ� �ڧԧ����");
				if (role == PlayerRole.ROLE_RED) {
					for (int index = 0; index < parent.creators.size(); index++) {
						Creator creator = parent.creators.get(index);
						if (creator.getUser().getName().equals(name)) {
							parent.creators.remove(index);
							parent.updateCreators();
							break;
						}
					}
				}
				client.board.myTurn = false;


				client.pauseGame.setEnabled(false);
				client.pause.setEnabled(false);
				client.giveIn.setEnabled(false);
				client.undo.setEnabled(false);
				names.remove(name);
				if (names.size() == 0) {
					client.send.setEnabled(false);
				}
				client.updateNames();
			}

		}

		else if (status == MsgType.PLAYER_GIVEIN) {
			gameStatus.setText(SPACE + packet.getName() + "���էѧݧ��!��");
			client.board.myTurn = false;
			ChessUtil.playSound("gamewin.wav");
		}

		else if (status == MsgType.GAME_PAUSE) {
			client.board.otherIsPause = true;
			if (client.board.isPause) {
				gameStatus.setText(SPACE + "�� �ӧ�, �� �ӧѧ� ���ҧ֧�֧էߧڧ� ���ڧ���ѧߧ�ӧڧݧ� �ڧԧ��.��");
			} else {
				gameStatus.setText(SPACE + "������ڧӧߧڧ� �����ѧӧڧ� �ڧԧ�� �ߧ� ��ѧ�٧壡");
			}
		}

		else if (status == MsgType.GAME_CONTINUE) {
			client.board.otherIsPause = false;
			if (client.board.isPause) {
				gameStatus.setText(SPACE + "�� �����ѧӧڧ� �ڧԧ�� �ߧ� ��ѧ�٧壡");
			} else {
				if (client.board.myTurn) {
					gameStatus.setText(SPACE + "����� ���֧�֧է� �ڧէ�ڣ�");
				} else {
					gameStatus.setText(SPACE + "���اڧէѧߧڧ� �էӧڧا֧ߧڧ� �����ڧӧߧڧܧѣ�");
				}
			}
		}

		else if (status == MsgType.GAME_MESSAGE) {
			ChessUtil.playSound("msg.wav");
			Message message = packet.getMessage();
			// String date = message.getDate();
			String content = message.getContent();

			String tempMsg = packet.getName() + " " + ChessUtil.getTime()
					+ "\n   " + content + "\n";

			client.addMsg(tempMsg);
			client.msgRecord += tempMsg;
			client.msgArea.setCaretPosition(msgArea.getText().length());
			validate();
			repaint();
		}

	}


	public void updateRole(String userName, PlayerRole role) {
		for (int i = 0; i < 4; i++) {
			String name = (String) groupTable.getValueAt(i, 0);
			if (name != null && name.equals(userName)) {
				switch (role) {
				case ROLE_RED:
					groupTable.setValueAt("����ѧ�ߧѧ�", i, 1);
					groupTable.setValueAt(ChessUtil
							.getImageIcon("hongshuai.gif"), i, 3);
					break;
				case ROLE_BLACK:
					groupTable.setValueAt("���֧�ߧ���", i, 1);
					groupTable.setValueAt(ChessUtil
							.getImageIcon("heijiang.gif"), i, 3);
					break;
				case ROLE_OBSERVER:
					groupTable.setValueAt("���ѧҧݧ�էѧ�֧ݧ�", i, 1);
					groupTable.setValueAt(ChessUtil
							.getImageIcon("observer.png"), i, 3);
					break;
				case ROLE_JUDGMENT:
					groupTable.setValueAt("��֧�֧��", i, 1);
					groupTable.setValueAt(ChessUtil
							.getImageIcon("judgment.png"), i, 3);
					break;
				}
			}
		}
	}


	public void updateNames() {
		names.clear();
		for (int i = 0; i < 4; i++) {
			String name = (String) groupTable.getValueAt(i, 0);
			if ((name != null)
					&& (!name.equals("") && (!name.equals(parent.userName)))) {
				names.add(name);
			}
		}

		client.updateNames();

		userComboBox.removeAllItems();
		userComboBox.addItem("�����");

		int size = names.size();
		for (int index = 0; index < size; index++) {
			String name = names.get(index);
			if (!name.equals(parent.userName)) {
				userComboBox.addItem(name);
			}
		}
	}


	public void switchBgsound(boolean flag) {
		if (flag) {
			if (bgSound != null) {
				bgSound.loop();
			}

		} else {
			if (bgSound != null) {
				bgSound.stop();
			}

		}
	}

	public void validateAll() {
		client.board.validate();
		client.board.repaint();
		client.validate();
		client.repaint();
		validate();
		repaint();
	}
}
