
package cn.fansunion.chinesechess.net.client;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.config.PropertyReader;
import cn.fansunion.chinesechess.load.ChessLoadingGUI;
import cn.fansunion.chinesechess.net.NetworkConstants;
import cn.fansunion.chinesechess.net.common.Creator;
import cn.fansunion.chinesechess.net.common.CreatorTableModel;
import cn.fansunion.chinesechess.net.common.JTableUtil;
import cn.fansunion.chinesechess.net.common.Member;
import cn.fansunion.chinesechess.net.common.Message;
import cn.fansunion.chinesechess.net.common.MsgPacket;
import cn.fansunion.chinesechess.net.common.Player;
import cn.fansunion.chinesechess.net.common.PlayerTableModel;
import cn.fansunion.chinesechess.net.common.Message.MessageType;
import cn.fansunion.chinesechess.net.common.MsgPacket.MsgType;
import cn.fansunion.chinesechess.net.common.MsgPacket.PlayerRole;
import cn.fansunion.chinesechess.net.server.User;


public class RoomGUI extends JFrame implements ActionListener, NAME {

	private static final long serialVersionUID = 101L;

	public boolean isJoin = false;

	JComboBox msgComboBox;


	String[] initialMsgs = { "���ѧ� �٧ߧѧܧ�ާ��ӧ�\", \"���������ڧ��, �� ���է�اէ�, ���ܧ� ����ѧէ� �ߧ� ��ۧէ֧�\", \"���ѧ�� ��ѧ�ާѧ�ߧ��� ���է� ��ѧ� �������\", \"���ԧ�ѧ� ��ߧ�ӧ� �� ��ݧ֧է���ڧ� ��ѧ�, �� ����ا�" };

	public JTextArea msgArea;

	String[] initialUsers = { "�����" };

	private JComboBox userComboBox;

	List<Player> players = Collections
			.synchronizedList(new ArrayList<Player>());

	List<Creator> creators = Collections
			.synchronizedList(new ArrayList<Creator>());

	PlayerGroupGUI group;

	public JButton create, join, load, exit, send;

	public JMenuBar bar = new JMenuBar();;

	public JMenu fileMenu, helpMenu;

	public JMenuItem welcome, aboutGame, helpContent;

	public JMenuItem createGame, exitGame, loadManual;

	private Socket roomSocket;

	public ObjectOutputStream toServer;

	public ObjectInputStream fromServer;

	public String userName;

	public JTextArea inAndOutArea;

	JTable leftTable, rightTable;

	public RoomGUI(String name) {
		this.userName = name;
		initButtons();
		initMenu();
		initPanels();
		handleKeyEvent();

		setSize(1002, 700);
		setTitle(PropertyReader.get("ROOM_TITLE"));
		setIconImage(ChessUtil.getAppIcon());
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}

			public void windowActivated(WindowEvent e) {
				msgComboBox.requestFocusInWindow();
			};

		});
	}


	private void initPanels() {
		JPanel leftPanel = new JPanel(new BorderLayout());

		JPanel rightPanel = new JPanel();

		int[] widths = { 8, 8, 8, 8 };

		leftTable = new JTable(new CreatorTableModel());
		leftTable.setGridColor(Color.BLUE);

		JTableUtil.fitTableColumns(leftTable, widths);
		TitledBorder gameBorder = new TitledBorder("���ߧ���ާѧ�ڧ� �� �ߧ�ާ֧�ѧ�");
		leftPanel.setBorder(gameBorder);
		leftPanel.setLayout(new BorderLayout());
		leftPanel.setPreferredSize(new Dimension(500, 700));
		leftPanel.setLayout(new BorderLayout());

		JScrollPane creatorScroll = new JScrollPane(leftTable);
		leftTable.setPreferredSize(new Dimension(470, 240));
		leftTable.setRowHeight(20);
		creatorScroll.setPreferredSize(new Dimension(474, 268));

		JPanel creatorPanel = new JPanel();
		creatorPanel.setPreferredSize(new Dimension(480, 300));
		TitledBorder creatorBorder = new TitledBorder("���ߧ���ާѧ�ڧ� ��� �ѧӧ����");
		creatorPanel.setBorder(creatorBorder);
		creatorPanel.add(creatorScroll);

		JPanel msgPanel = new JPanel(new BorderLayout());
		TitledBorder msgBorder = new TitledBorder("����ӧ���� �ڧԧ��ܧ��");
		msgPanel.setBorder(msgBorder);
		msgArea = new JTextArea();
		msgArea.setRows(8);
		msgArea.setFont(new Font("����", Font.PLAIN, 16));
		msgArea.setEditable(false);
		JScrollPane displayScroll = new JScrollPane(msgArea);

		JPanel sendMsgPanel = new JPanel(new BorderLayout());

		msgComboBox = new JComboBox(initialMsgs);
		msgComboBox.setSelectedIndex(-1);
		msgComboBox.setPreferredSize(new Dimension(290, 30));
		msgComboBox.setEditable(true);
		msgComboBox.setToolTipText(PropertyReader.get("MSG_JCOMBOBOX_TOOLTIP"));
		msgComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));

		userComboBox = new JComboBox(initialUsers);
		userComboBox.setSelectedIndex(0);
		userComboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));
		userComboBox.setToolTipText(PropertyReader
				.get("USER_JCOMBOBOX_TOOLTIP"));
		userComboBox.setEditable(false);
		userComboBox.setPreferredSize(new Dimension(80, 30));
		JPanel panel = new JPanel(new FlowLayout());
		panel.add(msgComboBox);
		panel.add(send);
		panel.add(userComboBox);
		sendMsgPanel.add(BorderLayout.NORTH, panel);
		msgPanel.add(BorderLayout.CENTER, displayScroll);
		msgPanel.add(BorderLayout.SOUTH, sendMsgPanel);

		JPanel controlPanel = new JPanel();
		controlPanel.add(create);
		controlPanel.add(join);
		controlPanel.add(load);
		controlPanel.add(exit);

		leftPanel.add(BorderLayout.NORTH, creatorPanel);
		leftPanel.add(BorderLayout.CENTER, msgPanel);
		leftPanel.add(BorderLayout.SOUTH, controlPanel);

		rightTable = new JTable(new PlayerTableModel());
		rightTable.setGridColor(Color.BLUE);
		rightTable.setRowHeight(20);
		JTableUtil.fitTableColumns(rightTable, widths);

		rightPanel = new JPanel(new BorderLayout());
		JScrollPane playersScroll = new JScrollPane(rightTable);
		playersScroll.setPreferredSize(new Dimension(470, 430));
		rightPanel.add(BorderLayout.NORTH, playersScroll);
		TitledBorder playerBorder = new TitledBorder("����ڧ��� �ڧԧ��ܧ��");
		rightPanel.setBorder(playerBorder);
		rightPanel.setPreferredSize(new Dimension(500, 700));

		JPanel inAndOutPanel = new JPanel();
		TitledBorder inAndOutBorder = new TitledBorder("�������֧էڧߧ֧ߧڧ� �� ���ѧ���ѧӧѧߧڧ�");
		inAndOutPanel.setBorder(inAndOutBorder);

		inAndOutArea = new JTextArea();
		inAndOutArea.setRows(6);
		inAndOutArea.setFont(new Font("����", Font.PLAIN, 16));
		inAndOutArea.setEditable(false);
		inAndOutArea.setPreferredSize(new Dimension(440, 130));
		JScrollPane inAndOutAreaScroll = new JScrollPane(inAndOutArea);
		inAndOutAreaScroll.setPreferredSize(new Dimension(450, 150));
		inAndOutPanel.add(inAndOutAreaScroll);
		rightPanel.add(BorderLayout.CENTER, inAndOutPanel);

		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,
				leftPanel, rightPanel);
		split.setDividerSize(2);
		split.setDividerLocation(500);

		add(split, BorderLayout.CENTER);

	}


	private void initButtons() {
		ImageIcon ii = ChessUtil.getImageIcon("create.png");
		int width = ii.getIconWidth();
		int height = ii.getIconHeight();

	
		create = new JButton(ChessUtil.getImageIcon("create.png"));
		create.setPreferredSize(new Dimension(width, height));
		create.setToolTipText(PropertyReader
				.get("CREAGE_GAME__JBUTTON_TOOLTIP"));
		create.setCursor(new Cursor(Cursor.HAND_CURSOR));
		create.addActionListener(this);

		join = new JButton(ChessUtil.getImageIcon("join.png"));
		join.setPreferredSize(new Dimension(width, height));
		join.setToolTipText(PropertyReader.get("JOIN_GAME_JBUTTON_TOOLTIP"));
		join.setCursor(new Cursor(Cursor.HAND_CURSOR));
		join.addActionListener(this);

		load = new JButton(ChessUtil.getImageIcon("load.png"));
		load.setPreferredSize(new Dimension(width, height));
		load.setToolTipText(PropertyReader.get("LOAD_GAME_JBUTTON_TOOLTIP"));
		load.setCursor(new Cursor(Cursor.HAND_CURSOR));
		load.addActionListener(this);

		exit = new JButton(ChessUtil.getImageIcon("exit.png"));
		exit.setPreferredSize(new Dimension(width, height));
		exit.setToolTipText(PropertyReader.get("EXIT_GAME_JBUTTON_TOOLTIP"));
		exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
		exit.addActionListener(this);

		send = new JButton(ChessUtil.getImageIcon("send.png"));
		send.setPreferredSize(new Dimension(width, height));
		send.setToolTipText(PropertyReader.get("SEND_JBUTTON_TOOLTIP"));
		send.setCursor(new Cursor(Cursor.HAND_CURSOR));
		send.addActionListener(this);

	}


	private void initMenu() {

		fileMenu = new JMenu("�ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��(C)");

		helpMenu = new JMenu("����ާ�ԧڧ��H)");

		welcome = new JMenuItem("�է�ҧ�� ���اѧݧ�ӧѧ��", ChessUtil.getImageIcon("welcome.gif"));

		helpContent = new JMenuItem("����է֧�اѧߧڧ� ����ѧӧܧ�", ChessUtil.getImageIcon("help.gif"));

		aboutGame = new JMenuItem("�� �ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ�ѧ�", ChessUtil.getImageIcon("info.gif"));

		createGame = new JMenuItem("����٧էѧ�� �ڧԧ��");

		exitGame = new JMenuItem("�ӧ��ۧ�� �ڧ� �ڧԧ��", ChessUtil.getImageIcon("exit.gif"));

		loadManual = new JMenuItem("���ѧԧ��٧ڧ�� �ڧԧ��");

		fileMenu.add(createGame);
		fileMenu.add(loadManual);
		fileMenu.add(exitGame);

		fileMenu.setMnemonic(KeyEvent.VK_C);
		helpMenu.setMnemonic(KeyEvent.VK_H);

		helpMenu.add(welcome);
		helpMenu.addSeparator();
		helpMenu.add(helpContent);
		helpMenu.addSeparator();
		helpMenu.add(aboutGame);

		createGame.addActionListener(this);
		loadManual.addActionListener(this);

		welcome.addActionListener(this);
		exitGame.addActionListener(this);
		aboutGame.addActionListener(this);
		helpContent.addActionListener(this);
		bar.add(fileMenu);
		bar.add(helpMenu);
		setJMenuBar(bar);

		createGame.setAccelerator(KeyStroke.getKeyStroke('C',
				InputEvent.CTRL_DOWN_MASK));
		loadManual.setAccelerator(KeyStroke.getKeyStroke('L',
				InputEvent.CTRL_DOWN_MASK));

		exitGame.setAccelerator(KeyStroke.getKeyStroke('E',
				InputEvent.CTRL_DOWN_MASK));
		welcome.setAccelerator(KeyStroke.getKeyStroke('W',
				InputEvent.CTRL_DOWN_MASK));
		helpContent.setAccelerator(KeyStroke.getKeyStroke('H',
				InputEvent.CTRL_DOWN_MASK));
		aboutGame.setAccelerator(KeyStroke.getKeyStroke('A',
				InputEvent.CTRL_DOWN_MASK));

	}


	public boolean connectToServer(String host) {
		boolean flag = false;
		try {
			roomSocket = new Socket(host, NetworkConstants.PORT);
			msgArea.append(SERVER_NAME + ":" + SYSTEM_WELCOME + "--"
					+ ChessUtil.getTime() + "\n");

			try {
				toServer = new ObjectOutputStream(roomSocket.getOutputStream());
				fromServer = new ObjectInputStream(roomSocket.getInputStream());

				if (fromServer == null) {
					System.out.println("����ڧҧܧ� �������֧ߧڧ� �ӧ����էߧ�ԧ� �����ܧ�");
				} else {
					MsgPacket packet = new MsgPacket();
					packet.setMsgType(MsgType.PLAYER_LOGIN);
					packet.setName(userName);
					sendPacket(packet);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			flag = true;

		} catch (Exception ex) {
			flag = false;
			ex.printStackTrace();
			System.err.println(ex);
		}
		return flag;

	}


	@SuppressWarnings("unchecked")
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		if (source == create || source == createGame) {
			if (creators.size() >= 10) {
				JOptionPane.showMessageDialog(this, "����ݧڧ�֧��ӧ� ���٧էѧ�֧ݧ֧� �է���ڧԧݧ� �ӧ֧��ߧ֧ԧ� ���֧է֧ݧѣ�",
						"����ݧڧ�֧��ӧ� ���٧էѧ�֧ݧ֧� �է���ڧԧݧ� �ӧ֧��ߧ֧ԧ� ���֧է֧ݧѣ�", JOptionPane.INFORMATION_MESSAGE);
				return;
			}

			group = new PlayerGroupGUI(this);
			group.role = PlayerRole.ROLE_RED;
			isJoin = true;

			System.out.println("����� ���ݧ� - ��ӧ��֧�:" + PlayerRole.ROLE_RED);
			MsgPacket packet = new MsgPacket();
			packet.setMsgType(MsgType.ADD_CREATOR);
			Creator creator = new Creator();
			User user = new User();
			user.setName(userName);
			creator.setUser(user);
			creator.setDate(ChessUtil.getTime());
			creator.setGameStatus("�ȴ�");
			creator.setIp(roomSocket.getLocalAddress().getHostAddress());
			packet.setCreator(creator);
			sendPacket(packet);

			group.setIconImage(ChessUtil.getAppIcon());
			group.setVisible(true);

			setMenuAndButtonEnabled(false);

		}

		else if (source == join) {
			int selectedRow = leftTable.getSelectedRow();
			if (selectedRow == -1) {
				return;
			}
			String name = (String) leftTable.getValueAt(selectedRow, 0);
			int num = (Integer) leftTable.getValueAt(selectedRow, 2);
			String gameStatus = (String) leftTable.getValueAt(selectedRow, 3);
			if (gameStatus == CREATOR_PK) {
				JOptionPane.showMessageDialog(this, "���ԧ�� �� �����֧��֣�", "���ԧ�� �� �����֧��֣�",
						JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			if (num >= 4) {
				JOptionPane.showMessageDialog(this, "����ݧڧ�֧��ӧ� �ڧԧ��ܧ�� �է���ڧԧݧ� �ӧ֧��ߧ֧ԧ� ���֧է֧ݧѣ�",
						"����ݧڧ�֧��ӧ� �ڧԧ��ܧ�� �է���ڧԧݧ� �ӧ֧��ߧ֧ԧ� ���֧է֧ݧѣ�", JOptionPane.INFORMATION_MESSAGE);
				return;
			}

			group = new PlayerGroupGUI(this);
			group.role = PlayerRole.ROLE_BLACK;

			isJoin = true;
			group.start.setEnabled(false);
			System.out.println("����� ��֧���ߧѧ� - �ڧԧ���:" + PlayerRole.ROLE_BLACK);

			if ((name != null) && (!name.equals(""))) {
				System.out.println("����� ��֧���ߧѧ�-�ڧԧ���");
				MsgPacket packet = new MsgPacket();
				packet.setName(userName);
				packet.setMsgType(MsgType.PLAYER_JOIN_CREATED_GAME);
				Member member = new Member();
				member.setName(userName);
				member.setRole(group.role);
				member.setIp(roomSocket.getInetAddress().getHostAddress());
				for (int i = 0; i < creators.size(); i++) {
					Creator creator = creators.get(i);
					if (creator.getUser().getName().equals(name)) {
						member.setCid(creator.getCid());
						break;
					}
				}
				packet.setMember(member);
				sendPacket(packet);

				group.setVisible(true);
				group.setIconImage(ChessUtil.getAppIcon());

				setMenuAndButtonEnabled(false);

			}
		} else if (source == exit || source == exitGame) {
			handleExitGame();
		} else if (source == send) {
			String msg = (String) msgComboBox.getSelectedItem();
			if (msg != null && !msg.equals("")) {
				MsgPacket sp = new MsgPacket();
				// DataPacket dataPacket = new DataPacket();
				sp.setMsgType(MsgType.ROOM_MESSAGE);
				Message message = new Message();
				message.setContent(msg);
				message.setDate(ChessUtil.getDateAndTime());
				String dest = (String) userComboBox.getSelectedItem();
				ArrayList<String> names = new ArrayList<String>();
				names.add(dest);

				if (dest.equals("�����")) {
					message.setStatus(MessageType.TO_ALL);
				} else {
					sp.names = names;
					message.setStatus(MessageType.TO_SOME);
				}
				sp.setMessage(message);
				// sp.setDataPacket(dataPacket);
				sp.setMsgType(MsgType.ROOM_MESSAGE);
				sp.setName(userName);

				sendPacket(sp);

				msgComboBox.setSelectedIndex(-1);
				msgArea.append(userName + ":" + msg + "\n");
			}
		}
		else if (source == load || source == loadManual) {
			ChessLoadingGUI test = new ChessLoadingGUI();
			test.setVisible(true);
		}

		else if (source == aboutGame) {
			ChessUtil.showAboutDialog();

		}

		else if (source == helpContent) {
			ChessUtil.showHelpDialog();
		}
		else if (source == welcome) {
			JOptionPane.showMessageDialog(this, "����ҧ�� ���اѧݧ�ӧѧ�� �� �ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��", "����ҧ�� ���اѧݧ�ӧѧ�� �� �ܧڧ�ѧۧ�ܧڧ� ��ѧ�ާѧ��",
					JOptionPane.INFORMATION_MESSAGE);
		}

	}


	public void setMenuAndButtonEnabled(boolean isEnable) {
		if (isEnable) {
			create.setEnabled(true);
			join.setEnabled(true);
			load.setEnabled(true);
			exit.setEnabled(true);

			createGame.setEnabled(true);
			loadManual.setEnabled(true);
			exitGame.setEnabled(true);
		} else {
			create.setEnabled(false);
			join.setEnabled(false);
			load.setEnabled(false);
			exit.setEnabled(false);

			createGame.setEnabled(false);
			loadManual.setEnabled(false);
			exitGame.setEnabled(false);
		}
	}

	@SuppressWarnings("unused")
	private void closeSocket() {
		try {
			toServer.close();
			fromServer.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void sendPacket(MsgPacket packet) {
		System.out.println("������ѧӧܧ� �էѧߧߧ��� �ߧ� ��֧�ӧ֧⣡" + "����ѧ��� ����ҧ�֧ߧڧ�" + packet.getMsgType());
		try {
			toServer.writeObject(packet);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	private void handleKeyEvent() {
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {

			public void eventDispatched(AWTEvent event) {
				if (((KeyEvent) event).getID() == KeyEvent.KEY_PRESSED) {
					int code = ((KeyEvent) event).getKeyCode();
					if (code == KeyEvent.VK_F1) {
						ChessUtil.showHelpDialog();
					}
				}
			}
		}, AWTEvent.KEY_EVENT_MASK);

	}


	public void work() {

		Thread thread = new Thread(new RoomThread());
		thread.start();
	}


	private class RoomThread implements Runnable {
		public void run() {
			try {
				while (true) {
					// if (running == RUNNING) {
					receiveInfoFromServer();
					/*
					 * } *else if (running == GAME_EXIT) { //
					 * System.out.println("�����ԧ�ѧާާ� ��ܧ��� �٧ѧӧ֧��ڧ���"); Thread.sleep(1000); } else
					 * if (running == GAME_PAUSE) { Thread.sleep(1000); }
					 */
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void receiveInfoFromServer() throws Exception {
		MsgPacket serverPacket = new MsgPacket();
		if (fromServer != null) {
			serverPacket = (MsgPacket) fromServer.readObject();
		}
		MsgType status = serverPacket.getMsgType();
		System.out.println("���ݧڧ֧ߧ� ����֧�ߧ� ���ݧ��ڧ� ����ҧ�֧ߧڧ� ��֧�ӧ֧��" + " ����ѧ��� ����ҧ�֧ߧڧ�:" + status);

		switch (status) {

		case CREATOR_LIST:
			System.out.println(userName + "����ݧ��ڧ�� ���ڧ��� ���٧էѧ�֧ݧ֧�");
			addCreators(serverPacket);
			break;

		case PLAYER_LIST:
			System.out.println("�٧ѧާ֧�ѧߧ�" + serverPacket.getPlayers().size()
					+ "���ߧ���ާѧ�ڧ� ��� �ڧԧ��ܧ�:");
			addPlayers(serverPacket);
			break;

		case ADD_PLAYER:
			addPlayer(serverPacket);
			break;

		case SUB_PLAYER:
			subPlayer(serverPacket);
			break;

		case ADD_CREATOR:
			System.out.println("���ݧڧ֧ߧ� ����֧�ߧ� ���ݧ��ڧ� ����ҧ�֧ߧڧ� ���٧էѧ�֧ݧ� �է�ҧѧӧݧ֧ߧڧ�");
			addCreator(serverPacket);
			break;

		case SUB_CREATOR:
			subCreator(serverPacket);
			break;

		case CREATOR_AND_MEMBER:
			System.out.println("���ݧڧ֧ߧ� ����֧�ߧ� ���ݧ��ڧ� �ڧߧ���ާѧ�ڧ� �� �ԧ����� ���ѧ��ߧڧܧ��, �ܧ�ݧڧ�֧��ӧ� ���ѧ��ߧڧܧ��:"
					+ serverPacket.members.size());
			group.updateGroup(serverPacket);
			break;

		case PLAYER_JOIN_CREATED_GAME:
			handleJoinGame(serverPacket);
			break;
		case PLAYER_EXIT_CREATED_GAME:
			handlePlayerExitGame(serverPacket);
			break;

		case CREATOR_EXIT_CREATED_GAME:
			handleCreatorExitGame(serverPacket);
			break;
		case CREATOR_START_CREATED_GAME:
			group.handleCreatorStartGame();
			break;

		case CHANGE_GAME_STATUS:
			handleChangeGameStatus(serverPacket);
			break;
		case CHANGE_ROLE:
			changeRole(serverPacket);
			break;

		case ROOM_MESSAGE:
			handleRoomMessage(serverPacket);
			break;
		case GROUP_MESSAGE:
			handleGroupMessage(serverPacket);
			break;

		case GAME_MESSAGE:
		case PIECE_MOVING:
		case GAME_UNDO:
		case GAME_BACK_YES:
		case GAME_BACK_NO:
		case PLAYER_GIVEIN:
		case GAME_PAUSE:
		case GAME_CONTINUE:
		case GAME_EXIT:
			group.handleDataPacket(serverPacket);
			break;

		default:
			break;

		}
	}


	private void handleChangeGameStatus(MsgPacket serverPacket) {

		Creator creator = serverPacket.getCreator();
		String name = creator.getUser().getName();

		for (int index = 0; index < creators.size(); index++) {
			Creator c = creators.get(index);
			if (c.getUser().getName().equals(name)) {
				c.setGameStatus(CREATOR_PK);
				break;
			}
		}

		for (int i = 0; i < creator.getMembers().size(); i++) {
			String n = creator.getMembers().get(i).getName();

			int playersSize = players.size();
			for (int m = 0; m < playersSize; m++) {
				String name2 = players.get(m).getUser().getName();
				if (name2.equals(n) || name2.equals(name)) {
					players.get(m).setGameStatus(CREATOR_PK);
					break;
				}
			}
		}

	}


	private void handleGroupMessage(MsgPacket serverPacket) {
		// DataPacket dp = serverPacket.getDataPacket();
		Message m = serverPacket.getMessage();
		MessageType flag = m.getStatus();
		if (flag == MessageType.TO_ALL) {
			group.msgArea.append(serverPacket.getName() + ":" + m.getContent()
					+ "\n");
		} else if (flag == MessageType.TO_SOME) {
			group.msgArea.append("[���ڧ�ߧѧ� ��֧�֧�ڧ�ܧ�]" + serverPacket.getName() + ":"
					+ m.getContent() + "\n");
		}
	}


	private void handleRoomMessage(MsgPacket serverPacket) {
		// DataPacket dp = serverPacket.getDataPacket();
		Message m = serverPacket.getMessage();
		MessageType flag = m.getStatus();
		if (flag == MessageType.TO_ALL) {
			msgArea
					.append(serverPacket.getName() + ":" + m.getContent()
							+ "\n");

		} else if (flag == MessageType.TO_SOME) {
			msgArea.append("���ڧ�ߧѧ� ��֧�֧�ڧ�ܧ�:" + serverPacket.getName() + ":"
					+ m.getContent() + "\n");

		} else if (flag == MessageType.SYSTEM) {
			msgArea.append("��ڧ��֧ާ�:" + m.getContent() + "\n");

		}

	}


	private void changeRole(MsgPacket sp) {

		String name = sp.getName();
		PlayerRole role = sp.getRole();
		group.updateRole(name, role);
		System.out.println("���֧ܧ������� �ڧԧ��ܧ� ���ާ֧ߧ�ݧ� ��ӧ�� ���ݧ�, ����ݧ֧էߧ�� ���ݧ" + "role =" + role);
	}


	private void subPlayer(MsgPacket serverPacket) {
		for (int i = 0; i < players.size(); i++) {
			Player player = players.get(i);
			String name = serverPacket.getName();
			if (player.getUser().getName().equals(name)) {
				inAndOutArea.append(name + "����ܧڧߧ��� �ܧ�ާߧѧ��  --" + ChessUtil.getTime()
						+ "\n");
				players.remove(i);
				break;
			}
		}
		updatePlayers();
	}

	private void subCreator(MsgPacket serverPacket) {
		int size = creators.size();
		for (int index = 0; index < size; index++) {
			Creator creator = creators.get(index);
			if (creator.getUser().getName().equals(serverPacket.getName())) {
				System.out.println("���ӧ��� ��էѧݧ֧�");
				creators.remove(index);
				break;
			}
		}
		updateCreators();

	}


	private void handleCreatorExitGame(MsgPacket serverPacket) {
		String name = serverPacket.getName();
		String n = (String) group.groupTable.getValueAt(0, 0);

		if (userName.equals(n)) {
			return;
		}
		if (name.equals(n)) {
			group.msgArea.append(name + "�����ۧ�� �ڧ� �ڧԧ��");
			if (isJoin) {
				JOptionPane.showConfirmDialog(group, "����٧էѧ�֧ݧ� �ӧ���֧� �ڧ� �ڧԧ��! ���� ���ҧڧ�ѧ֧�֧�� �ӧ��ۧ��", "�ӧ��ҧ��ӧѧ��",
						JOptionPane.YES_OPTION);
			}
			group.setVisible(false);
			isJoin = false;
			setMenuAndButtonEnabled(true);
		}

	}


	private void handlePlayerExitGame(MsgPacket serverPacket) {
		group.msgArea.append(serverPacket.getName() + "�����ۧ�� �ڧ� �ڧԧ��");

		Creator creator = serverPacket.getCreator();

		int size = creators.size();
		for (int i = 0; i < size; i++) {
			if (creators.get(i).getCid() == creator.getCid()) {
				creators.get(i).setMembers(serverPacket.members);
				updateCreators();
			}
		}


		if (creator.getUser().getName().equals(userName)) {
			System.out.println("���ԧ��� ���֧�, ��ҧߧ�ӧڧ�� ���ڧ��� ���ѧ��ߧڧܧ��");
			group.updateGroup(serverPacket);
			return;
		}

		for (int k = 0; k < serverPacket.members.size(); k++) {
			if (serverPacket.members.get(k).getName().equals(userName)) {
				System.out.println("���ԧ��� ���֧�, ��ҧߧ�ӧڧ�� ���ڧ��� ���ѧ��ߧڧܧ��");
				group.updateGroup(serverPacket);
				return;
			}
		}

	}


	private void handleJoinGame(MsgPacket serverPacket) {
		group.msgArea.append(serverPacket.getName() + "����ڧ��֧էڧߧڧݧ�� �� �ڧԧ��\n");
		Creator creator = serverPacket.getCreator();

		int size = creators.size();
		for (int i = 0; i < size; i++) {
			if (creators.get(i).getCid() == creator.getCid()) {
				creators.get(i).setMembers(serverPacket.members);
				updateCreators();
			}
		}


		if (creator.getUser().getName().equals(userName)) {
			group.updateGroup(serverPacket);
			return;
		}

		for (int k = 0; k < serverPacket.members.size(); k++) {
			if (serverPacket.members.get(k).getName().equals(userName)) {
				group.updateGroup(serverPacket);
				return;
			}
		}
	}


	public void updateCreators() {
		for (int i = 0; i < NetworkConstants.CREATOR_MAX_SIZE; i++) {
			for (int j = 0; j < 4; j++) {
				leftTable.setValueAt("", i, j);
			}
		}
		int size = creators.size();
		for (int index = 0; index < size; index++) {
			System.out.println("���ݧ֧֧� ���ݧ��ڧ� �ߧ�ӧ��� ���ڧ��� ���٧էѧ�֧ݧ֧�: �����-�ӧ� ��֧ݧ�ӧ֧�" + size);
			Creator creator = creators.get(index);
			leftTable.setValueAt(creator.getUser().getName(), index, 0);
			leftTable.setValueAt(creator.getDate(), index, 1);
			leftTable.setValueAt(1 + creator.getMembers().size(), index, 2);
			leftTable.setValueAt(creator.getGameStatus(), index, 3);
		}
	}


	private void addCreators(MsgPacket serverPacket) {
		System.out.println("������������" + serverPacket.getCreators().size());
		creators = serverPacket.getCreators();
		updateCreators();
	}


	private void addCreator(MsgPacket serverPacket) {

		Creator creator = serverPacket.getCreator();
		creators.add(0, creator);
		updateCreators();
	}


	private void addPlayer(MsgPacket serverPacket) {
		Player player = serverPacket.getPlayer();
		players.add(player);
		updatePlayers();
		String name = player.getUser().getName();
		String loginTime = ChessUtil.getTime();
		inAndOutArea.append(name + "�����֧� �� �ܧ�ާߧѧ��  --" + loginTime + "\n");
	}


	private void addPlayers(MsgPacket serverPacket) {
		players = serverPacket.getPlayers();
		updatePlayers();
	}


	private void updatePlayers() {

		for (int i = 0; i < NetworkConstants.PLAYER_MAX_SIZE; i++) {
			for (int j = 0; j < 4; j++) {
				rightTable.setValueAt("", i, j);
			}
		}
		userComboBox.removeAllItems();
		userComboBox.addItem("�����");

		// ���������Ϣ
		int size = players.size();
		System.out.println("������" + size + "���ԧ���");
		for (int i = 0; i < size; i++) {
			Player player = players.get(i);
			rightTable.setValueAt(player.getUser().getName(), i, 0);
			rightTable.setValueAt(player.getIpAddress(), i, 1);
			rightTable.setValueAt(player.getLoginTime(), i, 2);
			rightTable.setValueAt(player.getGameStatus(), i, 3);

			String name = player.getUser().getName();
			if (!name.equals(userName)) {
				userComboBox.addItem(name);
				System.out.println("��������ܧ� ��ҧߧ�ӧڧ�� ���ڧ��� �ڧԧ��ܧ��:" + player.getIpAddress());
			}
		}

	}


	private void handleExitGame() {
		boolean exit = false;
		int result = JOptionPane.showConfirmDialog(this, "���� ��ӧ֧�֧ߧ�, ���� ����ڧ�� �ӧ��ۧ�� �ڧ� �ڧԧ��?��",
				"���� ��ӧ֧�֧ߧ�, ���� ����ڧ�� �ӧ��ۧ�� �ڧ� �ڧԧ��??", JOptionPane.YES_NO_OPTION);
		if (result == JOptionPane.YES_OPTION) {
			if (isJoin) {
				JOptionPane.showMessageDialog(this, "����اѧݧ�ۧ���, �ӧ��ۧէڧ�� �ڧ� �ڧԧ��, �� �ܧ������ �ӧ� ���ڧ��֧էڧߧڧݧڧ��",
						"����اѧݧ�ۧ���, �ӧ��ۧէڧ�� �ڧ� �ڧԧ��, �� �ܧ������ �ӧ� ���ڧ��֧էڧߧڧݧڧ��?", JOptionPane.YES_OPTION);
				return;
			}
			MsgPacket sp = new MsgPacket();
			sp.setMsgType(MsgType.BYE_BYE);
			sp.setName(userName);
			sendPacket(sp);
			// closeSocket();
			System.out.println(userName + "�� �ӧ����է� �ڧ� �ڧԧ����");
			exit = true;
		}
		if (exit) {
			System.exit(0);
		}
	}
}
