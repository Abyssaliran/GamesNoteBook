
package cn.fansunion.chinesechess.net.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.fansunion.chinesechess.config.MyPropertyReader;



public class ObserverUtil {

	public static List<String> filterStrings = new ArrayList<String>();

	private static HashMap<String, String> properties;

	static {
		MyPropertyReader reader = new MyPropertyReader("config/filter.ini");
		properties = reader.getProperties();

	}

	public static String get(String key) {
		return properties.get(key);
	}


	public static String filter(String message) {
		for (Map.Entry<String, String> property : properties.entrySet()) {
			String filter = property.getValue();
			if (message.contains(filter)) {
				message = message.replaceAll(filter, "*");
			}
		}

		return message;
	}

	public static void main(String[] args) {
		display(filterStrings);
		String msg = "�R�˽��ߣ����߰���܇�˽�һ";
		System.out.println(filter(msg));
	}

	public static void display(List<String> strings) {
		if (strings == null) {
			return;
		}
		int size = strings.size();
		for (int index = 0; index < size; index++) {
			System.out.print(strings.get(index) + "\t");
		}
		System.out.println();
	}
}
