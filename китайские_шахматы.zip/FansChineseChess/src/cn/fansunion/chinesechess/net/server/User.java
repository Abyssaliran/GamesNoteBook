
package cn.fansunion.chinesechess.net.server;

import java.io.Serializable;


public class User implements Serializable {

	private static final long serialVersionUID = 3698L;

	private int uid;

	private String name;

	private String ip;
	

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}
}
