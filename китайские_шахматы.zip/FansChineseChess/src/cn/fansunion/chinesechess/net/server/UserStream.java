
package cn.fansunion.chinesechess.net.server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


public class UserStream {
	private String name;

	private Socket socket;

	private ObjectOutputStream oos;

	private ObjectInputStream ois;

	public UserStream() {

	}

	public UserStream(String name, ObjectOutputStream oos,
			ObjectInputStream ois, Socket socket) {
		this.name = name;
		this.oos = oos;
		this.ois = ois;
		this.socket = socket;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ObjectInputStream getOis() {
		return ois;
	}

	public void setOis(ObjectInputStream ois) {
		this.ois = ois;
	}

	public ObjectOutputStream getOos() {
		return oos;
	}

	public void setOos(ObjectOutputStream oos) {
		this.oos = oos;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}
}
