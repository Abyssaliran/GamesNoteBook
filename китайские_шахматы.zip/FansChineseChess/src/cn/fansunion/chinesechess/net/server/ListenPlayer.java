
package cn.fansunion.chinesechess.net.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import cn.fansunion.chinesechess.ServerGUI;
import cn.fansunion.chinesechess.net.common.MsgPacket;
import cn.fansunion.chinesechess.net.common.Message.MessageType;
import cn.fansunion.chinesechess.net.common.MsgPacket.MsgType;



public class ListenPlayer implements Runnable {

	private ObjectInputStream ois;

	private ObjectOutputStream oos;

	Socket socket;

	ServerGUI parent;

	MsgPacket packet;

	public ListenPlayer(ServerGUI parent, ObjectOutputStream oos,
			ObjectInputStream ois, Socket socket) {
		this.parent = parent;
		this.oos = oos;
		this.ois = ois;
		this.socket = socket;
	}


	public void run() {
		try {
			while (true) {

				if (ois != null) {
					packet = (MsgPacket) ois.readObject();
				} else {
					System.out.println("ois = null");
				}

				MsgType status = packet.getMsgType();
				System.out.println("���֧�ӧ֧� ���ݧ��ڧ� ����ҧ�֧ߧڧ� �ڧԧ��ܧ�, ���ѧ��� ����ҧ�֧ߧڧ�" + status);

				if (status == MsgType.ADD_CREATOR) {
					parent.addCreator(packet);
				}
				else if (status == MsgType.PLAYER_JOIN_CREATED_GAME) {
					System.out.println("���֧�ӧ֧� ����֧�ߧ� ���ݧ��ڧ� ����ҧ�֧ߧڧ� �� ���ڧ��֧էڧߧ֧ߧڧ� �ܧݧڧ֧ߧ��");
					parent.addMemer(packet);
				}
				else if (status == MsgType.CREATOR_EXIT_CREATED_GAME) {
					parent.subCreator(packet);
				}
				else if (status == MsgType.PLAYER_EXIT_CREATED_GAME) {
					parent.subMember(packet);
				}
				else if (status == MsgType.BYE_BYE) {
					parent.subPlayer(packet);
					// close();
				}
				else if (status == MsgType.CREATOR_START_CREATED_GAME) {
					parent.startGame(packet);
				}
				else if (status == MsgType.CHANGE_ROLE) {
					parent.handleChangeRole(packet);
				}

				else if (status == MsgType.ROOM_MESSAGE) {
					MessageType flag = packet.getMessage().getStatus();
					if (flag == MessageType.TO_ALL) {
						parent.handleRoomMessage(packet);
						parent.notifyAllPlayers(oos, packet);
					} else {
						parent.notifyPlayersByName(packet.names, packet);
					}
				}
				else if (status == MsgType.GROUP_MESSAGE) {
					MessageType flag = packet.getMessage().getStatus();
					if (flag == MessageType.TO_ALL) {
						parent.handleRoomMessage(packet);
						parent.notifyAllPlayers(oos, packet);
					} else {
						parent.notifyPlayersByName(packet.names, packet);
					}
				} else if (status == MsgType.GAME_EXIT) {
					parent.handleDataPacket(packet);
				} else if (status == MsgType.GAME_MESSAGE) {
					parent.handleDataPacket(packet);
				} else if (status == MsgType.PIECE_MOVING
						|| status == MsgType.GAME_UNDO
						|| status == MsgType.GAME_BACK_YES
						|| status == MsgType.GAME_BACK_NO
						|| status == MsgType.PLAYER_GIVEIN
						|| status == MsgType.GAME_PAUSE
						|| status == MsgType.GAME_CONTINUE) {
					parent.notifyGroupOtherPlayers(packet);
				}

			}
		} catch (IOException ex) {
			System.err.println(ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


	public void close() {
		System.out.println("���ѧܧ����ڧ� ���ܧ֧�� �ӧ����է��֧ԧ� �ڧԧ��ܧѣ�");
		try {
			if (oos != null) {
				oos.close();
				oos = null;
			}

			if (ois != null) {
				ois.close();
				ois = null;
			}

			if (socket != null) {
				socket.close();
				socket = null;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
