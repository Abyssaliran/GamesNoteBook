
package cn.fansunion.chinesechess.net;


public class NetworkConstants {

	public static final int POOL_SIZE = 5;

	public static int PLAYER_MAX_SIZE = 20;

	public static int CREATOR_MAX_SIZE = 10;


	public static int PORT = 8962;
}
